# 最新接續：M1 v0.19 獨立候選（2026-10-17 Codex 實作）

**目前分支仍為 `dev/m1-v018-chart-annotations`，main 未合併。** 專案目錄保留 `股票系統M1_v0_18/`，新候選 source 在 `product_candidate/`。以下舊 v0.18 狀態是歷史；本節為最新實作狀態。

本輪先建立 [M1_V019_REQUIREMENTS_TRACE.md](M1_V019_REQUIREMENTS_TRACE.md)，再補確定缺口：原保存高低點／波段／區域的上下文、支持／反證／缺證、逐日連結與重播、任意可用時間區間及價格尺度、共用時間軸K線／股數量／獨立MACD候選。圖形與原始事件不是完成標準；預設呈現主要狀態，完整次級事件可展開。未改原引擎、策略、門檻、schema、歷史庫及舊頁。

**核心產品用途仍未獲驗收。** 五種生命階段、正式修正／三種整理／盤中點線與長紅牆／反彈失敗條件尚缺定義，保留UNKNOWN；量價不能證明籌碼集中。最新確認主要低點只是一個候選參照，不代表重要性判斷已完成。分類NOT_VALIDATED、交易資格NOT_EVALUATED、SQLite事故根因NOT_ESTABLISHED、326人工覆核UNREVIEWED。

實際驗證：286 Python通過；最後純顯示調整後16項候選重測通過；1490個真實保存frame及12個截短前綴通過；最後HTML真實Chromium66檢查、48次精確JSON下載通過，含桌面／手機模擬、拖曳／雙指縮放、原生捲動、任意日期、價格尺度、共同游標、全螢幕及旋轉。Android實機仍NOT_TESTED。詳細執行範圍、原始log、hash及截圖見 [候選驗收報告](股票系統M1_v0_18/product_candidate/validation_20261017/驗收報告.md)，不要把舊72下載或未重跑項目混成本輪。

成品入口：[deliveries/m1-v019-context-20261017/README.md](deliveries/m1-v019-context-20261017/README.md)。包含單頁小ZIP、獨立HTML／候選JSON與三包完整離線專案。三包各自含部分檔案，解壓到同一資料夾即可；完整資產已內附，不需舊ZIP。Git checkout才需要先跑 `python3 codex/bootstrap_m1.py --hydrate-missing`，保留修改並補資產。

**下一步使用工作模式對話**：先讀本入口、原 [M1_V018_PRODUCT_GAP_HANDOFF.md](M1_V018_PRODUCT_GAP_HANDOFF.md)、[需求對照](M1_V019_REQUIREMENTS_TRACE.md)、[具體核心待定案例](M1_V019_CORE_RULE_DECISIONS.md)、候選README及驗收報告。針對1101混合高低點與2884結構仍在但動能轉弱的具體時點，釐清階段／修正、主要關鍵低點及三種整理的必要／排除／失效條件；不自行添加門檻。可引導新版Android實機測試並保留實際證據。定義明確或有可重現程式錯誤後回Codex。工作模式沒有GitHub工具時，必須明說未讀到source，改使用三個完整ZIP，不能只讀摘要就說已取得專案。

可直接給工作模式：
> 請讀取 blue1998-glitch/Twstockai 的 dev/m1-v018-chart-annotations 分支，先讀 CONTINUE_IN_WORK_MODE.md、M1_V019_REQUIREMENTS_TRACE.md、M1_V019_CORE_RULE_DECISIONS.md 及 product_candidate 的README／驗收報告。v0.19是獨立工程候選，不代表核心用途通過；請根據具體保存案例與原規格整理生命階段／修正、主要關鍵低點及三種整理的必要條件與反證，缺少定義保留未知，不擅定門檻。協助我實測候選頁Android，分開記錄使用者回報、實際觀察、檔案核對與未測項目；保留原策略與歷史結果。成果更新同一獨立分支；定義明確後交回Codex實作。

---

## 以下為 v0.18 交接沿革

# 工作模式／Codex 接續入口

目前版本：**M1 v0.18 結構標記版**。來源儲存庫為 blue1998-glitch/Twstockai，最新接續分支為 `dev/m1-v018-chart-annotations`。請明確選此分支；main 尚未合併這次成品。

## 2026-10-17 最新方向修正：核心用途未獲使用者認可

使用者實測後認為標記欠缺重點，未圍繞生命週期與動態股價平衡，並指出 K 線縮放、成交量及 MACD 缺口。下一步改為 Codex 規格追溯與修正，不再限於完成舊頁 Android 操作驗收。

**先讀 [M1_V018_PRODUCT_GAP_HANDOFF.md](M1_V018_PRODUCT_GAP_HANDOFF.md)**：包括使用者回饋、兩份下載 JSON 的實際核對、分析主線、可實作工作及驗收條件。兩份 JSON 各 317193 bytes，逐位元組相同；此不等於全部實機項目通過。沒有新程式交付或新應用測試。本次只更新文件；原引擎與歷史結果保留。

下列雲端成果仍有效，但不代表核心分析用途已通過使用者驗收。

## 歷史已完成

- v0.18 原手機版完成真實 Chromium HTTP 驗收，72次精確 JSON 下載核對通過。
- 新結構標記頁在日線顯示原保存的主要／次級轉折候選與支撐／壓力區候選；可點選或用清單查看原 ID、發生／首次觀察／確認日期及區域狀態。
- 標記頁也完成72次真實 Chromium下載核對，包括桌面、觸控手機模擬、旋轉、canvas、兩種週月口徑與精確 JSON；不是實體 Android 驗收。
- 本次270項Python、1項bootstrap整合、46項相關Node檢查通過。原引擎、策略、門檻、資料庫、歷史數值與舊頁不變。
- 原SQLite事故根因仍NOT_ESTABLISHED；分類NOT_VALIDATED，交易資格NOT_EVALUATED，326筆人工覆核UNREVIEWED。

## 讀取順序

1. 根目錄 AGENTS.md。
2. 股票系統M1_v0_18/AGENTS.md、README.md、docs/CODEX交接.md。
3. 股票系統M1_v0_18/docs/結構標記顯示契約.md。
4. 股票系統M1_v0_18/annotations/validation_20261017/驗收報告.md。

完整程式與證據直接在本分支可審查。下載入口為 `deliveries/m1-v018-annotations-20261017/README.md`；該目錄包含單頁小ZIP、獨立HTML、三個完整ZIP及SHA-256清單。成品本體的已驗證提交為 `5315979bddbdcf1972ac419ffabbeaa3c909f038`；後續交接文件更新不代表重跑應用程式測試。

若工作模式沒有讀取GitHub的工具，必須明確告知尚未讀到程式，改請使用者提供此目錄的三個完整ZIP；不能把讀到這份摘要當成讀完完整專案。三包各自含部分檔案，解壓到同一資料夾即可，無需舊版ZIP。

## 舊 Android 驗收計畫（未測範圍保留，後續範圍以最新修正交接為準）

工作模式可引導使用者在實體Android下載單頁小ZIP、解壓並以瀏覽器開啟「日週月研究對照_結構標記_v0_18.html」。先選TWSE / 1101、Raw、2026-09-30、structure-0.3-research日線版本及可用週月版本，再讀取。

檢查實機開檔、原生選單、點／色帶及證據清單、主要／次級切換、有效／歷史區域、60／130筆／全部、直橫向旋轉，以及實際下載JSON的內容。根據使用者實測、截圖或下載檔，分別記錄已觀察、使用者回報、獨立核對與未測範圍；不把模擬測試視為實機完成。

8069 Raw所選日期沒有有效主要區域，顯示0是保存結果。Adjusted日線沒有保存還原OHLC，仍只畫原MA及同錨定結構，不能造K。兩張範例圖沒有授權新增長紅K壓力、反彈失敗、平臺突破或買賣規則。

若實機出現可定位的程式問題，整理相同分支、選取條件、重現步驟、預期／實際畫面及證據，轉Codex診斷並作必要可逆修正。本輪已有使用者對產品用途的明確負面回饋，允許依最新修正交接處理必要功能缺口；此不授權自行凍結新策略或隱藏未測範圍。

## Codex 準備與交付

從這個分支的repository root執行 `python3 codex/bootstrap_m1.py --hydrate-missing`，保留來源修改並補缺歷史資產。再進入 股票系統M1_v0_18，依交接匯出標記頁及執行與變更相關的檢查。預設strict bootstrap遇到合法source差異會拒絕，不能刪除或覆寫修改來壓過指紋。

使用者已常態授權之後成品直接更新至本GitHub儲存庫的獨立分支；每次提供分支／提交、交接說明、實際驗收結果與可下載成品，讓兩種模式沿用同版。main保留，除非另有明確指示。此授權不等同部署網站、發布雲端環境、付費、交易或發送訊息。

目前下一步使用 **Codex**，先讀 M1_V018_PRODUCT_GAP_HANDOFF.md，完成核心要求追溯並進行可逆修正；具體核心策略或重大架構未決時回工作模式處理。新版 Android 全面驗收仍未完成，不能用附件下載成功代替。
