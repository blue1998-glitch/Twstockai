# 人工分析模式 0.1 驗收（2026-10-22）

## 來源與可重現範圍

- 實際 checkout 於 `dev/m1-v018-chart-annotations`，先跑 `python3 codex/bootstrap_m1.py --hydrate-missing`，回報 546 檔補足、基準 ZIP 有效、7 份既有不同檔保留。原 checkout 無任何已跟蹤檔修改；新原始碼獨立目錄。
- 工作中遠端由 `5282b080...` 增加 `1f12d64f...` 的人工多層箱型標註文件。已 `git fetch`、閱讀完整差異並 fast-forward 至 `1f12d64f279d26aeb19313d94570f6ed9a204912`，不覆蓋它。最終 GitHub 提交另核。
- 父版 0.4.3 ZIP SHA-256 `ee5362de516d52f43b2d09f76b46c04345fd147a2beced4a32e208fbfaf41212`，build 時檢查 SHA／CRC。新 HTML 解壓後原 interned payload 36,717,209 bytes，SHA-256 與父版同為 `a632ac6200b87f8fdc44d2a80c05056019f89e356e0815ec69ac2ad5287d3d30`；新 HTML SHA-256 `072ba58ef36107fa8079e7ce85fab7ce4f3fe04474635bd867fdc52a1b878205`。
- Catalogue 6,344 frames；父版保存解析及 JSON oracle 不新算策略。分類 `NOT_VALIDATED`，行動 `NOT_EVALUATED`，`historical_signal_eligible=false`。

## 本輪實測

| 範圍 | 結果 |
|---|---|
| 純解析、來源重疊、精確日期／無 fallback、不可覆寫 journal、篡改檢出、非法請求 | Python 4 tests PASS |
| 本機 HTTP 真實 Chrome for Testing 151 headless，1280×900 | 首次空白；1101 Raw 與父版精確 selection 相同；重疊日要求來源；8069 還原與父版精確 selection 相同 |
| 缺 8069 還原 2026-10-16 | UNAVAILABLE、圖表隱藏、匯出 saved_selection=null；重載後仍同模式／同日期；明確按「使用最後保存日」後才進 2026-09-30 |
| 換股 8069→6488→2884 | 模式保留 Adjusted；2884 無 Adjusted，不偷偷用 Raw；圖表隱藏 |
| 390×844 手機瀏覽器模擬 | Adjusted 畫面可見；document scrollWidth=390、viewport=390；截圖人工檢視 |
| localStorage 寫入故障注入 | 提示保存未完成；當前選擇仍可 JSON 匯出 |
| 頁面 JS exception | 上述流程 0 個 |

執行：`PYTHONPATH=. python3 -m unittest tests.test_manual_basis -v`；`CHROME_HEADLESS_SHELL=/path/to/chrome-headless-shell $CODEX_PRIMARY_RUNTIME_NODE tests/test_manual_basis_browser.cjs`。頁面採用本機 HTTP；沒有以 `file://` 繞過前輪政策限制。瀏覽器為自行取得的官方 Chrome for Testing 151；原 Playwright CLI 下載遭截斷，改用獨立可核 ZIP 與可執行檔。該下載失敗不算產品失敗。驗收截圖和原數據精確 oracle 位於本版 ZIP。

## 尚未驗證

實體 Android 及其下載檔驗收、寬窄以外其他裝置與離線 file:// 相容性；Adjusted 公司行動完整鏈與方法版本／歷史發布可得；全市場上市櫃普通股；核心圖形辨識準確率、箱底與跨層級規則、動能換股、績效及實際交易。`1f12d64` 的紫／褐大箱底來源仍須依圖與使用者判讀，不因本 UI 實作自訂門檻。Chrome 中環境缺中文字型，截圖部分漢字呈缺字形；DOM 文字及切換邏輯有核對，但不把該截圖當中文視覺字型驗收。
