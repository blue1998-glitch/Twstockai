# 顯示0.2獨立可重現包

不是整份歷史專案，不要覆寫原checkout。一般讀者直接看GitHub新images，不要求終端、手機搬檔或架伺服器。artifacts是新自含HTML與原bytes JSON；project含本輪完整新增顯示工程及庫內固定0.1輸入，沒有數值producer或新行情。原核心完整來源保持在固定702e9144 GitHub。

工程師在全新解壓目錄：

```bash
cd project/股票系統M1_v0_18
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p test_structure_state_readability.py -v
PYTHONDONTWRITEBYTECODE=1 python3 -m structure_state_chart.build_readable --output-dir structure_state_chart/output/REPRODUCED
```

應與artifacts七輸出完整bytes相同。上述新解壓同6不加總12；不需要網路、DB、核心producer或重跑歷史65／94。瀏覽器測試另需既有Chromium與Playwright，開臨時loopback HTTP而非file://或部署；沒有Android通過宣稱。完整限制與下一輪Work唯讀指令見WORK_HANDOFF。
