// Real Chromium only. HTTP validates rendering, not file:// access or physical Android.
const fs = require('fs'), path = require('path'), http = require('http');
const assert = require('assert/strict'), {pathToFileURL} = require('url');
const root = path.resolve(__dirname, '..');
const out = process.env.M1_BROWSER_OUTPUT_DIR || path.join(root, 'cross_view/output');
const output = path.join(out, '日週月真實瀏覽器檢查.json');
const transport = process.env.M1_BROWSER_TRANSPORT || 'file';
const checks = [];

(async () => {
  let browser, server;
  try {
    fs.mkdirSync(out, {recursive: true});
    assert(['file', 'http'].includes(transport), 'Unknown browser transport');
    const html = path.join(root, '日週月研究對照.html');
    let url = pathToFileURL(html).href;
    if (transport === 'http') {
      // Serve only this HTML on loopback; never expose project directories or databases.
      const content = fs.readFileSync(html);
      server = http.createServer((req, res) => {
        if (req.method !== 'GET' || req.url !== '/index.html') {
          res.writeHead(404); res.end(); return;
        }
        res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store'});
        res.end(content);
      });
      await new Promise((resolve, reject) => {
        server.once('error', reject); server.listen(0, '127.0.0.1', resolve);
      });
      url = `http://127.0.0.1:${server.address().port}/index.html`;
    }
    const playwright = require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES
      ? path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES, 'playwright') : 'playwright');
    browser = await playwright.chromium.launch({headless: true,
      ...(process.env.CODEX_BROWSER_EXECUTABLE_PATH
        ? {executablePath: process.env.CODEX_BROWSER_EXECUTABLE_PATH} : {})});
    const expected = JSON.parse(fs.readFileSync(path.join(root, 'cross_view/output/日週月對照實算驗收.json'), 'utf8'));
    assert.equal(expected.cases.length, 18);
    for (const viewport of [{width:1280, height:900}, {width:390, height:844}]) {
      const context = await browser.newContext({viewport, isMobile:viewport.width === 390,
        hasTouch:viewport.width === 390, acceptDownloads:true});
      const page = await context.newPage(), errors = [], external = [], cases = [], screenshots = [];
      page.on('pageerror', error => errors.push(error.message));
      page.on('request', request => {
        if (/^https?:/.test(request.url()) && new URL(request.url()).origin !== new URL(url).origin)
          external.push(request.url());
      });
      await page.goto(url);
      assert(await page.locator('#result').isHidden());
      assert(await page.locator('#load').isDisabled());
      const capturedModes = new Set();
      for (const c of expected.cases) {
        await page.selectOption('#stock', c.exchange + ' / ' + c.code);
        assert(await page.locator('#result').isHidden());
        assert(await page.locator('#download').isDisabled());
        await page.selectOption('#mode', c.price_mode);
        await page.selectOption('#date', c.as_of);
        await page.selectOption('#daily', c.daily_key);
        await page.selectOption('#period', c.period_key);
        if (viewport.width === 390) await page.locator('#load').tap();
        else await page.locator('#load').click();
        assert(await page.locator('#result').isVisible());
        assert((await page.locator('#badge').textContent()).includes('輸入對齊'));
        const original = JSON.parse(fs.readFileSync(path.join(root, 'cross_view/output', c.case + '_VIEW.json'), 'utf8'));
        for (const basis of ['candidate', 'elapsed']) {
          await page.selectOption('#basis', basis);
          for (const tf of ['weekly', 'monthly']) {
            const saved = original.period.record.result.snapshot[tf];
            const cells = await page.locator(`#${tf}Values tr td:nth-child(2)`).allTextContents();
            assert.equal(cells.length, saved.periods.length);
            saved.periods.forEach((period, index) => {
              const item = saved[basis].latest[String(period)];
              if (item.value === null) assert(cells[index].includes('[' + item.reason + ']'));
              else assert.equal(cells[index], item.value);
            });
          }
          const layout = await page.evaluate(() => ({scroll:document.documentElement.scrollWidth, width:window.innerWidth}));
          assert(layout.scroll <= layout.width, JSON.stringify({case:c.case, basis, layout}));
          const painted = await page.locator('canvas').evaluateAll(canvases => canvases.map(canvas => {
            const pixels = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height).data;
            return pixels.some((value, index) => index % 4 === 3 && value > 0);
          }));
          assert.deepEqual(painted, [true, true, true]);
        }
        if (c.price_mode === 'ADJUSTED_CANDIDATE')
          assert((await page.locator('#dailyFacts').textContent()).includes('還原日 K 沒有存入'));
        if (c.code === '1101') assert.equal((await page.locator('#warnings').textContent()).includes('誤標'),
          c.structure_version === 'structure-0.2-research');
        const event = page.waitForEvent('download');
        if (viewport.width === 390) await page.locator('#download').tap();
        else await page.locator('#download').click();
        const download = await event;
        assert.equal(await download.failure(), null);
        const downloaded = JSON.parse(fs.readFileSync(await download.path(), 'utf8'));
        assert.deepEqual(downloaded, original);
        assert.equal(downloaded.alignment.view_id, c.view_id);
        if (!capturedModes.has(c.price_mode)) {
          const screenshot = `${viewport.width}-${c.price_mode}.png`;
          await page.screenshot({path:path.join(out, screenshot), fullPage:true});
          screenshots.push(screenshot); capturedModes.add(c.price_mode);
        }
        cases.push({case:c.case, status:'PASS', bases:['candidate', 'elapsed'],
          exact_json_download:true, saved_values:true, charts_painted:true, no_horizontal_overflow:true});
      }
      assert.deepEqual(errors, []); assert.deepEqual(external, []);
      checks.push({viewport, status:'PASS', actual_comparisons:cases.length, json_downloads:cases.length,
        no_horizontal_overflow:true, page_errors:errors, external_requests:external, screenshots, cases});
      await context.close();
    }
    fs.writeFileSync(output, JSON.stringify({status:'PASS', method:'Real Chromium/Playwright desktop and touch mobile emulation',
      transport, browser_version:browser.version(), checks, physical_android:'NOT_TESTED',
      local_file_access:transport === 'file' ? 'PASS' : 'NOT_VALIDATED_HTTP_ONLY'}, null, 2));
  } catch (error) {
    const blocked = /Executable doesn't exist|Cannot find module|ERR_BLOCKED_BY_ADMINISTRATOR/.test(error.message);
    fs.writeFileSync(output, JSON.stringify({status:blocked ? 'BLOCKED' : 'FAIL', reason:error.stack,
      transport, checks, physical_android:'NOT_TESTED'}, null, 2));
    process.exitCode = blocked ? 2 : 1;
  } finally {
    if (browser) await browser.close();
    if (server) await new Promise(resolve => server.close(resolve));
  }
})();
