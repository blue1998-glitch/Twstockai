# M1 官方來源資格補充 0.1

這是本輪新入口；START_HERE.md及ACTION_PACKAGE_MANIFEST.json屬前輪事件帳，原293成員完整保留。
解壓到另一新資料夾，勿覆蓋原專案。先讀股票系統M1_v0_18/rotation_research/source_qualification_20261022/README.md、REPORT.md、SOURCE_CONTRACT.md及WORK_HANDOFF.md。

標準Python可離線重現本輪來源驗收：
```bash
cd 股票系統M1_v0_18
python3 -m unittest rotation_research.test_source_qualification -v
python3 -m rotation_research.source_qualification
```

15項新測試；16官方月報317市場日／473曆日，70研究窗口只補核日曆，總淨報酬仍0合格，2窗口不足。
不能用市場開市日推定個股有價格，也不能用當前預告零命中推定沒有公司行動。
設定草稿尚未套用，新官方網域未驗；資料／策略／Android限制見REPORT，沒有新UI。
SOURCE_QUALIFICATION_MANIFEST.json核對此新包全部成員；舊ACTION manifest仍可單獨核舊原件。
這不是完整歷史專案；GitHub完整checkout仍依根AGENTS準備。打包script重建需原已交付ZIP，不在此小包另複製該ZIP。
