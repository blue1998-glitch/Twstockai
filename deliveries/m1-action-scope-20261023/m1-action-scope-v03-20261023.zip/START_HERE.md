# M1公司行動與逐日資金帳 0.1

這是獨立研究／會計證據小包，非完整歷史專案。保留原專案，解壓到另一新資料夾。
閱讀 股票系統M1_v0_18/rotation_research/action_data_20261022/README.md、REPORT.md、CONTRACT.md。
包內有來源原件子集及新模組，標準Python可離線重現下列44定向測試及資格核查：

```bash
cd 股票系統M1_v0_18
python3 -m unittest rotation_research.test_action_sources rotation_research.test_action_ledger rotation_research.test_action_integration -v
python3 -m rotation_research.action_study
```

事件五組件不是完整事件清單，70市場窗口全拒算、2不足，總淨報酬合格0。
engineered是工程測試值，不是市場行情。gross-schedule-preview是真實毛額預定時程，不代表淨現金或實際到款。
無新UI、瀏覽器或Android驗收。原P1-7的歷史報告及整個舊庫不在此小包，不可用本包替代完整checkout。
完整專案工程接續仍依GitHub指定分支根AGENTS準備；WORK_HANDOFF有完整指令。
