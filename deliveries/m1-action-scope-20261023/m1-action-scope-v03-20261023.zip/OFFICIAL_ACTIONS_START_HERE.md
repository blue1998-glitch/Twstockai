# M1 官方行動來源補充0.2

先讀股票系統M1_v0_18/rotation_research/official_actions_20261022/README.md、REPORT.md、CONTRACT.md與WORK_HANDOFF.md。
此包保留前包375成員及歷史README，新增此0.2入口與原件／獨立producer／測試。
解壓到新資料夾，進入股票系統M1_v0_18後：
```bash
python3 -m unittest rotation_research.test_official_actions -v
python3 -m rotation_research.official_actions
```
標準Python，離線讀已封存原件及雙SHA文字，不需PDF依賴。勿執行網路capture作為驗收。
0.010015129為公開金額與同次面額推導精度，非實際未圓整最終比例；公司發放完成不認證個人到款或掛牌日。
完整行動／淨分配／期初權利未核，真正總淨報酬仍0合格；無新UI／Android。
OFFICIAL_ACTIONS_MANIFEST.json核此包全部其他成員，兩層舊manifest亦保留。
完整專案仍由指定GitHub分支依根AGENTS準備；打包腳本需前已交付ZIP，不另把ZIP重複塞進小包。
