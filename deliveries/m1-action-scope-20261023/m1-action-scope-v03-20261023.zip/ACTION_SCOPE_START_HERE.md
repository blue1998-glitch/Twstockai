# M1公司行動適用對象／版本核對0.3

新入口：股票系統M1_v0_18/rotation_research/action_scope_20261023/README.md、REPORT、CONTRACT、WORK_HANDOFF。
原410成員與各歷史入口保持，另加入最新Work原件及本輪獨立新程式。
解壓至新資料夾，進入股票系統M1_v0_18：
```bash
python3 -m unittest rotation_research.test_action_scope -v
python3 -m rotation_research.action_scope_sources
```
標準Python離線，無新依賴或查詢；只驗本版24測試，不把舊數字冒作本版通過。
2884配股DIRECT_PUBLISHED、2867股東換股及台泥資本公積提案分開；權利證書上市／匯費不跨案。
新資格重新跑70窗仍拒算、2不足、8窗另列換股影響未支援；沒有每日淨帳或六方案新績效。
完整公司行動、最終來源／精度／可賣日、淨分配與期初權利仍缺，真正總淨報酬0合格。Android未測。
ACTION_SCOPE_MANIFEST.json核全部其他成員；三層舊manifest可各自獨立核對。
此為研究小包，完整checkout仍依GitHub根AGENTS準備；重建打包需原交付ZIP，不在包內重複塞ZIP。
