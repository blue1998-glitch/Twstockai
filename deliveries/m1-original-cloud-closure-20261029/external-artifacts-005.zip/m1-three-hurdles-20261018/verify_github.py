from pathlib import Path
import concurrent.futures,datetime,hashlib,json,urllib.request,urllib.parse,zipfile
root=Path('/workspace/Twstockai');artifact='87ec609ef51d7346554e2546e520a9dbc4ac2235';delivery='deliveries/m1-v019-three-hurdles-20261018';outside=Path('/workspace/m1-three-hurdles-20261018/github-readback');outside.mkdir(exist_ok=True)
index=json.loads((root/delivery/'SOURCE_HASHES.json').read_text())['files'];names=set(index)
names.update(str(p.relative_to(root)) for p in (root/delivery).iterdir() if p.is_file())
def read(name):
 expected=(root/name).read_bytes();url='https://raw.githubusercontent.com/blue1998-glitch/Twstockai/'+artifact+'/'+urllib.parse.quote(name,safe='/')
 with urllib.request.urlopen(url,timeout=60) as response:
  content=response.read();status=response.status
 if content!=expected:raise ValueError('GitHub byte mismatch: '+name)
 target=outside/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(content)
 return dict(file=name,url=url,http_status=status,bytes=len(content),sha256=hashlib.sha256(content).hexdigest(),exact_local_equal=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:records=list(pool.map(read,sorted(names)))
package=json.loads((root/delivery/'PACKAGE_VERIFICATION.json').read_text());zp=outside/delivery/package['zip'];members={}
with zipfile.ZipFile(zp) as archive:
 if archive.testzip() is not None or set(archive.namelist())!=set(package['members']):raise ValueError('Remote ZIP CRC or membership mismatch')
 for name,meta in package['members'].items():
  data=archive.read(name)
  if len(data)!=meta['bytes'] or hashlib.sha256(data).hexdigest()!=meta['sha256']:raise ValueError('Remote ZIP member mismatch')
  dest=outside/'extracted-small-zip'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  members[name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),status='PASS')
report=dict(status='PASS',verified_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),branch='dev/m1-v018-chart-annotations',artifact_commit=artifact,remote_branch_head_observed=artifact,remote_main_unchanged='9c5b168c09ba80010c74f03b9c537e8b7474256a',verified_files=len(records),verified_bytes=sum(r['bytes'] for r in records),files=records,remote_small_zip=dict(status='PASS',crc='PASS',sha256=hashlib.sha256(zp.read_bytes()).hexdigest(),members=members),scope='Pinned artifact commit contents actually downloaded and byte-compared; later receipt documentation is a separate commit, not a claim of Android acceptance.')
(root/delivery/'GITHUB_DOWNLOAD_VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:report[k] for k in ('status','artifact_commit','verified_files','verified_bytes')},ensure_ascii=False));print('Remote ZIP CRC, extracted SHA and bytes: PASS')
