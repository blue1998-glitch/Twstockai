from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from urllib.request import urlopen
from urllib.parse import quote
import subprocess,json,hashlib
root=Path('/workspace/Twstockai');work=Path('/workspace/m1-source-admission-20261023');commit='b6db79279b3f84a134e9259aebd88d06a85243f1';branch='dev/m1-v018-chart-annotations'
files=json.loads((work/'publish-files.json').read_text())
def verify(name):
 url='https://raw.githubusercontent.com/blue1998-glitch/Twstockai/'+commit+'/'+quote(name,safe='/');local=(root/name).read_bytes()
 try:
  with urlopen(url,timeout=30) as response:body=response.read();http=response.status
  return dict(path=name,url=url,http=http,bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),byte_equal=body==local,passed=http==200 and body==local)
 except Exception as error:return dict(path=name,url=url,passed=False,error=type(error).__name__+': '+str(error))
with ThreadPoolExecutor(max_workers=4) as pool:checks=list(pool.map(verify,files))
head=subprocess.check_output(['git','ls-remote','origin','refs/heads/'+branch],cwd=root,text=True).split()[0];main=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=root,text=True).split()[0]
assert head==commit and main=='9c5b168c09ba80010c74f03b9c537e8b7474256a'
r=dict(product_commit=commit,branch=branch,observed_at=datetime.now(timezone.utc).isoformat(),remote_branch_head=head,main_unchanged=main,files=len(checks),all_pass=all(c['passed'] for c in checks),checks=checks)
(work/'readback.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='checks'}),flush=True)
for c in checks:
 if not c['passed']:print(json.dumps(c,ensure_ascii=False))
assert r['all_pass']
