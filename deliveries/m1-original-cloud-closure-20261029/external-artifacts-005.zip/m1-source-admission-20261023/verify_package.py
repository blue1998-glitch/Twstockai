from pathlib import Path
import json,zipfile,hashlib,subprocess,tempfile
root=Path('/workspace/Twstockai');d=root/'deliveries/m1-action-scope-20261023';bundle=d/'m1-action-scope-v03-20261023.zip'
receipt=json.loads((d/'bundle-receipt.json').read_text());assert hashlib.sha256(bundle.read_bytes()).hexdigest()==receipt['sha256']
with tempfile.TemporaryDirectory(dir='/workspace',prefix='m1-action-scope-extracted-') as td:
 extracted=Path(td)
 with zipfile.ZipFile(bundle) as z:
  assert z.testzip() is None;z.extractall(extracted)
  with zipfile.ZipFile(root/'deliveries/m1-official-actions-20261022/m1-official-actions-v02-20261022.zip') as old:
   assert all(z.read(n)==old.read(n) for n in old.namelist());old_count=len(old.namelist())
  counts={}
  for name in ('ACTION_SCOPE_MANIFEST.json','OFFICIAL_ACTIONS_MANIFEST.json','SOURCE_QUALIFICATION_MANIFEST.json','ACTION_PACKAGE_MANIFEST.json'):
   m=json.loads(z.read(name));assert all(hashlib.sha256(z.read(n)).hexdigest()==s for n,s in m.items());counts[name]=len(m)
 project=extracted/'股票系統M1_v0_18'
 for name,args in [('extracted-tests.log',['python3','-m','unittest','rotation_research.test_action_scope','-v']),('extracted-producer.log',['python3','-m','rotation_research.action_scope_sources'])]:
  r=subprocess.run(args,cwd=project,text=True,capture_output=True);(d/name).write_text(r.stdout+r.stderr);r.check_returncode()
 manifest=json.loads((extracted/'ACTION_SCOPE_MANIFEST.json').read_text())
 assert all(hashlib.sha256((extracted/n).read_bytes()).hexdigest()==s for n,s in manifest.items()),'Reproduction altered shipped outputs'
 ws=json.loads((project/'rotation_research/action_scope_20261023/window-qualification.json').read_text())['windows']
 assert sum(w['end'] is not None for w in ws)==70 and sum(w['end'] is None for w in ws)==2
 assert all(w['daily']==[] and w['total_net_return'] is None and not w['original_numeric_replay_called'] for w in ws if w['end'])
 summary=dict(bundle_sha256=receipt['sha256'],fresh_extraction='PASS',tests=24,offline_producer='PASS',original_members_byte_exact=old_count,manifest_members=counts,all_members_unchanged_after_reproduction=True,refused_windows=70,insufficient_windows=2,total_net_return_qualified_windows=0,original_numeric_replay_calls=0,browser_runs=0,android='NOT_TESTED_NEW_BUILD')
 (d/'package-verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary))
