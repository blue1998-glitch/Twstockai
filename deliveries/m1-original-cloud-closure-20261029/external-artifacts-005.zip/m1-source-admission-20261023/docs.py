from pathlib import Path
import subprocess,json,hashlib
root=Path('/workspace/Twstockai');p=root/'股票系統M1_v0_18/rotation_research/action_scope_20261023'
(p/'README.md').write_text('''# 公司行動適用對象／版本核對 0.3

本輪獨立程式入口；接續983b3559b616703e705bd64a70d256e4a09bbe03的Work來源核對，不改舊producer或資金帳。來源缺口仍會拒算，沒有新市場績效或UI。

- [實作及實測報告](REPORT.md)、[數值／來源契約](CONTRACT.md)、[完整續接指令](WORK_HANDOFF.md)。
- [新catalog與來源欄位](events-v03.json)：5個原帳組件、5個來源版本（3組文件家族，非5個獨立公司行動）。
- [72窗口新資格結果](window-qualification.json)、[單一跨換股日probe](scope-refusal.json)、[執行摘要](verification.json)、[24測試](tests.log)。
- 原來源在source_review_20261022；新producer校驗六原件、metadata、抽字及實際PDF連結，並與Work的直接比例欄位比對。
- 可下載小包／逐檔遠端核對入口：根deliveries/m1-action-scope-20261023/README.md。

解壓至新資料夾，標準Python離線重現：
```bash
cd 股票系統M1_v0_18
python3 -m unittest rotation_research.test_action_scope -v
python3 -m rotation_research.action_scope_sources
```
無新依賴、網路查詢或瀏覽器。source producer只寫本新目錄；純數值action_scope.py不讀檔、不連網、不選策略。

進階查單一欄位時，先從events-v03.json明確選inventory版本與field，提供family／issuer_code／entitled_old_code／action_type／old_instrument／version_id、field／unit／date_role、帶時區observed_as_of及purpose=SOURCE_DIAGNOSTIC，再呼叫action_scope.resolve_field。它不自行選最新版本；FINAL_LEDGER使用另需最終欄位資格，當前部分來源不具此資格。
''')
(p/'CONTRACT.md').write_text('''# 公司行動適用對象與來源契約 0.3

1. 新純數值action_scope.py及外部action_scope_sources.py；新schema rotation-scoped-action-catalog/0.3。原official_actions.py、action_sources／action_ledger、core／loop／策略參數、0.1／0.2 catalog、庫、輸入與歷史不改。新事件表只在獨立目錄；四個原現金組件逐位元語義不變，原配股另有父ID／新ID及前後觀察時點。
2. 重新驗六份官方原件／meta的URL、origin、HTTP、長度、SHA、衍生文字雙指紋；HTML再以HTMLParser重核可見內容，PDF核其magic及官方索引真實連結。三PDF／三HTML只算六原件，抽字不算獨立證據。健保署403只存failed來源提示，不進可用sources；本輪沒有新官方網路請求、重試或繞過。
3. 直接公告每千股10.015129／1000＝0.010015129股／原股，Decimal保留原公開精度，標DIRECT_PUBLISHED；舊金額／面額導出公式另存prior_ratio_calculation，不偽裝為直接公式。新公式明示按千股轉單股；未圓整最終比、個人實配／零股／2025可賣日仍unknown。頁面自載2025/7/7另存，不倒填announced_at。
4. 每來源版本分開issuer_code、entitled_old_code、old_instrument、action_type、family、version_id、field、unit、date_role。既有2884普通股的股票股利與原2867普通股的股份轉換不是同一權利；單位NEW_2884_PER_OLD_2867不得轉成NEW_2884_PER_OLD_2884。2867與公司名的映射沿用Work明示對照，列出資格限制，不冒充新完整官方主檔已核。
5. 股份轉換原0.2486提案與後0.2596公告分存，文件自載發言時點與實際擷取觀察時點分開。只記文件所稱先後，不默選較晚版本或當歷史可知。resolve_field須指定完整身份及觀察截止，早於capture、無時區或要求歷史訊號均拒絕。announced_at=null、historical_signal_eligible=false。
6. Q&A的2026/9/1是本換股案新股權利證書上市，非2025配股普通股可賣日或所有新股的一般規則；ROUND_TO_WHOLE_TWD與特定條件匯費10元只綁本案原2867股東，不能借給其他股利。actual_investor_receipt不由公司時程推出。新resolve_field在錯日期角色、錯對象／事件／版本／單位或未知欄時拒用，不將null補零。
7. 台泥每股0.8元資本公積保留為BOARD_PROPOSAL來源分類。final_funding_source、capital_surplus_subtype、net_cash_per_share為null；提案、公司稅務說明或失敗健保署來源不構成最終法規與個人淨額模型。原CASH_DIVIDEND粗類型只表示舊帳機制，不作所得／補充保費分類。年底所得稅不改作發放日已實扣款。
8. coverage必含known_company_action_ids（包含同家族各來源版本），不能僅保原股利而漏掉已知股份轉換；這些ID是來源追蹤，不是獨立事件數。當前公司完整期間覆蓋仍INCOMPLETE，任何input自行改VERIFIED_COMPLETE亦不能蓋過catalog的來源資格。
9. 原action_ledger僅支援現金股利、股票股利與減資，不支援2867→2884股份轉換；不在本輪新增換股會計或擅給既有2884增股。窗口跨公告的預定9/1或起日恰9/1，追加SHARE_EXCHANGE_ACCOUNT_IMPACT_UNSUPPORTED，保留舊股東影響待核。不由文件定調既有2884完全無其他權利影響。9/1後的預定事件不記為更早已發生；完整名冊仍另外不足。
10. admit_and_replay先驗證catalog與組件指紋／版本，作適用對象核對並重用舊qualify；任何不足則回傳新REFUSED結果，daily／journal空，scenario_net_return、total_net_return、actual_realized_investor_return全null，不呼叫原每日數值回放。只有全部外部來源及原數值契約皆合格才允許交原replay。本輪沒有合格市場資料，故此成功計算路徑未以真實市場資料驗收，不宣稱已算淨績效。
11. 實際對原72研究窗重新做新資格核對：70拒算、2不足；其中8窗另辨識跨／起於股份轉換預定日的未支援範圍。不是新六方案重跑，未產生成交、排名或勝出比例；primary_pressure_id=null、policy_authorized=false。原價格／缺價／Raw與Adjusted、歷史公布、五年Adjusted、主檔及SQLite未知保持。無新UI／Android。
12. 個人淨分配／期初權利仍需有來源紀錄或明示情境模型；空白證據表不是零資產／零權利。不得公開提交私人持倉或券商原件。全換／分批／觸發仍研究變數，不自動下單。
''')
(p/'REPORT.md').write_text('''# 2026-10-23 本輪實作與實測

本輪起點983b3559b616703e705bd64a70d256e4a09bbe03，包含使用者最低354a9c01及其後事件帳、官方日曆、0.2與最新Work來源核對全部成果。fetch／fast-forward保留後續。重新bootstrap --hydrate-missing成功：0補缺／7合法差異保留、baseline_verified=true，見bootstrap.log。

## 完成的工程

- 新純數值適用對象／版本核對與外部離線來源producer，沒有改原official_actions.py、action_ledger或core。六官方原件、三PDF實際連結與抽字／原件雙SHA重核，並核Work已確認的直接比例欄位；沒有新官方網路查詢或安裝。
- catalog0.3新增DIRECT_PUBLISHED證據及按千股→單股精確換算；原股票組件保留父ID、舊公式、舊觀察時點，另存新來源與新ID。四個現金組件保持原值。公司名／2867映射沿用Work且明示不是新完整主檔。
- 三商壽同案原0.2486、後0.2596及Q&A各保原來源版本；與2884股利及台泥資本公積提案分開。5個來源版本屬3個文件家族，不當5個獨立公司行動。
- 檢索須精確綁股東原股票、issuer、instrument、事件、版本、單位與日期角色。9/1權利證書上市、零股四捨五入／匯費10元不能流入2025股利；台泥提案不能直接當免稅／淨額模型。
- 新資格層以catalog真實來源限制input宣告；即使input單方面改成完整，也不能略過已知公司行動或取得淨績效。2867換2884不支援，保留既有2884帳影響待核，不直接配給原2884持股。

## 本輪實際執行

- 24項定向unittest通過：精度／單位、錯股東／issuer／事件／日期角色／版本、公開時間與後見訊號、未知不補零、來源／文字破損、偽完整旗標仍拒用、原價缺口與舊catalog保存。
- producer實際重新核對122價量原件與既有輸入一致，並驗舊來源0.2重建一致；對70個研究窗口執行新scope與原qualify，另1個單獨跨9/1 probe。70仍拒算、2不足；8窗增加股份轉換影響未支援原因。輸出逐列另核見output-verification.json。
- 所有市場daily／journal仍空、總淨報酬null；原每日numeric replay呼叫0、六方案／排名重跑0。這次是新程式實跑資格，不再只是讀舊72窗；仍不是有合格資料的總淨報酬計算通過。
- 首輪producer及24測試即通過（first-run／tests-first）；後續補強公式、來源映射及執行計數後的最終結果見run.log／tests.log。沒有隱藏的本輪測試失敗；前輪失敗原檔均保持。
- 封包將在新目錄解壓後執行同24測試與producer，逐成員SHA核對；實際結果只以delivery/package-verification及extracted紀錄為準。舊成果保存見preservation.json；遠端逐檔結果見delivery/GITHUB_READBACK。

## 未完成與限制

完整兩股2025/7/1～2026/10/16公司行動／減資及7/25後權息覆蓋、2884精確未圓整實配／2025新股直接可賣日／零股截止、台泥最終來源決議與細項法規、淨分配及期初權利仍缺。當前來源不能產生真正總淨報酬，合格窗仍0。未實作股份轉換會計；沒有新個人實現績效、全換／分批最佳配置或市場飛輪驗證。

MOPS、TWT49U/TWT48U、TWTAUU、file://與NHI403均未重試或繞過。公司完成報告不當個人收款；空白證據表不當零權利。1101 2025/8/13及2884 2025/11/5缺報價原因仍UNKNOWN，未用併購日或他股停牌填因。Raw公司行動、五年Adjusted／歷史公布／完整主檔及SQLite根因未知保留。

舊17／44／15及18／9982／Chrome36未重跑；無新UI、瀏覽器、Android（NOT_TESTED_NEW_BUILD），正式圖形／交易／飛輪未升格。原引擎、策略參數、庫、歷史、舊頁／ZIP及main保持。下一步Work補確切來源，工程缺口再交Codex。
''')
prompt='''接續blue1998-glitch/Twstockai，分支dev/m1-v018-chart-annotations。先查遠端最新，確認包含983b3559b616703e705bd64a70d256e4a09bbe03及其後action_scope_20261023實作／GitHub回讀收據，保留354a9c01以來全部後續，不用main或舊ZIP覆蓋。最新固定成品與回讀見deliveries/m1-action-scope-20261023/GITHUB_READBACK.md。
讀根AGENTS、CONTINUE_IN_WORK_MODE、PROJECT_VISION、M1_V019_GRAPH_CORE_RESUME_HANDOFF最新節；全文讀股票系統M1_v0_18/rotation_research/action_scope_20261023的README、REPORT、CONTRACT、WORK_HANDOFF、events-v03、scope-refusal、verification、output-verification及delivery收據，再讀source_review_20261022的CODEX_TASK、facts、coverage-gaps及source-manifest。原事件帳／0.2／官方日曆契約仍適用。
本輪實作獨立純數值action_scope及外部source producer，24新定向測試實測通過。六官方原件與122價量原件重核；新catalog0.3只提升2884直接公開配股精度0.010015129，未核未圓整／個人實配。三商壽0.2486／0.2596與Q&A各保版本，均原2867股東，不能給原2884持股配股；9/1是本案新股權利證書上市，不補2025股利可交易日。零股／匯費也不跨案。台泥0.8資本公積仍董事會提案來源，不補最終來源、細項、免稅或淨到款。頁面自載日期不當歷史可知，announced_at=null、historical_signal_eligible=false，primary_pressure_id=null、policy_authorized=false。
本輪新scope資格實際重新執行70窗與另1probe，70拒算、2不足；8窗另見預定換股日影響未支援。原每日numeric replay與六方案重跑0，真正總淨報酬合格0，沒有每日真實淨帳、成交或績效／排名。5個來源版本屬3組文件家族，不當5個獨立公司行動。原帳只支持現金／配股／減資，不支持股份轉換；不能在coverage省略已知換股或由input旗標蓋掉catalog的完整性不足。
下一步Work優先補有來源的完整公司行動／減資及2026/7/25後權息覆蓋、2884直接可賣日／未圓整依據／零股期限、既有2884股東在換股案的直接權利影響；台泥最終分配決議／資本公積細項及適用法規。個人淨分配與每起日期初權利要有來源，或另做來源明確且情境／稅籍明示模型，不預設零稅費／零應收，不把空白表當帳戶。私人券商／集保原件不得提交公開Git。
MOPS安全拒絕、TWT49U/TWT48U、TWTAUU307、file://及NHI403不重試不繞過。可獨立讀到的其他官方原件才保存URL／擷取時點／SHA／對象與欄位，來源不足保持未知／拒算，不用個別公告、目前零命中或公司完成報告認證整段無事件／個人到款。1101 2025/8/13、2884 2025/11/5缺價原因仍UNKNOWN，不補行情；Raw／五年Adjusted、歷史公布、主檔與SQLite未知保持。
工程交Codex，實際完整checkout按最新AGENTS重新bootstrap --hydrate-missing成功後才做獨立新版本；不改原producer／core／action_ledger／策略參數／庫／歷史／舊catalog／舊頁／舊ZIP或main。全換／分批／觸發仍研究變數，不重問已答P0～P1、不新增正式門檻／自動下單。原17／44／15及18／9982／Chrome36不能當本輪重跑。無新UI，不重開手機驗收；Android NOT_TESTED_NEW_BUILD、正式圖形NOT_VALIDATED／交易與飛輪NOT_EVALUATED。不部署付費交易訊息或子代理。適量實測，逐節點保存同分支並固定提交逐檔GitHub回讀；結束列實際完成／未完成、成品／SHA入口、最新已核提交及下一步Work或Codex，附完整續接指令。'''
(p/'WORK_HANDOFF.md').write_text('# 完整回Work／後續Codex指令\n\n下一步Work補來源；需要工程再交Codex。遠端固定節點以delivery回讀收據為準。\n\n```text\n'+prompt+'\n```\n')
latest='''# 2026-10-23 Codex｜來源0.3適用對象／版本核對已實作

接續983b3559，保留354a9c01以來全部後續；新入口 `股票系統M1_v0_18/rotation_research/action_scope_20261023/README.md`、REPORT／CONTRACT／WORK_HANDOFF，ZIP／固定GitHub逐檔核對見 `deliveries/m1-action-scope-20261023/README.md`。原事件帳、來源0.2、Work核對小包及P1-7保持；下方是歷史。

重新bootstrap成功（0補缺／7差異保留）。新純數值action_scope與離線source producer接入六官方原件，提升2884直接公開比例精度並分開issuer／受領原股／事件／版本／instrument／日期角色。三商壽0.2486／0.2596與Q&A只屬原2867股東，不配給既有2884；9/1證書上市及零股／匯費不補2025股利。台泥0.8資本公積仍提案，不補最終來源／淨稅費。新觀察時點與文件自載日期分開，announced_at仍null。

24新定向測試通過，122價量原件與舊輸入再核；新資格實跑70研究窗＋1probe，70拒算／2不足，其中8窗增加換股影響不支援原因。原每日numeric replay與六方案重跑0，真正總淨報酬合格0；5來源版本屬3文件家族，非5獨立事件。input自行改完整旗標亦不能蓋過catalog來源不足；不省略已知公司行動或假定既有2884無影響。

完整行動／減資及7/25後權息、未圓整實配／2025可賣日／零股、台泥最終決議／細項法規、淨分配及期初權利仍缺。MOPS／權息端點／TWTAUU／file://／NHI403均未重試繞過，缺價原因未知不補價；本輪無新官方網路／UI／瀏覽器Android，Android NOT_TESTED_NEW_BUILD。原producer／action_ledger／core／策略參數／庫／歷史／舊catalog頁面及ZIP／main不改，舊17／44／15及18／9982／Chrome36未重跑。下一步Work補來源，工程Codex；完整可貼指令見新WORK_HANDOFF。不重問P0～P1、不定全換／分批、不部署付費交易訊息或子代理，Raw／五年Adjusted／歷史公布／主檔／SQLite未知保持。以下原文完整保留。

---

'''
for rel in ('AGENTS.md','CONTINUE_IN_WORK_MODE.md','M1_V019_GRAPH_CORE_RESUME_HANDOFF.md','股票系統M1_v0_18/rotation_research/README.md','股票系統M1_v0_18/rotation_research/WORK_HANDOFF.md','股票系統M1_v0_18/rotation_research/DATA_QUALIFICATION.md'):
 f=root/rel;b=f.read_bytes();assert not b.startswith(latest.encode());f.write_bytes(latest.encode()+b)
base=json.loads(Path('/workspace/m1-source-admission-20261023/baseline.json').read_text());changed=[];unchanged=0
for name,digest in base['files'].items():
 b=(root/name).read_bytes()
 if hashlib.sha256(b).hexdigest()==digest:unchanged+=1;continue
 before=subprocess.check_output(['git','show',base['base']+':'+name],cwd=root)
 assert b.endswith(before),name
 changed.append(name)
assert len(changed)==6
(p/'preservation.json').write_text(json.dumps(dict(base_commit=base['base'],original_tracked_files=len(base['files']),byte_identical=unchanged,prefix_only_original_bytes_exact_suffix=changed,deleted_files=0,all_original_code_data_catalogs_stores_histories_and_zips_unchanged=True),ensure_ascii=False,indent=2)+'\n')
