from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,hashlib,json,urllib.request,urllib.parse,datetime
repo=Path('/workspace/Twstockai'); scratch=Path('/workspace/m1-tcc-annual-archive-20261023')
commit='d5d506eec77e36c63e496e6c5f1daed9d25f0216'
paths=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','-z',commit],cwd=repo).decode().split('\0')[:-1]
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):return None
def fetch(path):
 expected=subprocess.check_output(['git','show',commit+':'+path],cwd=repo)
 url='https://raw.githubusercontent.com/blue1998-glitch/Twstockai/'+commit+'/'+urllib.parse.quote(path,safe='/')
 row={'path':path,'url':url,'requested_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expected_bytes':len(expected),'expected_sha256':hashlib.sha256(expected).hexdigest(),'redirects_followed':False,'retries':0}
 try:
  opener=urllib.request.build_opener(NoRedirect())
  with opener.open(urllib.request.Request(url,method='GET'),timeout=60) as r:
   row['http']=r.status;data=r.read()
  row.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),full_bytes_equal=data==expected,passed=row['http']==200 and data==expected)
 except Exception as e:row.update(passed=False,error=repr(e))
 row['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 return row
with ThreadPoolExecutor(max_workers=4) as pool:checks=list(pool.map(fetch,paths))
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/dev/m1-v018-chart-annotations','refs/heads/main'],cwd=repo,text=True)
refs={line.split()[1]:line.split()[0] for line in remote.splitlines()}
result={'scope':'ACTUAL_NEW_CODEX_ANNUAL_SOURCE_ARCHIVE_NO_PRODUCT_CHANGE','source_archival_commit':commit,'parent_commit':'71e6ff269b0ed974a3b7cfe97c3fdd3d5e9d66b2','unchanged_product_v010_commit':'f423447c9396bfdd7c524f4c5f63173be1ebb47d','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':len(checks),'all_pass':all(r['passed'] for r in checks),'remote_head':refs['refs/heads/dev/m1-v018-chart-annotations'],'main_head':refs['refs/heads/main'],'main_unchanged':refs['refs/heads/main']=='9c5b168c09ba80010c74f03b9c537e8b7474256a','source_original_sha256':'7406e30d1f02f083611f594459b952494816d87237bf2203734ce6afb487155d','source_package_sha256':'0eaac599005a946400d644829de663bd5dfb5a8e482b88ceb21e4deb6943c439','work_archive_meta_obtained':False,'product_tests_run':0,'checks':checks}
(scratch/'source-readback.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
assert result['all_pass'] and result['main_unchanged'],json.dumps([r for r in checks if not r['passed']])
assert result['remote_head']==commit,refs
(repo/'deliveries/m1-tcc-annual-source-20261023/GITHUB_READBACK.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False,indent=2))
