from pathlib import Path
import json
repo=Path('/workspace/Twstockai'); p=repo/'docs/source-research/20261023_tcc_annual_capture'; d=repo/'deliveries/m1-tcc-annual-source-20261023';d.mkdir(exist_ok=False)
meta=json.loads((p/'raw/tcc-annual-114.meta.json').read_text()); proc=json.loads((p/'pdf-processing.json').read_text())
readme=f'''# 台泥114年度年報：新Codex來源歸檔

這是來源歸檔，**不是0.11、帳務事件或產品接入**。原唯一Codex於環境恢復後接續；遠端71e6ff269b0ed974a3b7cfe97c3fdd3d5e9d66b2及指定祖先已核，全部後續與main保留。

- [原PDF bytes](raw/tcc-annual-114.response)（可用PDF閱讀器開啟或另存.pdf），4,932,379 bytes；SHA256 `{meta['sha256']}`。
- Git blob SHA1 `{meta['git_blob_sha1']}`。與使用者提供的Work比對值一致；這是本Codex新捕捉，不是Work原meta／研究包已交付。
- [公開安全meta](raw/tcc-annual-114.meta.json)：精確URL一次GET、HTTP200、未轉址／未重試；開始{meta['requested_at']}，完成{meta['completed_at']}。標頭為解析後公開安全欄位，不冒原始header bytes。
- [人工視讀及圖指紋](visual-review.json)、[公司來源觀察](observations.json)、[日期角色](date-roles.json)、[完整處理診斷](pdf-processing.json)、[範圍／未完成](availability.json)。
- [物理52／印刷102–103](visual/tcc-annual-114-p52.png)、[57／112–113](visual/tcc-annual-114-p57.png)、[58／114–115](visual/tcc-annual-114-p58.png)、[60／118–119](visual/tcc-annual-114-p60.png)。只實際視讀這四頁指定項目，非113頁全書核閱。
- [報告](REPORT.md)、[契約界線](CONTRACT.md)、[完整Work唯讀續接指令](WORK_HANDOFF.md)、[來源交付包及固定讀回](../../../deliveries/m1-tcc-annual-source-20261023/README.md)。

## 核讀結果與差異

115/1/13是董事會議日；115/2/23是**公司年報報告**的經濟部核准函日期，函原件未取得；股本形成表115.03保留月份，不能當精確生效日。年報28,000,000股與舊第二季財報28,000仟股只作同家族交叉來源，新增帳務事件／獨立市場樣本0。

舊財報「115年1月辦理註銷」與本年報股本形成表「115.03」分開留存，不自行調和、選日期或拆成兩事件。actual_effective_at及announced_at仍null。普通股來源表7,523,181,742股、特別股200,000,000股與股本形成表實收7,723,181,742股口徑分開；不把含特別股的總數直接當普通股或推個人權利。

## 使用及診斷

離線檢查此來源歸檔（只需Python標準庫，不重新下載或轉圖）：

```bash
python3 verify_archive.py
```

來源處理pdfinfo／pdftotext及四頁pdftoppm均return0。pdfinfo stderr空；pdftotext完整stderr7,992 bytes、222行Invalid Font Weight警告；每頁轉圖各2行同警告，完整stdout／stderr均在raw。新完整stderr是本Codex新產物，不冒Work原stderr已取得；不證舊Fontconfig／xref消除。

bootstrap成功0補缺／7差異保留。離線來源／封包檢查不是產品測試；沒有重跑producer、資格、產品／歷史回歸、每日帳、六方案或Android。原0.10全部parent、策略引擎、庫、Raw null、UNKNOWN歷史、catalog、舊頁／原件／成品與main不改；不回寫parent null。

全部來源缺口及execution_qualified=false、imputed_close／valuation=null、historical_signal_eligible=false、primary_pressure_id=null、policy_authorized=false保持。日期元資料不證歷史公開可得；公司註銷不自動等於股東比例減資／退資。私人原件不公開、不補零或行情。不重試既錄拒絕入口、library、已存CTBC／受限公開說明書／嘉新失敗路徑，不以unrestricted解禁。不部署、付費、交易、訊息或子代理。
'''
(p/'README.md').write_text(readme)
(p/'CONTRACT.md').write_text('''# 新年報歸檔界線

這是docs來源研究目錄，不是版本化產品層；不建立0.11、catalog、正式數值／選關／帳務規則。正式0.10及全部parent契約，尤其subsidiary_proposal_20261023/CONTRACT.md、正式action_resolution_20261023/CONTRACT.md及events-v04.json保持原bytes與資格。保留CTBC所有界線、IPO方案非完成與場次矛盾、Fontconfig勘誤及xref歷史。

1. 來源只認本Codex實際取得bytes；URL、HTTP、SHA、長度與原捕捉／本機讀回另存。Work捕捉時間只USER_REPORTED比較資料，Work原meta／頁圖未取得；相同PDF指紋不等取得Work封包。headers已解析並限公開安全欄位，非完整header bytes。
2. issuer1101；本案對象為公司持有普通股的庫藏股註銷，不當既有普通股持有人按比例減資／退資、個人受配或零影響證明。年報股本來源的普通股／特別股與實收總股數分欄，不以總數推普通股或個人比率。
3. 115/1/13是董事會議日；115/2/23為公司報告外部核准函日期，不冒函原件已取得；115.03是股本形成表年月。年度／月份／日及「股／仟股／元」原精度保留，不造月初／月底日期。註銷28,000,000股、資本減少280,000,000元不是個人款股。
4. 舊第二季財報115年1月、年報115.03並存；只保存同家族交叉來源差異，不宣稱調和或依晚來源覆早值，不拆兩事件。actual_effective_at與announced_at保持null。第七次表內數量不是另一事件或獨立市場樣本。
5. 3/24是年報自載截至時點，PDF建立／修改與HTTP Last-Modified是元資料；官方公開可得未證，不能倒填公告或歷史訊號。新Codex捕捉不借Work時間，work_github_readback_at保持null。
6. 只視讀物理52／57／58／60指定項目，不冒113頁全書。native全文與人工盤點分開，保存完整新stderr及各圖SHA，警告非空白，return0不等無警告，也不抹舊Fontconfig／xref。Work原抽字完整stderr仍未取得。
7. 不新增產品行為，不重跑producer、產品測試／歷史回歸、資格、daily／journal、六方案或Android。離線封包CRC／manifest／來源核對不是市場／產品測試。歷史53及70／2／8／合格0不冒本輪重跑。
8. 完整1101／2884行動減資、2026/7/25～10/16權息、直接TWSE復牌／2025可交易、個人未圓整實配／畸零期限及實際處置／既有2884影響、台泥最後調整／最細稅源、個人淨額及九研究起點權利仍缺。不假定無事件或零費、不補行情／前價／估值。私人券商／集保原件不公開。
9. 九起點均2026年：01-02、02-02、03-02、04-01、05-04、06-01、07-01、08-03、09-01。起點持股／目前持股／公司總數不證先前或當日起點除權息權利。
10. execution_qualified=false、imputed_close／valuation=null、historical_signal_eligible=false、primary_pressure_id=null、policy_authorized=false，Raw／五年Adjusted／歷史公布／主檔／SQLite未知及全換／分批研究變數保持。全部已拒入口不重試／繞過；新PDF成功不解禁。無新UI不重開Android；不改main、不部署付費交易訊息或子代理。
''')
(p/'REPORT.md').write_text(f'''# 本輪實際歸檔報告

## 已完成範圍

原環境恢復至spec8／observed8、connected/running，exec命令實際可用；status的network policy state仍unknown，沒有冒稱enforced或全部入口通行。未改環境設定、代理、CA或TLS。遠端指定分支71e6ff26及三指定祖先已核，main仍9c5b168c09ba80010c74f03b9c537e8b7474256a。本輪唯一Codex處理，未啟動平行工作或子代理。

按AGENTS重新bootstrap --hydrate-missing成功，0補缺／7差異保留，再進行來源歸檔。精確新URL一次GET，HTTP200，無轉址／重試；原件4,932,379 bytes，SHA {meta['sha256']}，Git blob {meta['git_blob_sha1']}均匹配Work參照。完整Git追蹤HEAD原無該blob或同大小檔。新Codex捕捉{meta['requested_at']}～{meta['completed_at']}，與Work16:50捕捉分開，Workmeta未取得不冒已交付。

## 指定四頁實際核讀

| 物理／印刷頁 | 真實觀察 | 日期／對象／精度限制 |
|---|---|---|
|52／102–103|右頁115/1/13董事會通過註銷第七次買回庫藏股暨訂定減資基準日案|只有會議日，不是已證基準日|
|58／114–115|註14寫28,000,000股及115/2/23經授商字第11530011800號函核准|公司報告核准函；函原件未取得，不借作生效日|
|57／112–113|股本形成表115.03、其他欄(280,000,000元)、註14|月份不造精確日，金額不是個人退資|
|60／118–119|第七次已辦理銷除及轉讓之股份數量28,000,000股|同家族交叉來源，不新增事件或樣本|
|57／112–113|普通股7,523,181,742、特別股200,000,000；形成表實收7,723,181,742|不同表及股別口徑分開，不將實收總數當普通股或個人權利|

PDF總113頁；只視讀上述四頁指定項目。物理58註14的native line48、物理57年月line113及金額line112，物理52會議主題line50／日期line61為合併儲存格，以圖核關聯，不單憑文字先後配日期。物理60第七次欄及銷除列line32／57同樣以圖核對。

舊財報本機重用：PDF3320224 bytes／SHA e8a8ca682a242180a908a68030dc80ee0321ddf92217586f59230b1d3e584d2d，原native實體52為115年1月辦理註銷28,000仟股、57為本期註銷28,000（仟股）。本年報表列115.03與該月份差異未調和；不選任一作生效、不拆兩事件。舊PDF／meta／native／圖完全保留，沒有重抓重畫；定位見observations.json。

## 實際檢查與警告

pdfinfo return0／stderr0；pdftotext return0／完整stderr7992 bytes、222行 `Syntax Warning: Invalid Font Weight`；四個pdftoppm各return0／同警告2行。全部新stdout／stderr及PNG指紋保存；Work原完整stderr未交付，不冒已取得。新警告不證舊Fontconfig／xref已消除。離線verify_archive.py已實跑PASS，只核原件、meta、處理檔與圖指紋、盤點界線；新來源封包CRC／manifest與解壓檢查另見delivery/package-verification.json，**不是產品測試**。

沒有新產品模組、catalog／0.11、帳務事件或獨立樣本；沒有執行producer、資格重算、產品／歷史回歸、daily／journal、六方案或Android。不以歷史53、70／2／8／合格0作本輪結果。舊Work ZIP及meta／研究檔未取得未讀未驗；公司新聞中英文重複／嘉新讀取逾時只使用者提供Work結果，本Codex未發新請求或取得該候選。

## 日期、來源及未完成

年報3/24截至時點不等公告，PDF建立5/12 06:13:56Z／修改06:27:10Z、HTTP Last-Modified亦不證歷史截止可得。announced_at／actual_effective_at保持null，核准函原件缺；1月／3月差異仍未解。其他完整行動／區間權息、直接復牌／可交易、個人實配畸零／既有2884換股影響、台泥最後調整／最細稅源、個人淨分配及九起點權利仍缺。

原0.10與全部parent null、catalog、引擎策略、庫、Raw null／UNKNOWN、歷史、原件與成品不改。三根交接僅新增前綴，逐檔保留核對見preservation.json；main未變。固定來源提交逐檔GitHub原bytes讀回後才報交付，收據在delivery，避免自指SHA循環。

未取得：經濟部函、Work原meta／頁圖／完整研究與舊包；未讀：未取得資料及非指定109頁之視讀；未實作：產品接入／0.11（不在範圍）；未執行：producer／資格／每日帳／六方案；未測：產品回歸／Android；未讀回：Work原封包，這與本Codex新來源固定逐檔讀回分開。

下一步只交Work唯讀來源研究；完整可貼文字見WORK_HANDOFF.md。優先用庫內原件及真正新線索，不反覆核同檔、不重問已答比例、不造績效、不公開私人原件、不重試既錄拒絕入口或嘉新逾時路徑。不部署、付費、交易、訊息或子代理。
''')
(p/'WORK_HANDOFF.md').write_text('''# 下一輪Work唯讀完整續接指令

固定來源提交與最新已核SHA以deliveries/m1-tcc-annual-source-20261023/GITHUB_READBACK.md／JSON及實際分支頭為準。這是新年報來源歸檔，沒有0.11／產品接入。

```text
接續blue1998-glitch/Twstockai，分支dev/m1-v018-chart-annotations。
先唯讀核遠端包含71e6ff269b0ed974a3b7cfe97c3fdd3d5e9d66b2、固定CTBC519e0a25eb34bb7358be895c54946d02e945ad92、原0.10 f423447c9396bfdd7c524f4c5f63173be1ebb47d及其後新年報來源固定提交／讀回收據。保留全部後續，不回退、強推或以main／舊ZIP覆蓋。

Work僅來源研究與GitHub唯讀，不bootstrap、工程、產品測試、commit／push或另開Codex／子代理。工程仍由原既有唯一Codex處理。

讀根AGENTS、CONTINUE_IN_WORK_MODE、PROJECT_VISION、M1_V019_GRAPH_CORE_RESUME_HANDOFF最新節；全文讀docs/source-research/20261023_tcc_annual_capture/README.md、WORK_HANDOFF.md、CONTRACT.md、REPORT.md，以及observations.json、date-roles.json、visual-review.json、pdf-processing.json、availability.json、raw/tcc-annual-114.meta.json；讀delivery README、package-verification、GITHUB_READBACK MD／JSON。CTBC交接、正式0.10及全部parent契約與Fontconfig勘誤繼續有效。

先用已存原件，不重新抓此年報或已存CTBC／公開說明書。年報4932379 bytes，SHA256 7406e30d1f02f083611f594459b952494816d87237bf2203734ce6afb487155d，Git blob f6d87f6ee476c56cb596a4d6fa326d8a45ac85ba；Codex精確URL一次HTTP200，無轉址重試。新Codex捕捉17:18:18.708199Z～17:18:22.478497Z與Work16:50捕捉分開；Work原meta／研究檔未取得，不冒封包已交付。公開headers不是完整原始header bytes。

只視讀物理52／57／58／60，對應印刷102–103／112–113／114–115／118–119，非113頁全書核閱。115/1/13是董事會議日；115/2/23函核准只公司年報報告，經濟部函原件未取得；115.03是表列月份，不創精確生效日。28,000,000股與舊財報28,000仟股只同家族交叉佐證，不新增帳務事件或獨立樣本。股本形成表實收總股數含特別股，不直接當普通股；個人權利未知。

舊第二季財報115年1月與年報115.03分開保存，不宣稱調和、選任一為生效或拆兩事件。actual_effective_at／announced_at仍null。自載截至3/24、PDF建立／修改與HTTP日期、公司函日期、捕捉／讀回時間角色不得互借，歷史可得未證。

Codex新pdfinfo、抽字、四頁轉圖均return0；抽字完整stderr7992 bytes、222行Invalid Font Weight，各頁轉圖各2行同警告，已保存。這不是Work原stderr已取得，不證舊Fontconfig／xref消除。原PDF／JSON／PNG／catalog／ZIP與舊警告不改、不重抓重畫。

本輪僅來源歸檔與來源／封包完整性檢查，未新增0.11、catalog、產品規則或parent null。沒有producer、資格、產品／歷史回歸、每日帳、六方案或Android。歷史53與70／2／8／合格0不是本輪重跑；Work不得把來源讀取或新解壓當產品驗收。

優先真正新線索：完整1101／2884行動減資及2026/7/25～10/16權息、直接TWSE復牌／2884的2025可交易日、個人未圓整實配／畸零期限及實際處置／既有2884換股影響、台泥最後調整／最細稅源、個人淨分配及九研究起點既有權利。九起點均2026年：01-02、02-02、03-02、04-01、05-04、06-01、07-01、08-03、09-01。起點／目前持股、公司總數不證先前或當日除權息權利；私人券商／集保原件不得公開。不假定無事件、不補零、行情、前價或估值。

台泥中文版稅務新聞與既存英文版重複不算新最細稅源；嘉新候選逾時未取得，不採搜尋摘要、不重試該失敗路徑。玉山兩條待核轉載不升官方原件。IPO方案非完成／場次矛盾及CTBC年度、股別、日期、金額精度、非個人實收等全部界線保持。

MOPS安全拒絕、TWT49U／TWT48U、TWTAUU307、file://、NHI403、公報PDF403、TWSE公文查詢307、重大訊息導MOPS空頁、wwwc.twse.com.tw／investoredu.twse.com.tw／ttc.mof.gov.tw三舊403、library、已存CTBC及受限公開說明書路徑不重試／不換主機路徑繞過。runtime unrestricted不等入口解禁。舊Work包／MANIFEST／完整WORK_RESEARCH_HANDOFF／原meta與selection未取得未讀未驗，不要求手機搬檔，不冒已交付。

全部舊版、策略、引擎、庫、Raw null、UNKNOWN、歷史、成品及main保持。execution_qualified=false；imputed_close／valuation=null；historical_signal_eligible=false；primary_pressure_id=null；policy_authorized=false。Raw／五年Adjusted／歷史公布／主檔／SQLite未知，全換／分批仍研究變數。

只交實際唯讀／研究結果、新來源與具體缺口。沒有新來源或工程實益就結束，不為湊版本追加產品。確有必要工程再交回此唯一Codex，依最新AGENTS準備／實測／同分支提交／固定逐檔原bytes讀回。最後分列未取得／未讀／未實作／未執行／未測／未讀回，只選一個接續對象並附一份完整指令。不部署、付費、交易、發訊息或啟動子代理。
```
''')
prefix='''# 2026-10-23 Codex｜台泥114年報來源歸檔：1月／3月留差異，不建0.11

原環境恢復connected/running（spec8；policy state仍unknown，不冒enforced）後，核遠端71e6ff26及指定祖先，按AGENTS bootstrap成功0補缺／7差異保留。新年報精確URL一次HTTP200／4932379bytes／SHA7406e30d1f02f083611f594459b952494816d87237bf2203734ce6afb487155d，與Work參照相符；無轉址重試。入口 `docs/source-research/20261023_tcc_annual_capture/README.md`、REPORT／CONTRACT／WORK_HANDOFF、observations／date-roles／visual-review；來源包及固定原bytes回讀見 `deliveries/m1-tcc-annual-source-20261023/README.md`。

實際只視讀物理52／57／58／60（印刷102–103／112–113／114–115／118–119），非113頁全書。1/13董事會、2/23公司報告核准函、115.03股本表月份分角色；函原件未取得，不造生效日。舊第二季財報115年1月與年報115.03未調和，不覆舊值／選日期／拆事件，actual_effective_at及announced_at仍null。28,000,000股與28,000仟股只同家族佐證，不當股東現金事件；含特別股實收總數不當普通股或個人權利。3/24自載截至／PDF與HTTP元資料不證歷史可得。

新pdfinfo／抽字／四頁轉圖return0，抽字完整stderr7992bytes／222行Invalid Font Weight，各圖2行同警告，完整保存，不冒Work原stderr已取得或舊Fontconfig／xref已消除。只來源／封包核對，無新產品／catalog／0.11，不回寫parent null；producer／資格／產品回歸／每日帳／六方案／Android未跑，歷史53及70／2／8／合格0不冒重測。全部原版本、策略引擎、庫、Raw null／UNKNOWN、歷史原件／圖／成品與main保持。

下一步Work僅來源研究／GitHub唯讀，完整指令在新WORK_HANDOFF。缺口／九期初權利與所有資格false/null保持；舊Work包／meta未取得，不冒交付。已存年報／CTBC／舊PDF與全部受拒入口不重抓或繞過，嘉新逾時路徑不重試，不因unrestricted解禁。唯一既有Codex寫入，不部署付費交易訊息或子代理。以下原文完整保留。

---

'''
for name in ['AGENTS.md','CONTINUE_IN_WORK_MODE.md','M1_V019_GRAPH_CORE_RESUME_HANDOFF.md']:
 f=repo/name; f.write_bytes(prefix.encode()+f.read_bytes())
print('Wrote source-only README/CONTRACT/REPORT/WORK_HANDOFF and three additive root handoff prefixes')
