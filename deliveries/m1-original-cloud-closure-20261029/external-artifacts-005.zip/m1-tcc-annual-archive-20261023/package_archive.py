from pathlib import Path,PurePosixPath
import subprocess,json,hashlib,tempfile,zipfile,datetime
repo=Path('/workspace/Twstockai'); scratch=Path('/workspace/m1-tcc-annual-archive-20261023'); p=repo/'docs/source-research/20261023_tcc_annual_capture';d=repo/'deliveries/m1-tcc-annual-source-20261023'
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(root,name,v):(root/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
baseline=json.loads((scratch/'baseline.json').read_text()); changed=[]; unchanged=[]
for name,old in baseline['tracked_files'].items():
 f=repo/name
 if not f.is_file() or sha(f.read_bytes())!=old['sha256']: changed.append(name)
 else: unchanged.append(name)
expected=['AGENTS.md','CONTINUE_IN_WORK_MODE.md','M1_V019_GRAPH_CORE_RESUME_HANDOFF.md']
assert sorted(changed)==sorted(expected),(changed,expected)
for name in expected:
 original=subprocess.check_output(['git','show',baseline['head']+':'+name],cwd=repo)
 assert sha(original)==baseline['tracked_files'][name]['sha256'] and (repo/name).read_bytes().endswith(original)
put(p,'preservation.json',{'status':'PASS','baseline_commit':baseline['head'],'baseline_tracked_files':len(baseline['tracked_files']),'unchanged_existing_tracked_files':len(unchanged),'changed_existing_files':changed,'root_handoffs_prepend_only':True,'all_existing_sources_catalogs_strategy_engines_databases_raw_unknown_history_pages_and_archives_unchanged':True,'baseline_main_head':baseline['main'],'old_untracked_groups_preserved_by_no_modification_and_status_inventory':baseline['status'],'untracked_full_byte_baseline_claimed':False,'product_or_parent_null_modified':False})
put(p,'execution-diagnostic.json',{'scope':'SOURCE_ARCHIVE_ONLY_NOT_PRODUCT_TESTS','environment_recovery':[{'observation':'spec8 connected/running but initial exec still unavailable before environment context reattached','root_cause':'NOT_ESTABLISHED'},{'observation':'after actual environment attachment pwd and original checkout commands succeeded'}],'read_diagnostics':[{'command':'cat full root AGENTS.md','result':'HISTORICAL_OUTPUT_TRUNCATED','resolution':'Read latest sections and applicable tail rules with bounded output; no claim entire historical narrative reviewed'},{'command':'rg --files -g AGENTS.md docs/source-research deliveries rotation_research && wc ...','returncode':1,'result':'NO_MATCHES_PREVENTED_WC_NOT_PRODUCT_FAILURE','resolution':'Used direct file inventory; no scoped AGENTS files in those target trees'}],'bootstrap_returncode':0,'bootstrap_restored_files':0,'bootstrap_differing_files_preserved':7,'new_official_GET_attempts':1,'new_official_GET_http':200,'redirects_followed':False,'retries':0,'pdfinfo_returncode':0,'pdftotext_returncode':0,'render_returncodes':[0,0,0,0],'pdftotext_invalid_font_weight_warning_lines':222,'render_invalid_font_weight_warning_lines_each':[2,2,2,2],'complete_new_stderr_preserved':True,'work_original_full_stderr_obtained':False,'old_fontconfig_and_xref_unchanged':True,'first_archive_verification_returncode':0,'source_archive_integrity_checks_not_product_tests':True,'product_tests_run':0,'historical_product_regression_run':0,'producer_or_qualification_or_daily_six_plan_executed':False})
r=subprocess.run(['python3',str(p/'verify_archive.py')],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(p/'archive-verification.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
ver=json.loads(r.stdout);put(p,'source-verification.json',ver)
sourcefiles=sorted(f for f in p.rglob('*') if f.is_file() and f.name!='MANIFEST.json' and '__pycache__' not in f.parts)
entries=[{'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in sourcefiles]
put(p,'MANIFEST.json',{'scope':'CODEX_NEW_ANNUAL_SOURCE_ARCHIVE_NOT_WORK_PACKAGE_OR_COMPLETE_PROJECT','manifest_excludes_self':True,'members':entries,'zip_timestamps_role':'NORMALIZED_CONTAINER_METADATA_NOT_OFFICIAL_CAPTURE_OR_ANNOUNCEMENT'})
name='tcc-annual-codex-source-archive-20261023.zip';zpath=d/name
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(sourcefiles+[p/'MANIFEST.json']):
  info=zipfile.ZipInfo(str(f.relative_to(p)),date_time=(2026,10,23,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
  z.writestr(info,f.read_bytes(),compresslevel=9)
with tempfile.TemporaryDirectory(prefix='annual-offline-',dir=scratch) as target:
 with zipfile.ZipFile(zpath) as z:
  assert z.testzip() is None
  names=z.namelist();assert len(names)==len(set(names))
  assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n for n in names)
  manifest=json.loads(z.read('MANIFEST.json'));assert set(names)=={v['path'] for v in manifest['members']}|{'MANIFEST.json'}
  for e in manifest['members']:
   b=z.read(e['path']);assert len(b)==e['bytes'] and sha(b)==e['sha256']
  z.extractall(target)
 fresh=Path(target); before={n:sha((fresh/n).read_bytes()) for n in names}
 check=subprocess.run(['python3','verify_archive.py'],cwd=fresh,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 assert check.returncode==0,check.stderr
 assert before=={n:sha((fresh/n).read_bytes()) for n in names}
(d/'extracted-verification.log').write_bytes(check.stdout+check.stderr)
receipt={'status':'PASS','scope':'SOURCE_ARCHIVE_PACKAGE_NOT_PRODUCT_TESTS','filename':name,'bytes':zpath.stat().st_size,'sha256':sha(zpath.read_bytes()),'members':len(names),'manifest_entries':len(entries),'crc_unique_safe_paths':True,'all_manifest_lengths_and_sha_verified':True,'new_directory_extraction_verified':True,'offline_verification_command':['python3','verify_archive.py'],'offline_returncode':check.returncode,'offline_result':json.loads(check.stdout),'all_members_unchanged_after_verification':True,'product_tests_run':0,'product_regressions_run':0,'producer_or_qualification_rerun':False,'work_archive_obtained':False}
put(d,'package-verification.json',receipt)
(d/'SHA256SUMS').write_text(receipt['sha256']+'  '+name+'\n')
(d/'README.md').write_text(f'''# 台泥114年報來源歸檔包（非0.11）

- [下載來源ZIP]({name}?raw=true)：{receipt['bytes']:,} bytes，{receipt['members']}成員／{receipt['manifest_entries']}項manifest。
- SHA256：`{receipt['sha256']}`；另見[SHA256SUMS](SHA256SUMS)。
- [來源README](../../docs/source-research/20261023_tcc_annual_capture/README.md)、[原件meta](../../docs/source-research/20261023_tcc_annual_capture/raw/tcc-annual-114.meta.json)、[公司來源觀察及月份差異](../../docs/source-research/20261023_tcc_annual_capture/observations.json)。
- [指定四頁圖與核讀指紋](../../docs/source-research/20261023_tcc_annual_capture/visual-review.json)、[報告](../../docs/source-research/20261023_tcc_annual_capture/REPORT.md)、[完整Work續接指令](../../docs/source-research/20261023_tcc_annual_capture/WORK_HANDOFF.md)。
- [實際新解壓／CRC／manifest／離線檢查](package-verification.json)、[解壓執行紀錄](extracted-verification.log)、[固定提交逐檔GitHub原bytes讀回](GITHUB_READBACK.md)／[JSON](GITHUB_READBACK.json)。收據在來源提交後另存，避免自指SHA。

原PDF4932379 bytes，SHA7406e30d1f02f083611f594459b952494816d87237bf2203734ce6afb487155d；新Codex精確URL一次HTTP200，無重試轉址，與Work指紋相符但不是Work封包交付。來源包包含PDF原bytes（raw/tcc-annual-114.response，可另存.pdf）、新完整抽字／stdout／stderr、四頁PNG與原生文字定位、盤點與日期角色、來源差異、保留與交接。不是完整專案，不要覆寫原工作目錄。

新目錄解壓可離線執行`python3 verify_archive.py`，只核來源／meta／圖與歸檔界線，不重新下載或轉圖，不匯入產品。封包檢查不是產品測試。

115/1/13會議、2/23公司報告核准函、115.03表列月份與舊財報115年1月分存；未調和、不造生效日或拆事件。actual_effective_at／announced_at仍null，經濟部函原件未取得；普通股／特別股口徑分開，註銷不是個人退資。PDF113頁只視讀指定四頁；抽字222行Invalid Font Weight及每圖2行警告完整保存，不抹舊Fontconfig／xref。

本輪不建0.11、catalog、帳務事件或產品行為，不回寫parent null；無producer／資格／產品回歸／每日帳／六方案／Android。全部舊版本、引擎策略、庫、Raw null／UNKNOWN、歷史、原件成品及main保留，完整行動／權息／個人權利等缺口與原資格false/null保持。

下一步只Work來源研究與GitHub唯讀；完整可貼指令在來源WORK_HANDOFF。未取得／未讀／未實作／未執行／未測／未讀回分列。不重抓已存來源、重試既拒入口或嘉新失敗路徑，不公開私人原件、不部署付費交易訊息或子代理。
''')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
