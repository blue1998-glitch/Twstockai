from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.request import urlopen
from urllib.parse import quote
from datetime import datetime,timezone
import subprocess,hashlib,json

r=Path('/workspace/Twstockai');s=Path('/workspace/m1-source-followup-v07-20261023')
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
names=json.loads((s/'publish-files.json').read_text())
def read(name):
 expected=subprocess.check_output(['git','show',sha+':'+name],cwd=r)
 url='https://raw.githubusercontent.com/blue1998-glitch/Twstockai/'+sha+'/'+quote(name,safe='/')
 try:
  with urlopen(url,timeout=30) as response:b=response.read();http=response.status
  return dict(path=name,url=url,http=http,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),byte_equal=b==expected,passed=http==200 and b==expected)
 except Exception as e:return dict(path=name,url=url,passed=False,error=type(e).__name__+': '+str(e))
with ThreadPoolExecutor(max_workers=4) as pool:checks=list(pool.map(read,names))
head=subprocess.check_output(['git','ls-remote','origin','refs/heads/dev/m1-v018-chart-annotations'],cwd=r,text=True).split()[0]
main=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=r,text=True).split()[0]
v=dict(checkpoint_commit=sha,parent_commit='2d2dbf1aeedcc6238a2cfc064170bdbdcc3a7040',status='BLOCKED_ALL_THREE_NEW_SOURCES_PROXY_CONNECT_403',
 observed_at=datetime.now(timezone.utc).isoformat(),files=len(checks),all_pass=all(x['passed'] for x in checks),remote_head=head,
 main_head=main,main_unchanged=main=='9c5b168c09ba80010c74f03b9c537e8b7474256a',new_source_versions=0,new_product_tests=0,checks=checks)
(s/'github-readback.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:x for k,x in v.items() if k!='checks'}),flush=True)
for c in checks:
 if not c['passed']:print(json.dumps(c,ensure_ascii=False))
assert v['all_pass'] and head==sha and v['main_unchanged']
