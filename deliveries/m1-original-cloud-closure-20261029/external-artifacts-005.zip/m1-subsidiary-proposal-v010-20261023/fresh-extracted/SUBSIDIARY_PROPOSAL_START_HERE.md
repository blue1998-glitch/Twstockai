# 子公司方案來源0.10離線重現

讀股票系統M1_v0_18/rotation_research/subsidiary_proposal_20261023/README、CONTRACT、REPORT與WORK_HANDOFF。
全新目錄解壓，cd 股票系統M1_v0_18，標準Python離線執行：
```bash
python3 -m unittest rotation_research.test_subsidiary_proposal rotation_research.test_capital_components -v
python3 -m rotation_research.subsidiary_proposal_sources
```
不需網路、PDF工具或瀏覽器；已含兩新原件／meta／原生文字／五頁視讀PNG。
24新＋29相關回歸＝53；全新解壓同53不累加。詳細掃描條款parser未實作，不冒OCR。
公司子公司IPO方案非完成或個人1101配股／減資，場次矛盾與未知不修正。
原0.9的723成員及十一manifest全保留，新增manifest核全部其餘成員。
來源包不是完整checkout，不覆專案；正式工程先按最新GitHub AGENTS重新bootstrap。
