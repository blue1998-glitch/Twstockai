from pathlib import Path
import hashlib,json,subprocess,zipfile

ROOT=Path('/workspace/Twstockai');WORK=Path('/workspace/m1-subsidiary-proposal-v010-20261023')
DEL=ROOT/'deliveries/m1-subsidiary-proposal-20261023';target=DEL/'m1-subsidiary-proposal-v010-20261023.zip'
out=WORK/'fresh-extracted';out.mkdir(exist_ok=False)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
    assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
    members={n:z.read(n) for n in z.namelist()};z.extractall(out)
with zipfile.ZipFile(ROOT/'deliveries/m1-capital-components-20261023/m1-capital-components-v09-20261023.zip') as z:
    assert len(z.namelist())==723 and all(members[n]==z.read(n) for n in z.namelist())
manifests={}
for n,b in members.items():
    if n.endswith('_MANIFEST.json'):
        m=json.loads(b);assert all(hashlib.sha256(members[f]).hexdigest()==sha for f,sha in m.items());manifests[n]=len(m)
assert len(manifests)==12
commands=[['python3','-m','unittest','rotation_research.test_subsidiary_proposal','rotation_research.test_capital_components','-v'],['python3','-m','rotation_research.subsidiary_proposal_sources']]
results=[]
for args,name in zip(commands,['extracted-tests.log','extracted-producer.log']):
    p=subprocess.run(args,cwd=out/'股票系統M1_v0_18',capture_output=True,text=True);(DEL/name).write_text(p.stdout+p.stderr)
    results.append(dict(command=args,returncode=p.returncode,log=name));assert p.returncode==0,name
assert 'Ran 53 tests' in (DEL/'extracted-tests.log').read_text()
assert all((out/n).read_bytes()==b for n,b in members.items())
base=out/'股票系統M1_v0_18/rotation_research';new=base/'subsidiary_proposal_20261023';old=base/'capital_components_20261023'
v=json.loads((new/'verification.json').read_text());c=json.loads((new/'catalog-v010.json').read_text());parent=json.loads((old/'catalog-v09.json').read_text())
assert c['parent_catalog']==parent and c['parent_catalog_id']==parent['id']
assert (new/'missing-quotes.json').read_bytes()==(old/'missing-quotes.json').read_bytes()
missing=json.loads((new/'missing-quotes.json').read_text())['diagnostics']
assert all(d['raw_close'] is None and not d['execution_qualified'] and d['suspension_end_date'] is None for d in missing)
w=json.loads((new/'window-qualification.json').read_text())['windows']
assert v['qualification_calls']==sum(x['end'] is not None for x in w)
assert v['refused_windows']==sum(x['status']=='REFUSED_INCOMPLETE_EVENT_ACCOUNTING' for x in w)
assert v['insufficient_windows']==sum(x['end'] is None for x in w)
assert v['exchange_unsupported_windows']==sum('SHARE_EXCHANGE_ACCOUNT_IMPACT_UNSUPPORTED' in x.get('refusal_reasons',[]) for x in w)
assert v['qualified_total_net_return_windows']==sum(x.get('total_net_return') is not None for x in w)==0
assert all(not x['daily'] and not x['journal'] and not x['original_numeric_replay_called'] for x in w if x['end'] is not None)
result=dict(status='PASS',filename=target.name,bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),members=len(members),parent_v09_members_byte_exact=723,manifests=manifests,commands=results,actual_distinct_tests=53,new_tests=24,old_tests_actually_rerun=29,all_bundle_members_unchanged_after_test_and_producer=True,exact_original_bridge_zip_included=True,missing_quotes_new_evidence_and_old_unknown_preserved=True,exact_complete_parent_v09_preserved=True,statistics_reconciled_from_actual_window_rows=True,offline_producer_verification=v)
(DEL/'package-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result))
