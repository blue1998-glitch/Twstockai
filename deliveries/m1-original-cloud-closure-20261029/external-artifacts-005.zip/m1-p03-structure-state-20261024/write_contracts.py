from pathlib import Path
import json,hashlib,datetime,shutil,importlib.util,sys
r=Path('/workspace/Twstockai');p=r/'股票系統M1_v0_18';s=Path('/workspace/m1-p03-structure-state-20261024');v=p/'structure_state_chart/validation_20261024';v.mkdir(exist_ok=True);sys.path.insert(0,str(p))
(p/'structure_state/README.md').write_text('''# 已確認 P0-3 結構狀態附層 0.1

這是 `p03-structure-state/0.1`，不是公司行動來源0.11，也不是自動選帶／主要壓力／買賣策略。直接重用原 `reaction_facts.core.evaluate` 的精確 close/high/low、三態及路徑；不改原reaction_facts、graph_core參數、策略、指標、庫或歷史。核對未見同等角色／P0-3狀態實作後才新增此附層，人工模式解析沿原manual_basis，沒有再做第二套路由。

## 確認規則與相等

在明示、已知、同源／基底／版本、有效角色及突破後返回情境下：

|收盤事實|輸出|
|---|---|
|嚴格高於回檔高點|STRENGTHENING／轉強|
|沒有高於回檔高點，也沒有低於原箱下緣|CONSOLIDATING／整理|
|嚴格低於原箱下緣|WEAKENING／轉弱|
|缺角色、尚不可知、角色失效、來源／基底／版本不符、中斷或矛盾|INSUFFICIENT／證據不足／不可判定|

EQUAL另存`equal_boundaries`及原close/high/low關係；等於高點不算突破，等於箱底不算跌破，因此有效情境下仍為整理。淺回檔線可另存來源事實，但不是判弱界線。量、MACD正負與前筆描述比，分列支持／反面／缺證，不會取消已發生的嚴格收盤過線。沒有容忍百分比、確認天數、量倍數、OSC門檻、機率、主壓力或自動進出規則。

## 純數值、來源與時間

`core.evaluate(facts_input, scenario, as_of=...)`無檔案／網路／UI／資料庫IO，無時計依賴；`source.prepare(comparison_data, choice)`是純來源綁定adapter；`cli.py`／`build.py`才做外部IO。price字串使用既有Decimal比較，不受全域精度或JS浮點影響。錯來源輸入明示拒用，不補缺值、不整理或猜日期。

`p03-explicit-roles/0.1`要求PULLBACK_HIGH、ORIGINAL_BOX_FLOOR、ORIGINAL_BOX_UPPER；最後一項只驗最初突破，淺回檔線SHALLOW_OBSERVATION可選。每個角色有reference_id、語義evidence、HUMAN_CONFIRMED／RESEARCH_CANDIDATE／ENGINEERING_FIXTURE資格、原值occurred_at／known_on、角色known_on／valid_from／valid_until／invalidated_on及實際selected_at。原參照同時保留來源K或研究候選ID、source/frame/prefix、價格基底及adjustment_version；角色ID另綁版本。未知選取時點不造歷史已選，來源條件不足就不可判定。

原箱候選的上下緣必同一已保存候選，帶完整原K見證日，不可任意拼兩價或升作HUMAN_CONFIRMED。回檔高點必明選返回階段K成員與全部同最高日，核與原K、已知時點相符；不自動拿最近pivot。**選定返回階段本身是明示語義輸入，不是新自動切段公式**。核心不自動猜開始、結束或完整原箱。錯角色／候選／來源見證／階段時間拒用。

只分析as_of以前的K／MACD。全來源指紋是完整性metadata，數值事實及狀態只取前綴；追加／修改甚至弄壞未來OHLC不會改既有records／events。來源整檔／frame／result ID可因整檔前綴變動而不同，不能冒稱metadata也相同。狀態／事件ID不綁未來行情；最初突破、返回、轉弱與再次轉強都追加保存。日OHLC不推盤中先後。

已知／待核日曆缺口、缺價格或基底中斷自情境來源開始保守使結構不可判定；不沿價或在恢復資料後默認舊參照有效。必須另給有來源的新情境／角色版本，不做自動復活。缺量或MACD只列缺證，不虛構零值或擋已知價格事實。所有歷史公布可得／Raw完整公司行動限制保留。

## 真實案例資格

`examples/retained-case.json`只作**後來明示的研究角色案例**，不是演算法內硬寫日期／股票／答案。使用原1101五年Raw及B88（155筆來源、正式price_bounds仍null）。研究下緣20.25原K為2025-11-19；研究上緣26.95原K為2026-01-27，來源末轉折2026-07-14、確認2026-09-01與真正價位發生日分開。10/12收盤27.00越研究上緣、10/13收26.35返回；此次明示以10/13完成日高26.85作該返回階段的高點研究角色。**首次返回一日不是通用波段切法，也未獲使用者確認為完整回檔或正式原箱**。

依這組條件式參照，10/13整理、10/14轉強、10/15整理、10/16轉強；原突破10/12保留。真實此例沒有轉弱與收盤相等邊界；工程反例另存，絕不補行情湊齊。該研究角色不是原①④或G1/G2正式案例取代，不能因同價26.85借用5/13來源。來源定位、原精度與UI／JSON實際核對見主圖報告。

## 無網頁重現

完整repo先依AGENTS準備，在本專案目錄執行：

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m structure_state.build --data cross_scale_chart/generated/comparison-data.json --selection structure_state/examples/retained-case.json --as-of 2026-10-16 --output structure_state/output/new-result.json
```

或只用已交付的純輸入（不依賴網頁、原DB或indicator計算）：

```bash
python3 -m structure_state.cli --input facts-input.json --scenario scenario.json --as-of 2026-10-16 --output NEW-result.json
```

CLI以新檔寫入並讀回核等，既有不同輸出拒絕覆寫。不是正式signal store或交易帳，daily／journal／六方案未執行。

## 完成界線

已確認P0-3規則的工程接入不等自動選完整帶、主要壓力、全市場辨識、策略／勝率／換股或資金飛輪完成。人工Raw／Adjusted切換已有manual_basis／manual_basis_chart，不能再列為未實作；Adjusted仍限既有候選資料，缺者拒絕、不退Raw。新頁重用該功能。

正式來源0.10及全部parent、Raw／UNKNOWN、所有歷史成品與Fontconfig／xref警告不改。完整行動／權息、個人權利等缺口仍在，不作本輪P0-3工程無限來源研究前置條件。execution_qualified=false、imputed_close／valuation=null、historical_signal_eligible=false、primary_pressure_id=null、policy_authorized=false。分類品質NOT_VALIDATED／用途NOT_ESTABLISHED／行動與飛輪NOT_EVALUATED；Android NOT_TESTED_NEW_BUILD。全部已拒入口不重試或繞過，不部署付費交易訊息或子代理。
''')
(p/'structure_state_chart/README.md').write_text('''# P0-3：接入既有人工模式研究主圖

[獨立純數值附層](../structure_state/README.md)接到原manual_basis_chart；沿用人工Raw／Adjusted解析、不可fallback、localStorage與JSON選擇紀錄，以及原K／SMA／MACD與全部既有操作。未修改原頁、舊引擎、參數或來源。不是重做整套UI，也不是來源0.11。

[交付入口、直接可看的廣角／局部PNG及HTML／ZIP](../../deliveries/m1-p03-structure-state-20261024/README.md)。PNG可直接在GitHub查看，不要求使用者搬手機檔案、開終端或架伺服器。HTML為完整自含可重現成品，實際以臨時loopback HTTP驗證；原file://政策未重試，file://可用及Android實機不冒通過。沒有網站部署。

## 主圖操作

1. 按「開啟1101真實研究案例」明示選此Raw來源；或沿原人工模式選股票、模式、來源與精確日期。這個按鈕是選定固定案例，不是自動選股或系統代決價格模式。
2. 主圖列所選日狀態、回檔高點、研究箱下緣、狀態變更日／原因與支持／反面／缺證；24月486根、約五年1213根及局部31根可互切，K／量／MACD共窗共游標。畫窗不限制計算範圍，移圖／定位／查詢不改分析日。
3. 價格軸內畫對價水平線與來源K圓點；來源日期在畫外仍有線標籤。局部視窗20.25在軸外時只明示提示，不把它畫在錯價或壓扁近期K。點線標籤或狀態標記看來源與原過線事實。
4. 10/12最初突破保留；10/13整理→10/14轉強→10/15整理→10/16轉強可逐日／重播。證據抽屜以中文列事件路徑，完整ID與JSON折疊。原關卡／區域保留且可選疊加，預設關閉避免相同價位不同來源混淆，不改其數值。
5. 下載JSON保留原保存選擇、完整精度與目前分析日前的狀態／事件／參照資格。參照原始artifact綁定是後來選取來源，display source_binding與evaluated_prefix是所選日期的實際同源前綴；不把來源檔較晚frame冒成歷史當時已選。
6. 換股或模式只沿原manual_basis，不套用此案例到其他來源／基底。無P0-3明示角色顯示證據不足；缺Adjusted資料照舊UNAVAILABLE，不默轉Raw。

## 案例資格

真實行情，但B88正式邊界及此回檔階段角色沒有人工核定。這是明示研究參照下的條件式結構描述，主圖清楚標示，不是已通過全市場分類、完整原箱自動辨識或交易信號。回檔高點26.85出自10/13，與原④的5/13即使同價也不合併。研究箱下緣20.25原K為2025-11-19；來源末轉折、確認、角色可知與後來選取分開。

## 工程重現

根依最新AGENTS bootstrap成功後，在本專案目錄：

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p test_structure_state.py -v
PYTHONDONTWRITEBYTECODE=1 python3 -m structure_state_chart.build --output-dir structure_state_chart/output/NEW_EMPTY_LEAF
P03_ARTIFACT_DIR=structure_state_chart/output/NEW_EMPTY_LEAF CODEX_BROWSER_EXECUTABLE_PATH=/usr/bin/chromium node structure_state_chart/test_browser.cjs
```

可選`--data`與`--selection`明示其他同契約保存來源，不自動挑選或補參照；不同現有輸出拒絕覆寫。不是給一般使用者架伺服器的要求；正常查看直接用GitHub PNG。原父版0.4.3 ZIP先核SHA／CRC，interned數值JSON36,717,209 bytes／SHA a632ac6200b87f8fdc44d2a80c05056019f89e356e0815ec69ac2ad5287d3d30保持。MA／MACD沒有重算。

實際測試、視讀與所有失敗／修正／未測見[驗收報告](validation_20261024/驗收報告.md)。只原唯一Codex工程寫入，不改main；不部署付費交易訊息或子代理。原來源限制、false/null資格及Android NOT_TESTED_NEW_BUILD不變。
''')
# Keep raw execution logs from this turn, including intermediate runs, separately.
for name in ['bootstrap.log','build-initial.log','build-final.log','build-shipped.log','build-delivery.log','python-final.log','python-37-before-version-identity.log','reaction-regression.log','manual-basis-regression.log','pure-io-network-final.log','browser-initial.log','browser-final.log','browser-delivery.log','browser-final-complete.log','headless-verification.json','pan-diagnostic.json']:
 if (s/name).is_file():shutil.copyfile(s/name,v/name)
spec=importlib.util.spec_from_file_location('p03_test_fixture',p/'tests/test_structure_state.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from structure_state.core import evaluate
inp,scenario=m.fixture();out=evaluate(inp,scenario,as_of='2000-01-09')
eng=p/'structure_state/examples/engineering';eng.mkdir(exist_ok=True)
(eng/'counterexample.json').write_text(json.dumps(dict(qualification='ENGINEERING_SYNTHETIC_NOT_MARKET_DATA_OR_SAMPLE',facts_input=inp,scenario=scenario,result=out),ensure_ascii=False,indent=2)+'\n')
(eng/'README.md').write_text('工程合成反例，非市場行情或獨立樣本。涵蓋等高不突破、等底不跌破、破淺線未破底仍整理、真正破底與再轉強保留先前事件；與真實1101案例分開，不補真實缺少的弱勢／相等狀態。\n')
print('New core and chart contracts plus execution logs and separate engineering counterexample saved')
