from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import subprocess,json,hashlib,urllib.request,urllib.parse,datetime
repo=Path('/workspace/Twstockai');scratch=Path('/workspace/m1-p03-structure-state-20261024');commit='702e91447ff8c02950efe8edf508658e68aba45d'
paths=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','-z',commit],cwd=repo).decode().split('\0')[:-1]
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):return None
def read(path):
 expected=subprocess.check_output(['git','show',commit+':'+path],cwd=repo)
 url='https://raw.githubusercontent.com/blue1998-glitch/Twstockai/'+commit+'/'+urllib.parse.quote(path,safe='/')
 row=dict(path=path,url=url,requested_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),expected_bytes=len(expected),expected_sha256=hashlib.sha256(expected).hexdigest(),redirects_followed=False,retries=0)
 try:
  with urllib.request.build_opener(NoRedirect()).open(url,timeout=60) as r:row['http']=r.status;data=r.read()
  row.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),full_bytes_equal=data==expected,passed=row['http']==200 and data==expected)
 except Exception as e:row.update(passed=False,error=repr(e))
 row['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();return row
checks=[]
with ThreadPoolExecutor(max_workers=4) as pool:
 for f in as_completed([pool.submit(read,p) for p in paths]):
  checks.append(f.result())
  if len(checks)%20==0:print('fixed-commit files read',len(checks),'/',len(paths),flush=True)
checks.sort(key=lambda r:r['path'])
refs={r.split()[1]:r.split()[0] for r in subprocess.check_output(['git','ls-remote','origin','refs/heads/dev/m1-v018-chart-annotations','refs/heads/main'],cwd=repo,text=True).splitlines()}
package=json.loads((repo/'deliveries/m1-p03-structure-state-20261024/package-verification.json').read_text())
result=dict(scope='CONFIRMED_P03_STATE_ENGINE_AND_EXISTING_CHART_INTEGRATION_NOT_AUTOMATIC_BOX_OR_STRATEGY',fixed_engineering_commit=commit,parent_commit='ff532ce4a54d67bbafedb1fd2ec5bf54d18eb1b1',source_research_010_unchanged_commit='f423447c9396bfdd7c524f4c5f63173be1ebb47d',observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=len(checks),all_pass=all(r['passed'] for r in checks),remote_head=refs['refs/heads/dev/m1-v018-chart-annotations'],main_head=refs['refs/heads/main'],main_unchanged=refs['refs/heads/main']=='9c5b168c09ba80010c74f03b9c537e8b7474256a',new_source_011=False,unique_python_tests=dict(new=39,reaction=22,manual_basis=4,total=65),real_chromium_checks=94,repeated_checks_not_added=True,independent_real_conditional_case=1,package_bytes=package['bytes'],package_sha256=package['sha256'],physical_android='NOT_TESTED_NEW_BUILD',execution_qualified=False,historical_signal_eligible=False,primary_pressure_id=None,policy_authorized=False,checks=checks)
(scratch/'fixed-readback.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
assert result['all_pass'],[r for r in checks if not r['passed']]
assert result['main_unchanged'] and result['remote_head']==commit,refs
(repo/'deliveries/m1-p03-structure-state-20261024/GITHUB_READBACK.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False,indent=2))
