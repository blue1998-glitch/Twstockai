from pathlib import Path,PurePosixPath
import json,hashlib,subprocess,shutil,zipfile,datetime,tempfile,os
repo=Path('/workspace/Twstockai');root=repo/'股票系統M1_v0_18';scratch=Path('/workspace/m1-p03-structure-state-20261024');valid=root/'structure_state_chart/validation_20261024';deliver=repo/'deliveries/m1-p03-structure-state-20261024';deliver.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
# Capture actual preservation, never import old ledgers or run old research producers.
base=json.loads((scratch/'baseline.json').read_text());changed=[]
expected=['AGENTS.md','CONTINUE_IN_WORK_MODE.md','PROJECT_VISION.md','M1_V019_GRAPH_CORE_RESUME_HANDOFF.md','股票系統M1_v0_18/AGENTS.md','股票系統M1_v0_18/README.md','股票系統M1_v0_18/docs/CODEX交接.md']
for path,old in base['files'].items():
 data=(repo/path).read_bytes()
 if sha(data)!=old['sha256']:
  changed.append(path);assert path in expected,path
  assert data.endswith(subprocess.check_output(['git','show',base['head']+':'+path],cwd=repo)),path
assert sorted(changed)==sorted(expected)
preserve=dict(status='PASS',baseline_commit=base['head'],baseline_tracked_files=len(base['files']),unchanged_existing_files=len(base['files'])-len(changed),changed_existing_files=changed,all_old_documents_prepend_only=True,all_existing_engines_parameters_source_cases_catalogs_raw_unknown_databases_history_pages_and_archives_unchanged=True,untracked_full_byte_baseline_claimed=False,baseline_untracked_inventory=base['status'],main_expected=base['main'])
put(valid/'preservation.json',preserve)
# Directly readable artifacts and figures on GitHub.
art=deliver/'artifacts';art.mkdir(exist_ok=True)
for f in (root/'structure_state_chart/output/delivery').iterdir():
 if f.is_file():shutil.copyfile(f,art/f.name)
images=deliver/'images';images.mkdir(exist_ok=True)
for f in (valid/'browser-final').glob('*.png'):shutil.copyfile(f,images/f.name)
shutil.copyfile(repo/'M1_P03_STRUCTURE_STATE_HANDOFF.md',deliver/'WORK_HANDOFF.md')
# Archive all newly written engineering plus unchanged public dependencies needed
# to run headless P0-3 and rebuild this exact HTML in a fresh directory.
work=scratch/'package-tree';assert not work.exists();work.mkdir()
project=work/'project';pr=project/'股票系統M1_v0_18';pr.mkdir(parents=True)
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')[:-1]
source=[]
for rel in tracked:
 f=root/rel
 if f.is_file() and (f.suffix in ['.py','.js','.css'] or f.name.endswith('template.html')) and not any(x in f.relative_to(root).parts for x in ['generated','output']):source.append(f)
for folder in ['structure_state','structure_state_chart']:
 source += [f for f in (root/folder).rglob('*') if f.is_file() and not any(x in f.relative_to(root/folder).parts for x in ['output','validation_20261024','__pycache__'])]
source += [root/'tests/test_structure_state.py',root/'cross_scale_chart/generated/comparison-data.json']
for f in set(source):
 t=pr/f.relative_to(root);t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,t)
parent=repo/'deliveries/m1-v019-soft-regions-v043-20261019/M1_v019_soft_regions_v043.zip';t=project/parent.relative_to(repo);t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(parent,t)
shutil.copytree(art,work/'artifacts');shutil.copytree(images,work/'images');shutil.copytree(valid,work/'evidence');shutil.copyfile(repo/'M1_P03_STRUCTURE_STATE_HANDOFF.md',work/'WORK_HANDOFF.md')
(work/'REPRODUCE.md').write_text('''# P0-3完整新增工程與可重現成品

不是完整歷史專案，不要覆寫原checkout。一般使用者直接在GitHub看images廣角／局部PNG，不需終端、架站或手機搬檔。artifacts有自含HTML、完整精度JSON與顯式輸入。工程來源及固定公開父版位於project，未改原來源、舊指標、引擎或策略，不是來源0.11。

在全新目錄解壓後，工程重現（Python標準庫）：

```bash
cd project/股票系統M1_v0_18
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p test_structure_state.py -v
PYTHONDONTWRITEBYTECODE=1 python3 -m structure_state.cli --input ../../artifacts/facts-input.json --scenario ../../artifacts/scenario.json --as-of 2026-10-16 --output structure_state/output/new-headless.json
PYTHONDONTWRITEBYTECODE=1 python3 -m structure_state_chart.build --output-dir structure_state_chart/output/new-html
```

新HTML及JSON應與artifacts完整bytes相同；不要在此包跑無關舊全套測試。HTML重建重用已存公開0.4.3父ZIP及原cross-scale資料，無新行情／來源GET或MA／MACD／graph_core重算。來源包已含所需原碼與資料；工程回原完整repo仍依AGENTS bootstrap。file://／Android未驗，不重試已拒政策。核心／來源／效益限制與完整下一輪Work唯讀指令見WORK_HANDOFF。
''')
files=sorted(f for f in work.rglob('*') if f.is_file());entries=[dict(path=str(f.relative_to(work)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())) for f in files]
put(work/'MANIFEST.json',dict(schema='p03-reproducible-package-manifest/0.1',members=entries,manifest_excludes_self=True,container_timestamp_not_observation_time=True))
name='M1_P03_structure_state_v01_20261024.zip';archive=deliver/name
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(files+[work/'MANIFEST.json']):
  info=zipfile.ZipInfo(str(f.relative_to(work)),date_time=(2026,10,24,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,f.read_bytes(),compresslevel=9)
# Fresh extraction, every member, then actual headless + source + HTML rebuild.
with tempfile.TemporaryDirectory(prefix='p03-extracted-',dir=scratch) as temp:
 fresh=Path(temp)
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  names=z.namelist();assert len(names)==len(set(names))
  assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n for n in names)
  manifest=json.loads(z.read('MANIFEST.json'));assert set(names)=={m['path'] for m in manifest['members']}|{'MANIFEST.json'}
  for row in manifest['members']:
   b=z.read(row['path']);assert len(b)==row['bytes'] and sha(b)==row['sha256']
  z.extractall(fresh)
 before={n:sha((fresh/n).read_bytes()) for n in names}
 cwd=fresh/'project/股票系統M1_v0_18';env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');runs=[]
 commands=[('core-tests',['python3','-m','unittest','discover','-s','tests','-p','test_structure_state.py','-v']),('headless',['python3','-m','structure_state.cli','--input',str(fresh/'artifacts/facts-input.json'),'--scenario',str(fresh/'artifacts/scenario.json'),'--as-of','2026-10-16','--output',str(fresh/'new-headless.json')]),('rebuild-html',['python3','-m','structure_state_chart.build','--output-dir','structure_state_chart/output/reproduced'])]
 for label,command in commands:
  result=subprocess.run(command,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (deliver/(label+'-extracted.log')).write_bytes(result.stdout)
  runs.append(dict(label=label,command=command,returncode=result.returncode,log=label+'-extracted.log'))
  assert result.returncode==0,(label,result.stdout.decode()[-3000:])
 assert (fresh/'new-headless.json').read_bytes()==(fresh/'artifacts/structure-state.json').read_bytes()
 rebuild=cwd/'structure_state_chart/output/reproduced'
 rebuilt=[]
 for f in (fresh/'artifacts').iterdir():
  assert (rebuild/f.name).read_bytes()==f.read_bytes(),f.name
  rebuilt.append(f.name)
 assert before=={n:sha((fresh/n).read_bytes()) for n in names}
receipt=dict(status='PASS',scope='CURRENT_P03_ENGINE_UI_REPRODUCTION_NOT_MARKET_ACCURACY_OR_ANDROID',filename=name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),members=len(names),manifest_entries=len(entries),crc_unique_safe_paths=True,all_member_lengths_sha_verified=True,new_extraction_runs=runs,headless_exact_bytes_equal=True,rebuilt_files_exact_bytes_equal=rebuilt,archive_members_unchanged=True,current_unique_python_tests=dict(new=39,reaction_regression=22,manual_basis_regression=4,total=65),new_extraction_same_39_not_added_again=True,browser_checks=94,physical_android='NOT_TESTED_NEW_BUILD',file_policy_not_retried=True,source_version_011_created=False,new_market_data_or_net_performance=False)
put(deliver/'package-verification.json',receipt);(deliver/'SHA256SUMS').write_text(receipt['sha256']+'  '+name+'\n')
put(deliver/'artifact-manifest.json',dict(files=[dict(path=str(f.relative_to(deliver)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())) for f in sorted([*art.iterdir(),*images.iterdir()]) if f.is_file()]))
(deliver/'README.md').write_text(f'''# 已確認P0-3結構狀態｜真實研究主圖交付

**主線已回核心功能；不是來源0.11或自動選箱策略。** 原人工Raw／Adjusted切換已完成並重用，不重新列未實作。

## 直接看圖，不用架伺服器或搬手機檔案

- [桌面廣角24月／486根](images/wide-1280.png)　[局部放大／31根](images/local-1280.png)
- [手機直向廣角](images/wide-390.png)　[直向局部](images/local-390.png)
- [手機橫向廣角](images/wide-844.png)　[橫向局部](images/local-844.png)

以上是真實Chromium輸出的PNG，可直接在GitHub看。圖有所選日結構狀態、來源高點／研究箱底、支持／反面／缺證；同K／量／MACD、軸外提示與原突破／狀態標記。手機模擬不等Android實機。

## 下載與完整精度

- [下載可重現HTML／JSON／完整新增工程ZIP]({name}?raw=true)：{receipt['bytes']:,} bytes，{receipt['members']}成員／{receipt['manifest_entries']}項manifest。
- SHA256：`{receipt['sha256']}`；[SHA256SUMS](SHA256SUMS)、[實際CRC／全成員／新目錄重建驗證](package-verification.json)。
- [自含HTML](artifacts/M1_P03_structure_state_v01.html?raw=true)、[完整狀態JSON](artifacts/structure-state.json)、[明示角色與來源](artifacts/role-selection.json)、[純輸入](artifacts/facts-input.json)、[情境](artifacts/scenario.json)、[chart-layer](artifacts/chart-layer.json)。
- [完整工程交接／可貼Work指令](WORK_HANDOFF.md)、[純核心契約](../../股票系統M1_v0_18/structure_state/README.md)、[實測報告](../../股票系統M1_v0_18/structure_state_chart/validation_20261024/驗收報告.md)、[固定逐檔GitHub原bytes讀回](GITHUB_READBACK.md)／[JSON](GITHUB_READBACK.json)。

HTML單檔自含，按「開啟1101真實研究案例」→廣角／局部→日期／重播→點標記／來源證據→下載JSON。一般查看先用上述PNG，不要求終端或伺服器；HTML實測為臨時loopback HTTP，file://原政策與Android未驗，不冒通過，無新網站部署。ZIP不是完整歷史專案，不要覆寫原checkout；其中project含重建本成果所需工程來源、未改的公開parent與固定資料。全新解壓實際39核心測試、無網頁CLI、HTML／所有輸出重建均成功且完整bytes相同；同39不再加總。

## 真實案例的精確界線

1101原Raw1213根到2026-10-16。B88只研究候選，正式邊界仍null，不冒人工核定原箱或完整回檔。此次後來明示10/13高26.85為返回階段高點研究提案，原箱下緣研究20.25；原K、來源末轉折、確認／角色可知與選取分開。10/12原突破保留；在此條件下10/13整理、14轉強、15整理、16轉強。真實案例沒有轉弱與相等收盤，工程反例另存，非市場樣本，不造行情湊齊。原④5/13的26.85不是本次10/13來源，不合併。

本輪65個唯一Python範圍（39新＋22反應事實／4模式回歸），最後94項真實Chromium三視窗檢查通過；早期子集、71檢查／重驗／新解壓不重複累加。失敗／修正保存於驗收資料；不是策略準確率、歷史當時訊號、Android或獲利驗證。

原引擎策略／庫／歷史、來源0.10及全部parent、Raw null／UNKNOWN、舊頁成品警告與main保持，不建立來源0.11或回寫null。未完成自動完整帶／主要壓力、全市場識別、正式策略／換股／資金飛輪；完整公司行動／個人權利等缺口及全部false/null資格不解除，沒有每日淨帳／六方案新績效。下一步只Work看真實圖與用途差異；不重問已答P0-3、不回到無限來源研究、不部署付費交易訊息或子代理。
''')
print(json.dumps({k:v for k,v in receipt.items() if k!='new_extraction_runs'},ensure_ascii=False,indent=2))
