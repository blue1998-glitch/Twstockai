from pathlib import Path
import json,datetime,hashlib,shutil
r=Path('/workspace/Twstockai');p=r/'股票系統M1_v0_18';s=Path('/workspace/m1-p03-structure-state-20261024');v=p/'structure_state_chart/validation_20261024'
b=json.loads((v/'browser-final/browser-report.json').read_text());assert b['status']=='PASS' and b['checks']==94
for name in ['browser-final-complete.log','headless-verification.json','pure-io-network-final.log']:
 shutil.copyfile(s/name,v/name)
(v/'驗收報告.md').write_text('''# P0-3結構狀態與既有主圖接入驗收｜2026-10-24

## 實際準備與保留

原既有唯一Codex接續ff532ce4a54d67bbafedb1fd2ec5bf54d18eb1b1；遠端含固定年報d5d506ee、CTBC519e0a25、來源0.10 f423447及全部後續，開始main仍9c5b168c09ba80010c74f03b9c537e8b7474256a。根／適用子AGENTS及指定四份人工裁決、manual_basis全原碼／主圖／報告、reaction_facts原碼與graph_core／chart README已讀。依最新AGENTS重新bootstrap成功0補缺／7既有差異保留，才新增工程。

現況對照：manual_basis／manual_basis_chart的人工Raw／Adjusted解析及保存已有完成，不重做；reaction_facts有三態與路徑，沒有角色／P0-3狀態；graph_core／graph_core_chart仍研究候選，不等完整正式價格帶或主要壓力。這輪新增structure_state純附層與structure_state_chart增量渲染，未改原引擎、策略、參數、庫、數值契約、來源0.10與parent、歷史或舊頁。原來源缺口不作無限研究版本的前置條件。

## 真實保存案例與資格

1101五年Raw1213根，2021-10-18～2026-10-16；原comparison-data.json及parent0.4.3解碼數值JSON以SHA固定，原K／MA／MACD逐值核等，沒有重算指標。原始來源與prefix／frame／basis、候選及原K見證在source-lineage.json、role-selection.json及JSON結果中。

B88只是既有研究候選，source2025-11-19～2026-07-14／確認2026-09-01；研究下緣20.25的原K為2025-11-19，研究上緣26.95原K2026-01-27。正式price_bounds仍null。10/12收盤27.00嚴格越研究上緣、10/13收26.35返回；**本次後來明示**選10/13完成日高26.85作返回階段高點研究角色，不是系統自動選最近pivot，不是使用者已核完整回檔或正式原箱。原④5/13即使也26.85，不借用來源、不合併。選取時間與原值／角色可知分開，historical_selection_time仍null。

|真實保存分析日|實際收盤|本組研究角色下狀態|原因|
|---|---|---|---|
|2026-10-12|27.00|證據不足／不可判定|返回階段及回檔高點角色尚不可知；原突破事件保留|
|2026-10-13|26.35|整理|未越26.85且未破20.25|
|2026-10-14|27.05|轉強|收盤嚴格大於26.85|
|2026-10-15|26.80|整理|未越26.85且未破20.25|
|2026-10-16|27.30|轉強|收盤嚴格大於26.85|

完整輸出1213日中1209日證據不足，2日轉強、2日整理；這是**一個條件式來源案例**，不把日數或事件數當獨立樣本／準確率。真實此例沒有轉弱與相等收盤邊界；獨立工程合成反例另存structure_state/examples/engineering，明示ENGINEERING_NOT_MARKET，不造行情補齊。

## 本輪實際測試

|範圍|本輪結果|
|---|---|
|新增P0-3純數值／來源／時間因果／CLI|39 tests PASS（python-final.log）|
|實跑reaction_facts相關回歸|22 tests PASS（reaction-regression.log）|
|實跑manual_basis解析／不可fallback／journal回歸|4 tests PASS（manual-basis-regression.log）|
|最後強化無檔案／網路核心檢查|同一項定向重驗PASS，不再加總成第40項|
|真實Chromium154.0.8037.57／HTTP／1280×1000、390×844、844×390|最後94項檢查PASS（browser-final/browser-report.json）|
|無網頁真實來源CLI重播|與交付structure-state.json完整bytes相同，3339350bytes／SHA37a75a6979fb5d101323bc1b4498ca63aec437d6c2f118c0589877c22242710d|

唯一Python測試範圍是39新＋26相關回歸＝65，不把先前32／37子集、定向重驗或解壓後同輸入讀回重複加總。最初71項舊介面行為檢查與中間71項只屬中間版本，不能取代最後94項，也不相加。原歷史53與70／2／8／合格0及全套舊測試沒有重跑。

測試實際涵蓋：嚴格大小／相等、破淺線未破底不判弱、量少／MACD負值不取消過線、缺量／暖機另列、缺角色、錯角色／原欄位／artifact／候選K見證／基底／版本、尚不可知／失效、原箱幾何矛盾、初始突破需有相鄰收盤證據、缺價／日曆／基底中斷保守拒判、追加／修改甚至弄壞未來OHLC不改舊records／events、轉弱後再轉強不刪歷史、同日兩影線不推盤中順序、超長小數精度及無IO／不改輸入。

94項真實瀏覽器檢查含：沿用人工模式、精確Raw與Adjusted來源及缺者不可fallback、四日狀態／事件／JSON oracle一致、10/12不得洩漏10/13高點、24月486／五年1213／局部31根、K量MACD同窗同游標、實際拖曳查詢／移圖與手機模擬觸控放大、源K定位不跳分析日、原突破標記及舊疊圖可選但不改狀態、箱底超軸不錯貼、實際下載三份JSON對直接匯出與Python當日輸出、四日重播、橫向無溢位、JS錯誤0／外部網路請求0。手機模擬不是Android實機。

## 可見畫面及修正紀錄

browser-final有桌面／直向／橫向廣角和局部PNG共6張，已實際視讀桌面局部、直向廣角／局部及橫向局部，桌面廣角亦核其前同值畫面。中文Noto CJK已存在，沒有新抓字型；這不回寫舊manual_basis報告缺字型的歷史狀態。直接GitHub圖片入口在delivery，不要求使用者架站／開終端／手機搬檔。HTML為單檔自含，實測用僅測試期間的loopback HTTP，未部署任何網站。

保留失敗與修正：初版截圖在捲頁後以錯誤clip座標裁切，71項行為PASS不能當可見截圖合格；改為scroll0＋fullPage精確clip，保留browser-initial與中間browser。後來擴充實際拖曳時，390畫面送出y922卻只有844高，未觸及canvas而斷言失敗；pan-diagnostic.json實核rect.y752，捲入畫布後y397，同動作start1182→1174、分析日不變。修正測試在選操作模式後將canvas捲入可視區再取座標，最後94項通過；未調引擎或關掉斷言。browser-delivery/browser-failure.json與原log保留。另文件輔助器由scratch啟動因sys.path找不到graph_core，加入實際專案root後成功，屬輔助腳本錯誤，不冒產品測試失敗或通過。

## 未完成與限制

P0-3工程已接入，不等全自動選完整帶、主要壓力、正式原箱／回檔角色品質、全市場識別、勝率、換股策略或資金飛輪完成。已答規則不重問；只有新且真正影響核心的歧義才配充分真圖詢問。

未取得：本輪不取得舊Work研究ZIP／原meta／經濟部函／私人權利原件；未讀：未取得資料及原101圖不重讀；未實作：自動選箱／完整價格帶／主壓力及正式策略；未執行：新來源GET、每日淨帳／六方案／獲利驗證／無關舊全套；未測：Android實機、file://政策、完整還原與全市場用途；未讀回：舊Work原封包，本次新工程固定逐檔GitHub讀回另記delivery收據。

來源0.10及全部parent、完整公司行動／區間權息／個人實配畸零／換股影響／台泥最細稅源／個人淨額／九起點權利缺口保持；Raw／五年Adjusted／歷史公布／主檔／SQLite未知。execution_qualified=false、imputed_close／valuation=null、historical_signal_eligible=false、primary_pressure_id=null、policy_authorized=false；Android NOT_TESTED_NEW_BUILD。已存年報CTBC／公開說明書／ZIP／舊圖與全部拒絕入口均未重抓重試。不部署、付費、交易、訊息或子代理。
''')
lineage=json.loads((p/'structure_state_chart/output/delivery/build-verification.json').read_text())
lineage.update(original_comparison_artifact_id=json.loads((p/'cross_scale_chart/generated/comparison-data.json').read_text())['artifact_id'],raw_price_qualification='UNVERIFIED_CORPORATE_ACTION_COMPARABILITY_NOT_COMMON_ADJUSTED_PRESSURE',historical_publication='UNVERIFIED',independent_real_cases=1,production_core_contains_case_stock_or_dates=False)
(v/'source-lineage.json').write_text(json.dumps(lineage,ensure_ascii=False,indent=2)+'\n')
(v/'execution-diagnostic.json').write_text(json.dumps(dict(first_core_suite_subset=32,final_new_core_tests=39,related_reaction_regression=22,related_manual_basis_regression=4,unique_python_test_scope=65,additional_io_network_recheck_not_added_to_count=True,initial_browser_checks=71,intermediate_browser_checks=71,final_browser_checks=94,old_checks_not_added_together=True,initial_screenshot_clipping='VISUAL_QA_FAILED_CORRECTED_SCROLL0_FULLPAGE_CLIP',expanded_browser_failure='POINTER_SENT_OUTSIDE_MOBILE_VIEWPORT',proof='pan-diagnostic.json',corrected='SCROLL_CANVAS_INTO_VIEW_AFTER_MODE_SELECTION_THEN_MEASURE',final_browser_status='PASS',source_or_strategy_parameter_changed_to_make_tests_pass=False,documentation_helper_failure='ModuleNotFoundError graph_core because scratch helper directory was on sys.path',documentation_helper_resolution='Insert actual project root before importing engineering fixture',physical_android='NOT_TESTED_NEW_BUILD',file_policy='NOT_RETRIED_OR_BYPASSED'),ensure_ascii=False,indent=2)+'\n')
# Retain old body bytes; the new highest entry correctly marks prior mode work complete.
prefix='''# 2026-10-24 Codex｜回到核心：P0-3結構狀態已接入既有人工模式主圖

本輪依最新使用者指令將主線由來源研究轉回已確認核心工程。`manual_basis/`／`manual_basis_chart/`的人工Raw／Adjusted模式切換已有完成，不重做，也不再列未實作；較早「未證／尚未整合」段落保留為其當時狀態。新增 `股票系統M1_v0_18/structure_state/` 純數值P0-3附層及 `structure_state_chart/` 增量主圖，重用reaction_facts三態／路徑與原模式路由；原K／MA／MACD數值樹不改。最新完整接續 `M1_P03_STRUCTURE_STATE_HANDOFF.md`；直接廣角／局部PNG、HTML／JSON／ZIP與固定原bytes讀回見 `deliveries/m1-p03-structure-state-20261024/README.md`。

有效明示參照下：收盤嚴格過回檔高點轉強；未過也未破原箱底整理；嚴格破箱底轉弱。相等獨立保留、不當越過或跌破；淺回檔線不作硬性判弱界，量／MACD另列不否定過線。缺來源／角色／時序／同基底版本或中斷／矛盾就證據不足；核心無UI／IO，來源／角色可知與後來選取分開，未來資料不回寫舊狀態事件，保留最初突破與先前轉弱，不推盤中先後。

真實1101原Raw1213根及B88僅明示研究角色，正式price_bounds仍null，非人工核定原箱。研究上緣26.95與下緣20.25原K／來源末轉折／確認各分存；10/13高26.85作單次返回階段研究提案，不借原④5/13同價，不是通用選高公式。條件式10/13整理→14轉強→15整理→16轉強；10/12原突破保留，實例無轉弱／相等，工程反例另存非行情。核心規則工程完成不等自動完整帶／主要壓力、全市場、勝率、換股或資金飛輪完成。

本輪39新＋22 reaction／4模式相關回歸＝65個Python唯一測試範圍，Chromium154最後94檢查PASS；早期32／37子集、71介面檢查及重驗不累加。實際三視窗、拖曳／移圖／觸控放大、同步、定位、下載與重播已驗，首截圖裁切及手機測試座標越出視野的失敗／修正保留。無網頁真實CLI輸出與成品結果完整bytes相同；新Android仍NOT_TESTED_NEW_BUILD，file://不重試。圖中文字型當前可讀不抹舊Fontconfig／xref。

來源0.10及全部parent、策略參數／舊引擎、庫、Raw null／UNKNOWN、原件、歷史／舊成品及main保持；不建來源0.11或重複catalog，不回寫null。完整公司行動／權息／個人權利／淨分配及九起點等缺口不解除，也不作本輪工程無限前置。execution_qualified=false、imputed_close／valuation=null、historical_signal_eligible=false、primary_pressure_id=null、policy_authorized=false；不跑每日淨帳／六方案／績效，全部受拒入口及舊來源未重試重抓。

下一步只Work看新真實廣角／局部與用途差異，完整可貼指令在M1_P03_STRUCTURE_STATE_HANDOFF；不重問P0-3或轉回無限來源歸檔。Work唯讀，不bootstrap／工程／測試／寫入；真正新核心歧義才配充分真圖詢問，明確缺陷交回原唯一Codex。無子代理、不改main、不部署付費交易訊息。以下歷史原文完整保留。

---

'''
for name in ['AGENTS.md','CONTINUE_IN_WORK_MODE.md','M1_V019_GRAPH_CORE_RESUME_HANDOFF.md','PROJECT_VISION.md']:
 f=r/name;body=f.read_bytes();assert not body.startswith(prefix[:40].encode());f.write_bytes(prefix.encode()+body)
sub='''> 2026-10-24最新：P0-3獨立結構狀態與既有人工模式主圖已接入，讀structure_state/README.md、structure_state_chart/README.md及validation_20261024/驗收報告.md，直接PNG／HTML／JSON／ZIP入口在root deliveries/m1-p03-structure-state-20261024。manual_basis／manual_basis_chart模式切換已實作，不重做；新附層只接受明示來源角色，不等自動選帶或正式策略。真實B88案例是研究角色提案，非人工核定原箱；39新＋26相關Python／94 Chromium實跑通過，Android未測，全部原來源／引擎／庫／歷史限制保持。最新完整Work指令見root M1_P03_STRUCTURE_STATE_HANDOFF.md；下方歷史原文保留。

'''
for name in ['AGENTS.md','README.md','docs/CODEX交接.md']:
 f=p/name;f.write_bytes(sub.encode()+f.read_bytes())
(r/'M1_P03_STRUCTURE_STATE_HANDOFF.md').write_text('''# P0-3工程完成：交回Work看真實圖與用途差異

新固定工程及最新已核提交以deliveries/m1-p03-structure-state-20261024/GITHUB_READBACK.md／JSON及最後回覆為準；來源工程提交與收據另存，避免自指SHA。當前是核心狀態附層0.1，不是來源0.11。

```text
接續 blue1998-glitch/Twstockai，分支 dev/m1-v018-chart-annotations。
先唯讀核包含ff532ce4a54d67bbafedb1fd2ec5bf54d18eb1b1、其後P0-3固定工程與讀回收據；固定年報d5d506eec77e36c63e496e6c5f1daed9d25f0216、CTBC519e0a25eb34bb7358be895c54946d02e945ad92、來源0.10 f423447c9396bfdd7c524f4c5f63173be1ebb47d及全部後續保留。不回退、強推或用main／舊ZIP覆蓋。

本輪只用Work做新成品／GitHub唯讀與用途差異檢視，不bootstrap、工程、產品測試、commit／push，不另開Codex／子代理。工程仍由原既有唯一Codex處理。主線已回核心，不把來源缺口當任何圖形功能都不能做的前置，不為湊版本補來源0.11。

讀根AGENTS、CONTINUE_IN_WORK_MODE、PROJECT_VISION、M1_V019_GRAPH_CORE_RESUME_HANDOFF最新節及本文件全文；讀structure_state/README與core.py／source.py／examples/retained-case.json，structure_state_chart/README、validation_20261024/驗收報告、source-lineage／execution-diagnostic／browser-final報告；再讀delivery README、package-verification及GITHUB_READBACK MD／JSON。

先直接看delivery廣角24月與局部PNG，桌面、手機直／橫向都有，不要求使用者手機搬檔、開終端或架伺服器。HTML自含可重現、JSON完整原精度與source指紋均已保存；loopback HTTP真實瀏覽器測試不是部署，也不是file://或Android已通過。Work若無法讀原件就列未讀，不用報告冒實看圖。

人工Raw／Adjusted切換已有manual_basis／manual_basis_chart工程及既有驗收，不重新列未實作。新P0-3只重用它及reaction_facts的原close/high/low三態／完整路徑，未改原K、SMA、MACD數值樹、策略參數、graph_core或任何舊頁。只接受明示有效角色，不自動選完整箱或主要壓力。

已確認P0-3不要重問：有效同源／基底／版本且當時可知角色下，收盤嚴格過回檔高點轉強；未過且未破箱底整理；嚴格破箱底轉弱。相等另存不能當越過／跌破；淺回檔線不是硬性失效線；量／MACD另列支持反面缺證，不以未放量取消過線。缺角色／未知／失效／錯基底／中斷／矛盾顯示證據不足，不自造天數、百分比、量倍數、OSC或主壓力門檻。原值發生／可知、角色可知、來源末轉折／確認、實際後來選取分開；不推盤中先後，追加未來不回寫過去事件。

本輪真實1101 Raw1213根到2026-10-16，廣角24月486根、局部31根。原B88來源2025-11-19～2026-07-14、確認9/1；下緣20.25原K11/19、上緣26.95原K1/27。B88正式price_bounds仍null，不能冒正式人工原箱；這是研究角色假設。10/12收27.00過研究上緣，10/13收26.35返回；本次後來明選10/13完成日高26.85作返回階段高點提案，不是自動找最近pivot或使用者已核完整回檔，不能借原④5/13的同價來源。核心無案例股票／日期硬碼。

條件式狀態：10/12返回參照未可知所以證據不足，但最初突破保留；10/13整理、10/14轉強、10/15整理、10/16轉強。真實此例沒有轉弱或收盤相等，工程反例另存非市場行情，不補真行情湊答案。圖上箱底超軸只提示、不錯貼或壓扁K；原關卡可選疊加但不改狀態。點標記／狀態證據可看來源與中文事件路徑。

本Codex實際39新＋22反應事實／4模式相關回歸＝65唯一Python範圍，最後Chromium154三視窗94檢查PASS，含實際拖曳、移圖、觸控放大、同軸游標、日期／模式／來源無fallback、逐日oracle、保留原突破、原K定位不跳分析日、精確下載／重播／無橫溢與JS錯誤。初版截圖裁切、手機測試座標超出視窗、文件輔助器sys.path失敗與修正都留史。舊32／37子集、71檢查或新解壓同輸入不加總；Work沒有替Codex重跑。原歷史53／70／2／8／合格0不是本輪執行。

只檢視真實圖的用途差異：狀態與依據是否清楚、完整廣角與局部能否理解、原突破／返回／再次轉強是否可追溯、量與MACD是否被誤作取消過線。明分核心規則工程完成與參照選取品質尚未驗；不用「畫出點線」冒全市場完整辨識、策略或獲利完成。已有P0-3答案與例行工程選擇不丟回使用者；只有真正新且影響核心行為的歧義才附足夠廣角／局部真圖提出具體問題，明確可復現缺陷交回原唯一Codex。

正式來源0.10及全部parent、Raw／UNKNOWN／所有舊版本、引擎、庫、歷史成品與Fontconfig／xref警告保持。不建來源0.11／重複catalog、不回寫parent null、不重抓年報／CTBC／公開說明書／ZIP／舊圖。全部已拒入口、library與嘉新逾時路徑不重試、不換主機路徑繞過，不因unrestricted解禁。私人原件不公開、不補零、行情、前價或估值。

完整公司行動／指定期間權息、個人實配畸零／換股影響、台泥最後調整／最細稅源、個人淨分配及九期初權利仍缺；九起點均2026年01-02、02-02、03-02、04-01、05-04、06-01、07-01、08-03、09-01。不由起點持股或公司總額推個人權利；不跑每日淨帳、六方案或稱已驗獲利。execution_qualified=false；imputed_close／valuation=null；historical_signal_eligible=false；primary_pressure_id=null；policy_authorized=false。Raw／五年Adjusted／歷史公布／主檔／SQLite未知，全換／分批仍研究變數；Android NOT_TESTED_NEW_BUILD。

最後交實際看過的圖／JSON與用途差異，分列已完成及未取得／未讀／未實作／未執行／未測／未讀回，只選一個下一執行對象並附完整指令。不部署、付費、交易、發訊息或啟動子代理。
```
''')
print('Final actual 65 Python / 94 Chromium scope, failure history, root progress and full Work handoff saved')
