# P0-3完整新增工程與可重現成品

不是完整歷史專案，不要覆寫原checkout。一般使用者直接在GitHub看images廣角／局部PNG，不需終端、架站或手機搬檔。artifacts有自含HTML、完整精度JSON與顯式輸入。工程來源及固定公開父版位於project，未改原來源、舊指標、引擎或策略，不是來源0.11。

在全新目錄解壓後，工程重現（Python標準庫）：

```bash
cd project/股票系統M1_v0_18
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p test_structure_state.py -v
PYTHONDONTWRITEBYTECODE=1 python3 -m structure_state.cli --input ../../artifacts/facts-input.json --scenario ../../artifacts/scenario.json --as-of 2026-10-16 --output structure_state/output/new-headless.json
PYTHONDONTWRITEBYTECODE=1 python3 -m structure_state_chart.build --output-dir structure_state_chart/output/new-html
```

新HTML及JSON應與artifacts完整bytes相同；不要在此包跑無關舊全套測試。HTML重建重用已存公開0.4.3父ZIP及原cross-scale資料，無新行情／來源GET或MA／MACD／graph_core重算。來源包已含所需原碼與資料；工程回原完整repo仍依AGENTS bootstrap。file://／Android未驗，不重試已拒政策。核心／來源／效益限制與完整下一輪Work唯讀指令見WORK_HANDOFF。
