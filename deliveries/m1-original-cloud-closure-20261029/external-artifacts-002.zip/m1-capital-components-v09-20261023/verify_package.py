from pathlib import Path
import hashlib,json,subprocess,zipfile

ROOT=Path('/workspace/Twstockai');WORK=Path('/workspace/m1-capital-components-v09-20261023')
DEL=ROOT/'deliveries/m1-capital-components-20261023';target=DEL/'m1-capital-components-v09-20261023.zip'
out=WORK/'fresh-extracted';out.mkdir(exist_ok=False)
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
 assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
 members={n:z.read(n) for n in z.namelist()};z.extractall(out)
with zipfile.ZipFile(ROOT/'deliveries/m1-source-contracts-20261023/m1-source-contracts-v08-20261023.zip') as z:
 assert len(z.namelist())==693 and all(members[n]==z.read(n) for n in z.namelist())
manifests={}
for n,b in members.items():
 if n.endswith('_MANIFEST.json'):
  m=json.loads(b);assert all(hashlib.sha256(members[f]).hexdigest()==sha for f,sha in m.items());manifests[n]=len(m)
assert len(manifests)==11
commands=[['python3','-m','unittest','rotation_research.test_capital_components','rotation_research.test_source_contracts','-v'],['python3','-m','rotation_research.capital_components_sources']]
results=[]
for args,name in zip(commands,['extracted-tests.log','extracted-producer.log']):
 p=subprocess.run(args,cwd=out/'股票系統M1_v0_18',capture_output=True,text=True);(DEL/name).write_text(p.stdout+p.stderr)
 results.append(dict(command=args,returncode=p.returncode,log=name));assert p.returncode==0,name
assert 'Ran 60 tests' in (DEL/'extracted-tests.log').read_text()
assert all((out/n).read_bytes()==b for n,b in members.items())
v=json.loads((out/'股票系統M1_v0_18/rotation_research/capital_components_20261023/verification.json').read_text())
assert (v['qualification_calls'],v['refused_windows'],v['insufficient_windows'],v['exchange_unsupported_windows'],v['qualified_total_net_return_windows'])==(70,70,2,8,0)
missing=json.loads((out/'股票系統M1_v0_18/rotation_research/capital_components_20261023/missing-quotes.json').read_text())['diagnostics']
assert len(missing)==2 and all(d['raw_close'] is None and d['parent_diagnostic']['parent_diagnostic']['new_missing_explanation']=='UNKNOWN' and d['parent_diagnostic']['new_missing_explanation']=='DIRECT_OFFICIAL_SUSPENSION_START_ON_DATE' and not d['execution_qualified'] and d['suspension_end_date'] is None for d in missing)
result=dict(status='PASS',filename=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),members=len(members),
 parent_v08_members_byte_exact=693,manifests=manifests,commands=results,actual_distinct_tests=60,
 new_tests=29,old_tests_actually_rerun=31,all_bundle_members_unchanged_after_test_and_producer=True,
 exact_original_bridge_zip_included=True,missing_quotes_new_evidence_and_old_unknown_preserved=True,offline_producer_verification=v)
(DEL/'package-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result))
