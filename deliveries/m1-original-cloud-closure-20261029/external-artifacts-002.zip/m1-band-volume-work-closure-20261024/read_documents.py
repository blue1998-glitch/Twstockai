import concurrent.futures,datetime,hashlib,json,subprocess,urllib.request,urllib.parse
from pathlib import Path
ROOT=Path('/workspace/Twstockai');SCRATCH=Path('/workspace/m1-band-volume-work-closure-20261024')
BASE=json.loads((SCRATCH/'baseline.json').read_text())
FIXED='0df19d88abb20ae89b9082beb42433de9c394225'
PATHS=json.loads((SCRATCH/'documentation-check.json').read_text())['only_documentation_paths_changed']
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
OPENER=urllib.request.build_opener(NoRedirect())
def read_one(path):
 expected=git('show',FIXED+':'+path)
 url='https://raw.githubusercontent.com/blue1998-glitch/Twstockai/'+FIXED+'/'+urllib.parse.quote(path,safe='/')
 started=now()
 req=urllib.request.Request(url,headers={'User-Agent':'Twstockai-documentation-readback','Cache-Control':'no-cache'})
 with OPENER.open(req,timeout=45) as response:
  actual=response.read();status=response.status;headers={key:response.headers.get(key) for key in ['Content-Type','Content-Length','Date','ETag','Last-Modified'] if response.headers.get(key) is not None}
  final_url=response.url
 completed=now()
 assert status==200 and final_url==url
 assert actual==expected,path
 return {'path':path,'url':url,'requested_at':started,'completed_at':completed,'http_status':status,'safe_headers':headers,'expected_bytes':len(expected),'actual_bytes':len(actual),'sha256':hashlib.sha256(actual).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(actual)).encode()+b'\0'+actual).hexdigest(),'exact_bytes_equal_fixed_git_blob':True}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:files=list(pool.map(read_one,PATHS))
refs=dict(line.split('\t')[::-1] for line in git('ls-remote','origin','refs/heads/dev/m1-v018-chart-annotations','refs/heads/main').decode().splitlines())
assert refs['refs/heads/dev/m1-v018-chart-annotations']==FIXED
assert refs['refs/heads/main']==BASE['remote']['refs/heads/main']
assert set(git('diff','--name-only',BASE['head'],FIXED).decode().splitlines())==set(PATHS)
for anchor in BASE['anchors']:subprocess.run(['git','merge-base','--is-ancestor',anchor,FIXED],cwd=ROOT,check=True)
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
assert set(git('ls-files','--others','--exclude-standard','-z').decode().split('\0')[:-1])==set(BASE['untracked_inventory'])
proof={'record_type':'fixed_documentation_commit_raw_byte_readback','fixed_document_commit':FIXED,'base_commit':BASE['head'],'repository':'blue1998-glitch/Twstockai','branch':'dev/m1-v018-chart-annotations','completed_at':now(),'verified_document_count':len(files),'files':files,'all_verified':True,'remote':refs,'all_baseline_anchors_preserved':True,'main_unchanged':True,'changed_paths':PATHS,'old_handoff_bodies_preserved':True,'all_other_existing_tracked_paths_unchanged_in_commit':True,'existing_untracked_inventory_preserved':True,'work_result_attribution':'user-relayed actual Work acquisition and complete JSON read; not independently rerun by this Codex','work_complete_band_volume_acquisition_and_reading_gap':'CLOSED_BY_WORK_REPORTED_ACTUAL_READ','product_tests_or_producers_run':False,'old_assets_or_parts_requested':False,'old_validation_rerun':False,'bootstrap_run':False,'new_product_or_source_version':False,'self_reference_policy':'This receipt describes the fixed documentation commit, not its own later receipt commit. Receipt files are separately byte-read back after their normal commit.'}
(SCRATCH/'fixed-document-readback.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
directory=ROOT/'docs/work-reviews/20261024_band_volume_read_closure'
(directory/'GITHUB_READBACK.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
rows='\n'.join('|'+r['path']+'|'+str(r['actual_bytes'])+'|`'+r['sha256']+'`|200／原bytes一致|' for r in files)
text='''# Work讀取結果歸檔：固定文件GitHub讀回

固定歸檔提交：`'''+FIXED+'''`。原分片6d35b7f及原工程ec51f617均保留；起點1972ad9及全部已核祖先仍在，main未變。

本Codex實際由GitHub raw讀回固定提交的以下4份必要文件，HTTP200，逐檔與固定Git blob原bytes完全相同。安全headers、URL、起訖時點、長度、SHA及Git blob指紋見[GITHUB_READBACK.json](GITHUB_READBACK.json)。沒有重新取得分片、原大檔／blob、圖、ZIP或來源。

|文件|bytes|SHA256|結果|
|---|---:|---|---|
'''+rows+'''

本輪只有文件歸檔／讀回；Work已實際取得16片、串接完整4102710bytes／SHA03961ba8…、解析並遍讀10根鍵／1213快照的結果，歸屬仍是使用者轉交的Work本輪結果。完整band-volume.json未取得／未讀項已結清，不冒Codex本輪重新串接或核心驗證。沿用已看10圖、五項用途及五JSON，不再要求重取或重驗。

只有兩個既有交接文件新增前置段落、原文保留，加兩個新歸檔文件；其他既有追蹤路徑在提交內不變，未追蹤內容保留。無bootstrap、產品／來源工程、新版本、catalog、指標／producer、歷史測試重跑、每日淨帳／六方案或Android驗收。全部parent契約及來源／個人權利缺口、Raw／UNKNOWN與false/null資格保持，file://及受拒入口不重試。

本收據在固定歸檔之後獨立提交，避免自指；兩份收據本身在後續提交後再各自GitHub原bytes讀回，最終回覆另列最新已核SHA。下一個對象僅Work，完整可貼唯讀續接指令在[README](README.md)；沒有新具體需求就交付現有狀態，不再為同一確認往返歸檔。
'''
(directory/'GITHUB_READBACK.md').write_text(text)
print(json.dumps({'fixed_document_commit':FIXED,'verified_documents':len(files),'all_exact_bytes':True,'main_unchanged':True,'old_assets_downloaded':False},indent=2))
