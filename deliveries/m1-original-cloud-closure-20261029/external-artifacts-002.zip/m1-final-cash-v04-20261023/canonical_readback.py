from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.request import urlopen
from urllib.parse import quote
from datetime import datetime,timezone
import subprocess,hashlib,json
root=Path('/workspace/Twstockai');commit='dae1f6e580f466c4f44cb271a350f4b420d5b5eb';parent='d11cd18a53d688eae4602461392a6602313cea9f'
files=[n.decode() for n in subprocess.check_output(['git','diff','--name-only','-z',parent,commit],cwd=root).split(b'\0') if n]
def check(name):
 expected=subprocess.check_output(['git','show',commit+':'+name],cwd=root)
 url='https://raw.githubusercontent.com/blue1998-glitch/Twstockai/'+commit+'/'+quote(name,safe='/')
 try:
  with urlopen(url,timeout=30) as r:body=r.read();http=r.status
  return dict(path=name,url=url,http=http,sha256=hashlib.sha256(body).hexdigest(),bytes=len(body),byte_equal=body==expected,passed=http==200 and body==expected)
 except Exception as e:return dict(path=name,url=url,passed=False,error=type(e).__name__+': '+str(e))
with ThreadPoolExecutor(max_workers=4) as pool:checks=list(pool.map(check,files))
r=dict(canonical_product_commit=commit,observed_at=datetime.now(timezone.utc).isoformat(),files=len(checks),all_pass=all(c['passed'] for c in checks),checks=checks)
out=root/'股票系統M1_v0_18/rotation_research/resolution_validation_20261023/canonical-product-readback.json';out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='checks'}));assert r['all_pass']
