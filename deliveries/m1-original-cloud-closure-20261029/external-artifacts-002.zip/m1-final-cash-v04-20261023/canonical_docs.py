from pathlib import Path
import json,hashlib,subprocess
root=Path('/workspace/Twstockai');work=Path('/workspace/m1-final-cash-v04-20261023');out=root/'股票系統M1_v0_18/rotation_research/resolution_validation_20261023'
(out/'README.md').write_text('''# 決議來源0.4：本環境驗收及續接

正式程式沿用action_resolution／action_resolution_sources，固定成品dae1f6e580f466c4f44cb271a350f4b420d5b5eb；不再發布另一套來源0.4。其README／CONTRACT／REPORT在相鄰action_resolution_20261023，完整parent0.3、策略／引擎／庫／歷史與舊ZIP保持。

本輪補充兩項測試及本環境驗收：原0.4的29項加新增2項，共31項本環境實際通過。PDF額外重抽全文byte比較有差異，所用頁及全部決議欄位精確一致；不同假想股東各自圓整不合併。7／26等平行草稿紀錄不是正式交付計數，草稿已另存本地而未發布。

- [實際進度／失敗／未完成](REPORT.md)、[完整Work續接](WORK_HANDOFF.md)。
- [31項實測](tests.log)、[正式0.4的28檔固定GitHub回讀](canonical-product-readback.json)。
- [PDF抽字重核](pdf-extraction-recheck.json)、[首次assert失敗](pdf-extraction-first-failure.json)、[完整文字差異](pdf-extraction-diff.txt)。
- 新可執行驗收包與固定提交讀回：根deliveries/m1-resolution-validation-20261023/README.md。

標準Python離線：
```bash
cd 股票系統M1_v0_18
python3 -m unittest rotation_research.test_action_resolution rotation_research.test_resolution_validation -v
```
若重現producer，請在另一新解壓目錄執行python3 -m rotation_research.action_resolution_sources；本輪新封包保留原511成員，重現與manifest核對見delivery/package-verification。完整checkout工程依根AGENTS先bootstrap。

正式毛額API是action_resolution.preview_shareholder_cash；只接受明示假想權利股數。3股×0.8＝2.4→2元毛額；不同人1股及4股各為0、3元，不能合併算一人5股的4元。稅費／個人淨額／到款／期初權利與報酬仍未核。
''')
(out/'REPORT.md').write_text('''# 本輪保存後續成果及環境驗收

使用者起點d11cd18a，已實際重新bootstrap成功（0補缺／7差異保留）。作業期間完成了一份本地平行草稿；提交前CAS父節點核對發現遠端已前進dae1f6e，檢查在stage／commit前停止，沒有覆蓋遠端。

讀完新的action_resolution_20261023完整交接、契約、原碼與證據後，確認其0.4已涵蓋本輪正式決議及每人總額圓整要求。故將平行草稿完整另存於本地/workspace/m1-final-cash-v04-20261023/local-draft，不發布重複功能；還原的六份入口均為本輪自己的暫時前綴，先備份再fast-forward採用遠端，原使用者差異／四組未追蹤歷史保持。

採用的正式0.4：action_resolution及source producer，嵌入不改的parent0.3／五組件；新增批准決議與兩庫藏股分次報告。普通股每人總額先算再捨去，明示假想權利股數才有毛額。批准階段不是調整後最後分配、稅務細項或個人淨到款；沒有每日numeric replay路徑。庫藏股銷除不是股東減資帳。未改其金融原碼／契約／catalog或舊封包。

採用最新程式後在本環境再次bootstrap成功（0補缺／7差異保留），紀錄bootstrap.log。新增test_resolution_validation兩項：不同人分開圓整，以及PDF工具版本下所用頁／欄位保持相同。原0.4的29測試與新增2項，在本環境合計31項通過，見tests.log；沒有把前代24／17／44／15或18／9982／Chrome36當本輪重跑。平行草稿26測試只是未發布草稿紀錄，正式本輪採用的結果是31項。

## PDF抽字的實際失敗與界線

附加重抽用pdftotext25.03.0，原Work24.02.0。首次整份文字byte equality assertion失敗，舊54,910bytes、新54,843bytes，首個失敗、兩份SHA、原PDF SHA與完整diff皆保留。差異在附錄兩處斷行／重複逗號。原件與舊文字未改；用到的第1／3／4／6／7頁逐位元相同，正式producer的所有解析欄位精確相同。新增測試對正式producer再核，不放寬數值容差，也不把此結果稱全文byte equal或完整行動覆蓋。

## 重現與GitHub

正式成品dae1f6e的28變更檔已逐一從固定GitHub raw讀回，HTTP200、位元及SHA全同，見canonical-product-readback.json。本輪新驗收包會在新目錄執行31測試與正式producer、校驗所有舊新manifest及原511包成員；實際結果只以delivery/package-verification與extracted紀錄為準。原成品、庫及歷史不在工作目錄重算覆寫。

原0.4資格結果維持70拒算、2不足、8換股影響未支援、真正總淨報酬合格0。新解壓producer的實際重現數字另見delivery，不把僅讀舊輸出冒充新計算。每日淨帳／六方案／排名未跑，毛額不是個人績效；本輪沒有新官方網路、UI、瀏覽器或Android驗收。

仍缺完整公司行動／減資及2026/7/25後權息、2884未圓整／可賣日／零股及換股影響、台泥最後調整分配／直接有效稅務細項、個人淨分配／實際到款與期初權利。所有MOPS／TWT49U/TWT48U／TWTAUU／file://／NHI403及公報PDF403均未重試繞過。兩缺價日原因UNKNOWN、不補價；Raw／五年Adjusted／歷史公布／主檔／SQLite未知保持，無自動交易或新策略。
''')
prompt='''接續blue1998-glitch/Twstockai，分支dev/m1-v018-chart-annotations。先查遠端最新，確認包含d11cd18a53d688eae4602461392a6602313cea9f、dae1f6e580f466c4f44cb271a350f4b420d5b5eb及其後resolution_validation_20261023／固定GitHub回讀，保留全部後續，不回退／不用main或舊ZIP覆蓋。最新已核提交見deliveries/m1-resolution-validation-20261023/GITHUB_READBACK.md及分支ref。
先讀根AGENTS、CONTINUE_IN_WORK_MODE、PROJECT_VISION、M1_V019_GRAPH_CORE_RESUME_HANDOFF最新節；全文讀股票系統M1_v0_18/rotation_research/resolution_validation_20261023的README、REPORT、WORK_HANDOFF、tests、pdf-extraction-recheck／first-failure／diff、canonical-product-readback及delivery收據；再全文讀action_resolution_20261023的README、CONTRACT、REPORT、WORK_HANDOFF／events-v04／verification與final_distribution_review_20261023原完整交接／facts／network-limitations。
採用正式0.4是action_resolution／action_resolution_sources（dae1f6e），不是本地平行distribution_sources草稿；後者封存本地未發布。本輪本環境重新bootstrap後，正式29測試＋新增2環境／不同人圓整測試＝31實測通過。原511小包成員完整保留；解壓producer／31測試與manifest以delivery實測為準。PDF重抽25.03與原24.02全文byte比較失敗已存，所用1／3／4／6／7頁及正式解析欄位精確相同，原件不改，不說全文byte一致。
台泥股東會通過0.8元／來源標籤／每人總額至元捨去已接，仍有調整授權，稅務細項／個人淨入帳未知。3股2.4→2元只是明示假想權利毛額，不以每股先捨去、不合併不同人、不除回net_per_share；假想0股不是零期初應收。第七次庫藏股28000張報告銷除缺生效／其他股東影響，不套每人減資／退資；第六次無銷除只屬該次。保留原0.3與全部歷史、原兩缺價原因UNKNOWN。70窗仍拒算、2不足、8換股影響未支援、真正總淨報酬合格0；無每日帳／六方案／排名或最適比例。
下一步Work補來源：完整1101／2884行動減資及2026/7/25後權息、2884直接2025可賣日／未圓整實配／零股與既有股東換股影響；台泥調整後最後比率／實際日期、直接有效稅務細項、個人淨分配／到款及九起日期初權利。公司發放不是個人淨入帳，空白資料不是零權利，私人券商／集保原件不得公開Git；或另作來源充分、稅籍／情境明示的總額淨帳契約。缺資料維持未知／拒算，不推免稅、不補行情。
所有MOPS安全拒絕、TWT49U/TWT48U、TWTAUU307、file://、NHI403及公報PDF403不重試或換路徑繞過；其他獨立可讀官方來源才保存URL／時點／SHA／範圍。工程Codex在實際完整checkout依最新AGENTS重新bootstrap成功後做獨立新版本；不改原scope／resolution／producer／action_ledger／core／參數策略／庫／歷史／舊catalog頁ZIP或main。正式原則全換／分批／觸發仍研究變數，不重問已答P0～P1，不加門檻或自動下單，不部署付費交易訊息子代理。
Raw／五年Adjusted／歷史公布／主檔／SQLite未知、historical_signal_eligible=false、primary_pressure_id=null、policy_authorized=false保持。無新UI則不重開手機驗收，Android NOT_TESTED_NEW_BUILD、圖形NOT_VALIDATED、交易飛輪NOT_EVALUATED。同分支逐節點保存及固定提交逐檔GitHub回讀，未測不完成；結束列實際完成／未完成、成品SHA入口、最新已核提交、下一步Work或Codex及完整續接指令。'''
(out/'WORK_HANDOFF.md').write_text('# 完整回Work／後續Codex指令\n\n```text\n'+prompt+'\n```\n')
