from pathlib import Path
import subprocess,json,zipfile,tempfile,hashlib
root=Path('/workspace/Twstockai');d=root/'deliveries/m1-distribution-v04-20261023';bundle=d/'m1-distribution-v04-20261023.zip'
receipt=json.loads((d/'bundle-receipt.json').read_text());assert hashlib.sha256(bundle.read_bytes()).hexdigest()==receipt['sha256']
with tempfile.TemporaryDirectory(dir='/workspace',prefix='m1-distribution-v04-extracted-') as td:
 extracted=Path(td)
 with zipfile.ZipFile(bundle) as z:
  assert z.testzip() is None;z.extractall(extracted)
  with zipfile.ZipFile(root/'deliveries/m1-action-scope-20261023/m1-action-scope-v03-20261023.zip') as old:
   assert all(z.read(n)==old.read(n) for n in old.namelist());original_count=len(old.namelist())
  counts={}
  for name in ('DISTRIBUTION_V04_MANIFEST.json','ACTION_SCOPE_MANIFEST.json','OFFICIAL_ACTIONS_MANIFEST.json','SOURCE_QUALIFICATION_MANIFEST.json','ACTION_PACKAGE_MANIFEST.json'):
   m=json.loads(z.read(name));assert all(hashlib.sha256(z.read(n)).hexdigest()==s for n,s in m.items());counts[name]=len(m)
 project=extracted/'股票系統M1_v0_18'
 for name,args in [('extracted-tests.log',['python3','-m','unittest','rotation_research.test_distribution_v04','-v']),('extracted-producer.log',['python3','-m','rotation_research.distribution_sources'])]:
  r=subprocess.run(args,cwd=project,capture_output=True,text=True);(d/name).write_text(r.stdout+r.stderr);r.check_returncode()
 manifest=json.loads((extracted/'DISTRIBUTION_V04_MANIFEST.json').read_text())
 assert all(hashlib.sha256((extracted/n).read_bytes()).hexdigest()==s for n,s in manifest.items()),'Reproduction changed shipped outputs'
 ws=json.loads((project/'rotation_research/distribution_v04_20261023/window-qualification.json').read_text())['windows']
 assert sum(w['end'] is not None for w in ws)==70 and sum(w['end'] is None for w in ws)==2
 assert all(w['daily']==[] and w['total_net_return'] is None for w in ws if w['end'])
 r=dict(bundle_sha256=receipt['sha256'],fresh_extraction='PASS',unit_tests=26,offline_producer='PASS',old_v03_members_byte_exact=original_count,manifest_counts=counts,all_members_unchanged_after_reproduction=True,refused_windows=70,insufficient_windows=2,total_net_return_qualified_windows=0,new_strategy_replays=0,android='NOT_TESTED_NEW_BUILD')
 (d/'package-verification.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r))
