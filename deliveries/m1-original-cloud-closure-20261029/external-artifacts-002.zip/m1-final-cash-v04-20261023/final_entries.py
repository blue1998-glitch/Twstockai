from pathlib import Path
from urllib.request import urlopen
import hashlib,json
root=Path('/workspace/Twstockai');d=root/'deliveries/m1-resolution-validation-20261023';r=json.loads((d/'bundle-receipt.json').read_text())
(d/'README.md').write_text(f'''# 決議0.4及本環境驗收完整小包

[下載驗收包]({r['filename']}?raw=true)，{r['bytes']:,}bytes（約6.39 MiB）；先開RESOLUTION_VALIDATION_START_HERE.md。

SHA256：`{r['sha256']}`；[SHA256SUMS](SHA256SUMS)、[封包收據](bundle-receipt.json)、[新目錄解壓驗收](package-verification.json)、[31項測試](extracted-tests.log)。原正式0.4的511成員逐位元保留；六層manifest527／510／469／409／374／292全通過。

[本輪入口／報告／完整續接](../../股票系統M1_v0_18/rotation_research/resolution_validation_20261023/README.md)；正式金融程式是[既有action_resolution0.4](../../股票系統M1_v0_18/rotation_research/action_resolution_20261023/README.md)，[契約](../../股票系統M1_v0_18/rotation_research/action_resolution_20261023/CONTRACT.md)不改。本輪固定提交回讀見[GITHUB_READBACK.md](GITHUB_READBACK.md)。

已保留作業期間遠端新增dae1f6e及e3a76eb，採用既有正式0.4，不發布平行草稿。既有29測試在本環境實跑，再補2項，共31通過；新解壓producer實跑70窗仍拒算、2不足、8換股影響未支援，真正總淨報酬0合格。沒有每日淨帳／六方案或市場績效。PDF額外抽字全文byte assert失敗／差異保留，所用頁與欄位精確同。

原0.3／正式0.4金融程式、來源、庫、策略、歷史、舊成品及main保持。每人總額毛額不是淨到款；完整行動、稅費、最後分配與期初權利等缺口依新WORK_HANDOFF。無UI／Android驗收，下一步Work補來源，工程交Codex。
''')
latest='''# 2026-10-23 Codex｜採用遠端正式0.4並完成本環境驗收

已保留作業期間新增的dae1f6e580f466c4f44cb271a350f4b420d5b5eb正式工程及e3a76eb2eac8dfd50bb5f6b7794fb77d84224b30收據，沒有用本地平行草稿覆蓋。正式程式維持action_resolution／action_resolution_sources；新補充入口 `股票系統M1_v0_18/rotation_research/resolution_validation_20261023/README.md`、REPORT／WORK_HANDOFF，下載與逐檔回讀入口 `deliveries/m1-resolution-validation-20261023/README.md`。原0.3、正式0.4與所有歷史保留。

本環境重新bootstrap成功（0補缺／7差異保留）。正式29項＋新增2項＝31項本環境實測通過，並在新封包解壓重驗；原511成員及六層manifest全保留。新解壓正式producer實跑70窗仍拒算、2不足、8換股影響未支援，真正總淨報酬0，numeric replay／六方案0。台泥批准來源與每人總額圓整已接，但假想毛額不是淨額／到款／期初權利，不做net_per_share或股東減資推定。

額外PDF抽字25.03與原24.02全文byte assertion失敗已保存，所用1／3／4／6／7頁及正式解析欄位精確同；不說全文byte equal。一次保存輔助命令誤用工作目錄也已留診斷並改絕對根重核，來源／金融程式不改。本地平行草稿封存未發布，其26測試不是正式交付計數。正式28檔已獨立固定GitHub回讀，本輪新增檔再另固定回讀。

所有原策略／引擎／庫／資料／catalog／頁／ZIP與main保持；完整行動／減資、7/25後權息、2884可賣日／實配／零股與換股影響、台泥最後調整／直接有效稅務來源、個人淨分配／期初權利仍缺。已記錄安全拒絕未重試繞過，缺價原因及Raw／五年Adjusted／歷史公布／主檔／SQLite未知保持，無新UI／Android。下一步Work補來源，工程Codex；完整可貼指令見新WORK_HANDOFF。不重問已答規則／比例、不部署付費交易訊息或子代理。以下原文完整保留。

---

'''
for rel in ('AGENTS.md','CONTINUE_IN_WORK_MODE.md','M1_V019_GRAPH_CORE_RESUME_HANDOFF.md','股票系統M1_v0_18/rotation_research/README.md','股票系統M1_v0_18/rotation_research/WORK_HANDOFF.md','股票系統M1_v0_18/rotation_research/DATA_QUALIFICATION.md'):
 p=root/rel;b=p.read_bytes();assert not b.startswith(latest.encode());p.write_bytes(latest.encode()+b)
checks=[];commit='e3a76eb2eac8dfd50bb5f6b7794fb77d84224b30'
for name in ('GITHUB_READBACK.md','GITHUB_READBACK.json'):
 p=root/'deliveries/m1-action-resolution-20261023'/name
 url='https://raw.githubusercontent.com/blue1998-glitch/Twstockai/'+commit+'/deliveries/m1-action-resolution-20261023/'+name
 with urlopen(url,timeout=25) as response:b=response.read();status=response.status
 assert status==200 and b==p.read_bytes()
 checks.append(dict(path=str(p.relative_to(root)),http=status,byte_equal=True,sha256=hashlib.sha256(b).hexdigest()))
(d/'canonical-receipt-closure.json').write_text(json.dumps(dict(commit=commit,all_pass=True,checks=checks),ensure_ascii=False,indent=2)+'\n')
