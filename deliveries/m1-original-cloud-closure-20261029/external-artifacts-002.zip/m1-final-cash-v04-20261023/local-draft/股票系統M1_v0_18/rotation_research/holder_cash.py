"""Pure per-holder approved-rate gross scenario; never net cash or a return."""
from datetime import datetime
from decimal import Decimal, localcontext, ROUND_FLOOR
import re
from graph_core.core import fingerprint
from .action_scope import verify

RULE = 'PER_ORDINARY_SHAREHOLDER_TOTAL_CASH_TO_WHOLE_TWD_DROP_SUB_TWD'


def holder_cash_total(data, resolution):
    verify(resolution)
    if data.get('schema') != 'rotation-holder-cash-scenario/0.1' or data.get('purpose') != 'APPROVED_RATE_HYPOTHETICAL':
        raise ValueError('Explicit hypothetical gross-total contract required')
    if resolution['stage'] != 'SHAREHOLDER_APPROVED_RESOLUTION' or resolution['action_type'] != 'CAPITAL_SURPLUS_CASH_RESOLUTION':
        raise ValueError('Approved cash resolution required; proposal/treasury record cannot be used')
    if any(data.get(k) != resolution[k] for k in ('issuer_code', 'entitled_old_code', 'old_instrument')) or data.get('resolution_id') != resolution['id']:
        raise ValueError('Wrong issuer/holder/instrument/resolution version')
    if not isinstance(data.get('holder_case_id'), str) or not data['holder_case_id'].strip():
        raise ValueError('One explicit hypothetical holder identity required')
    observed = data.get('observed_as_of')
    if not observed:
        raise ValueError('Explicit observation cutoff required')
    cutoff = datetime.fromisoformat(observed)
    if cutoff.tzinfo is None or cutoff < datetime.fromisoformat(resolution['observed_at']):
        raise ValueError('Evidence not yet observed or cutoff lacks timezone')
    if data.get('historical_signal') or resolution['historical_signal_eligible']:
        raise ValueError('Historical availability not authenticated')
    for prohibited in ('net_per_share', 'net_cash', 'net_distributions_verified', 'tax_exempt', 'actual_received_at'):
        if prohibited in data:
            raise ValueError('Net/receipt override is outside this gross-only contract')
    rule = resolution['fields']['rounding_rule']
    rate = resolution['fields']['approved_cash_per_share']
    if (rule['value'] != RULE or not rule['proofs'] or not rate['proofs']
            or rate['unit'] != 'TWD_PER_OLD_ORDINARY_SHARE'
            or not isinstance(rate['value'], str)
            or not re.fullmatch(r'(?:0|[1-9]\d*)(?:\.\d+)?', rate['value'])):
        raise ValueError('Sourced per-holder total rule and decimal rate required')
    if any(p.get('source_id') not in resolution['source_ids'] or not p.get('locator')
           for bound in (rule, rate) for p in bound['proofs']):
        raise ValueError('Rounding/rate proofs must bind the retained resolution sources')
    result = dict(schema='rotation-holder-cash-result/0.1', input_id=fingerprint(data),
        resolution_id=resolution['id'], holder_case_id=data['holder_case_id'],
        quantity_shares=data.get('quantity_shares'), approved_rate_per_share=rate['value'],
        rounding_scope=RULE, hypothetical=True, unrounded_approved_gross=None,
        rounded_approved_gross=None, sub_twd_remainder_to_issuer=None,
        net_per_share=None, investor_net_cash=None, actual_received_at=None,
        available_cash=None, total_net_return=None, daily=[],
        refusal_reasons=['FINAL_AFTER_AUTHORIZED_ADJUSTMENTS_UNKNOWN',
            'INVESTOR_TAX_FEES_AND_ACTUAL_RECEIPT_UNKNOWN', 'OPENING_ENTITLEMENTS_UNKNOWN',
            'NOT_A_NET_LEDGER_OR_RETURN'], historical_signal_eligible=False,
        primary_pressure_id=None, policy_authorized=False)
    quantity = data.get('quantity_shares')
    evidence = data.get('quantity_evidence')
    if quantity is None or evidence is None:
        result['refusal_reasons'].append('ENTITLEMENT_QUANTITY_UNKNOWN_NOT_DEFAULTED_ZERO')
        return dict(result, status='REFUSED_UNKNOWN_ENTITLEMENT_QUANTITY')
    if evidence.get('status') != 'DECLARED_SCENARIO' or not evidence.get('definition'):
        raise ValueError('Explicit scenario quantity definition required; not investor evidence')
    if not isinstance(quantity, str) or not re.fullmatch(r'0|[1-9]\d*', quantity):
        raise ValueError('Nonnegative integral share count as decimal string required')
    with localcontext() as context:
        context.prec = max(50, len(quantity) + len(rate['value']) + 8)
        gross = Decimal(quantity) * Decimal(rate['value'])
        rounded = gross.to_integral_value(rounding=ROUND_FLOOR)
        result.update(unrounded_approved_gross=format(gross, 'f'),
                      rounded_approved_gross=format(rounded, 'f'),
                      sub_twd_remainder_to_issuer=format(gross - rounded, 'f'))
    return dict(result, status='GROSS_SCENARIO_ONLY_NOT_NET_ACCOUNTING')
