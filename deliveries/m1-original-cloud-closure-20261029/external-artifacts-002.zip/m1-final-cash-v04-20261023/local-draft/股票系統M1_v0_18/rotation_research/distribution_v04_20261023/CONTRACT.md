# 正式決議與每人現金總額契約 0.4

1. 獨立來源producer `distribution_sources.py`、純數值 `holder_cash.py` 與新catalog；不改0.3、action_scope、official_actions、action_ledger、core或舊catalog／策略／庫／歷史。新版本顯式保留原ID、提案版本與觀察時點，沒有自動選最新／倒填歷史可得。
2. 股東會通過只認證決議所載來源標籤、金額、每股比率、圓整規則與授權；後續調整後最終分配、稅務細項法規、個人淨額及到款仍未核。會議日、除息日、基準日、發放日、個人入帳日各自獨立，announced_at仍null。
3. 新 `rotation-holder-cash-scenario/0.1` 輸入須明列resolution_id、holder_case_id、issuer_code、entitled_old_code、old_instrument、帶時區observed_as_of、purpose=APPROVED_RATE_HYPOTHETICAL、quantity_shares（十進位整數字串或null）、quantity_evidence=DECLARED_SCENARIO。這是工程假設數量，不是個人權利證明；null不補0。不同人不能先合併股數再圓整。
4. 純函數 `holder_cash_total(input, resolution)` 驗決議指紋及完整身份／版本／觀察時點，只接受股東會通過的普通股資本公積現金決議。對明示假設股數以Decimal算 `未圓整毛額 = 股數 × 決議每股額`，再對**一人本事件總額**捨去不足一元部分，另列餘款。不可先對每股捨去、不可按筆成交各捨去、不可將兩人合併、不可將結果除股數當通用net_per_share。
5. 輸出 `rotation-holder-cash-result/0.1` 保存輸入／決議ID、未圓整毛額、圓整毛額、餘款、圓整層級及hypothetical標示。有效假設數量狀態為GROSS_SCENARIO_ONLY_NOT_NET_ACCOUNTING；缺數量／定義時REFUSED_UNKNOWN_ENTITLEMENT_QUANTITY，三毛額皆null。明示0只代表此工程假設0，非真實零權利證明。負數、float、非整股、NaN／Infinity拒絕。
6. 本契約不接稅費／收款資料計淨額，也不產生每日資金帳、可用現金或報酬；net_per_share、investor_net_cash、actual_received_at、total_net_return均null。完整公司行動、原權利股數／期初應收、稅費及到款不足時，真實帳維持拒算。不得將本毛額情境宣稱已支援每人淨額入帳。
7. 新catalog將決議來源加到1101相符原現金組件，保留舊來源ID及數值／既有交易所與issuer日期，另存決議頁所未指定的基準／發放日null及比率調整授權。正式決議標籤與供稅模型的細項分開；總額除每股比率不反推股東或流通股數。
8. 第六／七次庫藏股報告只進公司行動inventory，單位保留原張；第六次「無銷除」只屬該次報告，第七次已銷除28000張不套成個別股東減資比例／退資。銷除生效日與持有人影響unknown，coverage不能升完整；不得用其買回日期填個股缺價原因。
9. 新資格producer重用原qualify作檢查，但不向舊固定每股淨額帳輸入每人圓整總額。完整期間、換股／庫藏股影響、淨分配、期初權利仍不足，則無每日numeric replay／六方案／排名。保留既有8窗換股範圍與2窗不足，不將來源通過當績效通過。
10. 新原件／索引連結、PDF頁及段落、表決權數總和／公布百分比、每人圓整原文及來源SHA須重核。只讀已封存資料，所有已記錄安全拒絕不重試繞過。所有歷史策略與Raw／Adjusted／歷史公布／主檔／SQLite未知持續，無UI／Android驗收。
