# 完整回Work／後續Codex指令

下一步Work補來源，工程交Codex；固定提交與回讀狀態見delivery收據。

```text
接續blue1998-glitch/Twstockai，分支dev/m1-v018-chart-annotations。先查遠端最新，確認包含d11cd18a53d688eae4602461392a6602313cea9f及其後distribution_v04_20261023工程／固定GitHub回讀收據，保留0.3及全部後續，不回退、不用main或舊ZIP覆蓋。最新已核提交以deliveries/m1-distribution-v04-20261023/GITHUB_READBACK.md及分支頭實讀為準。
依序讀根AGENTS、CONTINUE_IN_WORK_MODE、PROJECT_VISION、M1_V019_GRAPH_CORE_RESUME_HANDOFF最新節；全文讀股票系統M1_v0_18/rotation_research/distribution_v04_20261023的README、CONTRACT、REPORT、WORK_HANDOFF、events-v04、unknown-holder-refusal、verification、output-verification、pdf-extraction-recheck與first-failure／diff及delivery回讀收據；再讀final_distribution_review_20261023原WORK_HANDOFF、facts及network-limitations。原0.3／0.2／事件帳與保存契約持續適用。
本輪已實作獨立來源0.4與holder_cash純毛額函數，26新定向測試通過。兩新官方原件與122價量原件重核；股東會通過0.8元資本公積來源標籤／總額／表決已接，舊提案及原ID／時間保持。每人總額至元捨去，不先捨每股、不合併不同人、不除回通用net_per_share。7個工程假設權利股數案例僅毛額，未知股數probe拒算，淨額／到款／可用現金／報酬null；不是個人績效或每日淨帳。股東會通過不等調整後最後分配或稅務細項已核。
原第六次庫藏股無銷除只屬該次；第七次28,000張報告銷除仍缺生效日／持有人影響，不套每人股數減資或退資。本輪新資格實跑70窗全拒算、2不足、8換股影響未支援，真正總淨報酬合格0，無原每日numeric replay／六方案或排名。26是本輪數字，舊24／17／44／15及18／9982／Chrome36未重跑，無新UI／Android。
額外pdftotext25.03整份抽字與原24.02非逐位元一致，首個assert失敗與差異已存；所用1／3／4／6／7頁及全部抽取欄位精確相同，原件／舊文字未改。不要把額外核對說成全文byte equal或重做來源研究。
下一步Work優先補完整兩股行動／減資及7/25後權息、台泥最終調整分配／稅務細項法規、銷除生效日／股東影響、2884未圓整／2025可賣日／零股及換股對原2884影響，個人淨分配／實際入帳及起初權利要有來源，或另訂來源充分、情境／稅籍明示的總額模型。不假設零稅費／零權利，不拿公司發放當個人收款；私人券商／集保原件不提交公開Git。每人總額的淨額／每日入帳若需工程，另做獨立明示契約，不能繞過原net_per_share不足直接算績效。
工程用Codex，在實際完整checkout按最新AGENTS重新bootstrap --hydrate-missing成功後只做獨立新版本，保留holder_cash／distribution_sources0.4、action_scope0.3／舊producer／action_ledger／core／策略參數／庫／歷史／舊catalog／頁／ZIP與main。缺資料維持unknown／refused，所有MOPS／TWT49U/TWT48U／TWTAUU307／file://／NHI403及公報PDF403不重試／換路徑繞過；其他獨立官方來源可讀才保存URL／時點／SHA／適用對象／欄位，不用零命中證無事件。兩個缺價日原因及Raw／五年Adjusted／歷史公布／主檔／SQLite未知保持。
全換／分批／觸發仍研究變數，不重問P0～P1、不加策略門檻或自動下單。不部署付費交易訊息子代理，historical_signal_eligible=false、primary_pressure_id=null、policy_authorized=false，Android NOT_TESTED_NEW_BUILD、圖形NOT_VALIDATED、交易／飛輪NOT_EVALUATED。適量實測，同分支逐節點保存並固定提交逐檔GitHub回讀；結束列實際完成／未完成、成品／SHA／最新已核提交及下一步Work或Codex，附完整續接指令。
```
