# 正式分配決議與每人毛額圓整 0.4

本輪可執行獨立版本；原0.3／引擎／策略／庫／歷史／舊成品保持。正式決議來源已接入，但真實總淨報酬仍拒算。

- [輸入輸出契約](CONTRACT.md)、[實作／實測／錯誤及未完成](REPORT.md)、[完整Work續接指令](WORK_HANDOFF.md)。
- [新catalog](events-v04.json)：保留0.3所有來源版本，新增股東會通過及兩次庫藏股報告，不能把庫藏股銷除套成股東減資。
- [工程毛額案例](engineered-gross-examples.json)：假設權利股數，不是個人帳戶／投資績效。
- [缺權利股數的拒算](unknown-holder-refusal.json)、[新72窗口資格核對](window-qualification.json)、[摘要](verification.json)、[26測試](tests.log)。
- [PDF抽字額外核對](pdf-extraction-recheck.json)：整份文字非逐位元相同，所用頁／全部欄位相同；首個失敗與差異均保留，詳見REPORT。
- 可下載小包、SHA、實際解壓及固定GitHub回讀：根deliveries/m1-distribution-v04-20261023/README.md。

標準Python離線重現：
```bash
cd 股票系統M1_v0_18
python3 -m unittest rotation_research.test_distribution_v04 -v
python3 -m rotation_research.distribution_sources
```
只寫本新目錄；不連網、不改舊輸出、不需安裝依賴。PDF原件與兩版衍生文字均已封存，離線producer不需pdftotext。

每人毛額純函數為holder_cash.holder_cash_total，先依契約用distribution_sources.holder_input指定**假設權利股數**及明確決議版本，再傳入來源已核的resolution。3股×0.8＝2.4，該人總額捨去為2；1股及4股兩人分別為0與3，不能合併成5股的一人4元。所有net／actual receipt／return皆null；沒有把毛額除股數做net_per_share。
