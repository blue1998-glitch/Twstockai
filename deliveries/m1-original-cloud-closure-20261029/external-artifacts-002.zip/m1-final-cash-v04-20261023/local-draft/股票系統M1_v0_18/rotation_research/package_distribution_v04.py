"""Separate v0.4 package, retaining every prior v0.3 member unchanged."""
from io import BytesIO
import hashlib
import json
import zipfile
from .action_sources import ROOT, HERE, dump
from .distribution_sources import OUT, REVIEW


def main():
    old_zip = ROOT / 'deliveries/m1-action-scope-20261023/m1-action-scope-v03-20261023.zip'
    old_bytes = old_zip.read_bytes()
    if hashlib.sha256(old_bytes).hexdigest() != '0724b40717c25e1a9361bd213b586cc1097346287e2f3df879409425add71f2e':
        raise ValueError('Prior deliverable changed; preserve it')
    with zipfile.ZipFile(BytesIO(old_bytes)) as old:
        assert old.testzip() is None
        members = {name: old.read(name) for name in old.namelist()}
        for name in ('ACTION_SCOPE_MANIFEST.json', 'OFFICIAL_ACTIONS_MANIFEST.json', 'SOURCE_QUALIFICATION_MANIFEST.json', 'ACTION_PACKAGE_MANIFEST.json'):
            assert all(hashlib.sha256(members[n]).hexdigest() == s for n, s in json.loads(members[name]).items())
    old_count = len(members)
    selected = {p for folder in (OUT, REVIEW) for p in folder.rglob('*') if p.is_file()}
    selected.update(HERE / n for n in ('holder_cash.py', 'distribution_sources.py', 'test_distribution_v04.py', 'package_distribution_v04.py'))
    for path in sorted(selected):
        name = str(path.relative_to(ROOT))
        if name in members:
            raise ValueError('An old package member cannot be replaced')
        members[name] = path.read_bytes()
    members['DISTRIBUTION_V04_START_HERE.md'] = '''# M1正式決議與每人毛額圓整0.4

本輪入口：股票系統M1_v0_18/rotation_research/distribution_v04_20261023/README.md、CONTRACT、REPORT、WORK_HANDOFF。
原470成員及全部歷史入口逐位元保留，新增新原件、獨立程式及實測。
解壓至新資料夾，進入股票系統M1_v0_18：
```bash
python3 -m unittest rotation_research.test_distribution_v04 -v
python3 -m rotation_research.distribution_sources
```
標準Python離線；不需PDF依賴、網路或重跑舊驗收。26是本輪定向測試。
每人總額先算再捨去不足一元；例如假設權利3股×0.8＝2.4，該人毛額為2元。
這不是每股淨額／個人到款／可用現金或市場績效；未知股數拒算，真正總淨報酬仍0合格。
原PDF抽字24.02與本機25.03全文不等，所用頁／欄位全同，首個失敗及差異見REPORT。
DISTRIBUTION_V04_MANIFEST.json核全部其他成員，四層舊manifest亦保留。
完整checkout仍依GitHub根AGENTS準備；打包腳本另需原0.3 ZIP，不重複塞ZIP進小包。
'''.encode()
    manifest = {n: hashlib.sha256(b).hexdigest() for n, b in sorted(members.items())}
    members['DISTRIBUTION_V04_MANIFEST.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    buf = BytesIO()
    with zipfile.ZipFile(buf, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, body in sorted(members.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 23, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED; info.external_attr = 0o100644 << 16
            z.writestr(info, body, compresslevel=9)
    body = buf.getvalue(); delivery = ROOT / 'deliveries/m1-distribution-v04-20261023'
    delivery.mkdir(parents=True, exist_ok=True); dest = delivery / 'm1-distribution-v04-20261023.zip'
    if dest.exists() and dest.read_bytes() != body:
        raise ValueError('Different package already exists; preserve it and choose a new name')
    if not dest.exists(): dest.write_bytes(body)
    with zipfile.ZipFile(BytesIO(body)) as z:
        assert z.testzip() is None
        assert all(hashlib.sha256(z.read(n)).hexdigest() == s for n, s in manifest.items())
    sha = hashlib.sha256(body).hexdigest()
    (delivery / 'SHA256SUMS').write_text(sha + '  ' + dest.name + '\n')
    receipt = dict(filename=dest.name, sha256=sha, bytes=len(body), members=len(members),
                   original_v03_members_byte_exact=old_count, crc='PASS', manifest='ALL_PASS')
    dump(delivery / 'bundle-receipt.json', receipt); print(json.dumps(receipt))


if __name__ == '__main__': main()
