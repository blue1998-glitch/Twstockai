"""Source and holder-total arithmetic tests; no market/net performance claims."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

from . import distribution_sources as src
from .holder_cash import holder_cash_total, RULE
from .action_scope import identify, verify
from .action_study import verified_quotes, candidate_input
from .source_qualification import build_calendar, bind_observed_calendar
from .action_sources import HERE


class ApprovedDistribution(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.catalog = src.build_catalog()
        cls.resolution = next(v for v in cls.catalog['inventory'] if v['id'] == cls.catalog['approved_resolution_id'])
        cls.texts, _ = src.load_resolution_sources()
        cls.parsed = src.parse_resolution(cls.texts['tcc-2026-agm-minutes'], cls.texts['tcc-meeting-index'])
        cls.old = json.loads((HERE / 'action_scope_20261023/events-v03.json').read_text())
        cls.quotes, cls.manifest = verified_quotes(); cls.calendar = build_calendar()

    def input(self, q='3'):
        return src.holder_input(self.resolution, 'ENGINEERED_TEST_NOT_USER', q)

    def ledger_input(self, start='2026-06-30', end='2026-07-29'):
        return bind_observed_calendar(candidate_input(self.quotes, self.catalog, self.manifest, start, end, '1101'), self.calendar)

    def test_first_discussion_vote_scope_not_preceding_earnings_vote(self):
        self.assertEqual(self.parsed['votes'], dict(attending='5366379935', yes='5078871021', no='2452546', invalid='17000', abstain='285039368'))
        self.assertEqual(self.parsed['published_yes_percent'], '94.64')
        self.assertNotEqual(self.parsed['votes']['yes'], '5075909777')
        self.assertEqual(self.parsed['source_pages'], [6, 7])

    def test_exact_funding_label_and_approved_pool_not_inferred_share_count(self):
        self.assertEqual(self.parsed['approved_funding_label_raw'], '超過票面金額發行股票所得溢額')
        self.assertEqual(self.parsed['approved_total_twd'], '5994545394')
        self.assertEqual(self.parsed['approved_cash_per_share'], '0.8')
        self.assertEqual(self.parsed['meeting_date'], '2026-05-22')
        self.assertNotIn('implied_total_shares', self.parsed)
        self.assertIsNone(self.parsed['tax_origin_subtype'])

    def test_missing_passage_approval_rounding_or_authority_refuses(self):
        text = self.texts['tcc-2026-agm-minutes']; index = self.texts['tcc-meeting-index']
        for changed in (text.replace('照案通過', '尚未通過'), text.replace('元以下捨去', '待定'),
                        text.replace('另行訂定發放', '不訂發放')):
            with self.assertRaises(ValueError): src.parse_resolution(changed, index)

    def test_scoped_vote_sum_and_published_percent_must_agree(self):
        text = self.texts['tcc-2026-agm-minutes']; index = self.texts['tcc-meeting-index']
        for changed in (text.replace('5,078,871,021', '5,078,871,022'), text.replace('94.64%', '94.63%')):
            with self.assertRaises(ValueError): src.parse_resolution(changed, index)

    def test_official_rate_and_rounding_proofs_point_inside_approved_section(self):
        for name in ('approved_cash_per_share', 'rounding_rule', 'approved_funding_label_raw'):
            proof = self.resolution['fields'][name]['proofs'][0]
            self.assertIn('PDF pages 6-7, first discussion', proof['locator'])
            self.assertIn(proof['raw_value'], src.resolution_section(self.texts['tcc-2026-agm-minutes']))
        self.assertEqual(self.resolution['fields']['approved_cash_per_share']['proofs'][0]['raw_value'], '每股發放0.8元')

    def test_proposal_and_approved_versions_keep_separate_ids_and_times(self):
        old_proposal = next(v for v in self.old['inventory'] if v['action_type'] == 'CASH_DISTRIBUTION_PROPOSAL')
        self.assertEqual(self.catalog['inventory'][:len(self.old['inventory'])], self.old['inventory'])
        self.assertEqual(self.resolution['related_proposal_id'], old_proposal['id'])
        self.assertEqual(self.resolution['stage'], 'SHAREHOLDER_APPROVED_RESOLUTION')
        self.assertGreater(self.resolution['observed_at'], old_proposal['observed_at'])
        self.assertIsNone(self.resolution['announced_at'])
        self.assertFalse(self.resolution['historical_signal_eligible'])

    def test_meeting_date_does_not_replace_saved_ex_record_or_payment_dates(self):
        old = next(e for e in self.old['events'] if e['code'] == '1101' and e['ex_date'] == '2026-07-01')
        new = next(e for e in self.catalog['events'] if e.get('approval_resolution_id'))
        for key in ('ex_date', 'pay_date', 'record_date', 'gross_per_share', 'net_per_share'):
            self.assertEqual(new[key], old[key])
        self.assertEqual(new['supersedes_event_id'], old['id'])
        self.assertIsNone(self.resolution['fields']['record_date']['value'])
        self.assertIsNone(self.resolution['fields']['pay_date']['value'])
        for e in self.old['events']:
            if e['id'] != old['id']: self.assertIn(e, self.catalog['events'])
        verify(new); verify(self.catalog)

    def test_per_holder_total_rounding_exact_arithmetic(self):
        for quantity, raw, rounded, remainder in [('1', '0.8', '0', '0.8'), ('3', '2.4', '2', '0.4'),
                                                  ('5', '4.0', '4', '0.0'), ('6', '4.8', '4', '0.8'),
                                                  ('1001', '800.8', '800', '0.8')]:
            with self.subTest(quantity=quantity):
                r = holder_cash_total(self.input(quantity), self.resolution)
                self.assertEqual((r['unrounded_approved_gross'], r['rounded_approved_gross'], r['sub_twd_remainder_to_issuer']), (raw, rounded, remainder))
                self.assertEqual(r['rounding_scope'], RULE)
                self.assertEqual(r['status'], 'GROSS_SCENARIO_ONLY_NOT_NET_ACCOUNTING')

    def test_two_people_are_not_merged_and_rate_not_floored_first(self):
        one = holder_cash_total(src.holder_input(self.resolution, 'PERSON-A-ENGINEERED', '1'), self.resolution)
        four = holder_cash_total(src.holder_input(self.resolution, 'PERSON-B-ENGINEERED', '4'), self.resolution)
        merged = holder_cash_total(self.input('5'), self.resolution)
        self.assertEqual(Decimal(one['rounded_approved_gross']) + Decimal(four['rounded_approved_gross']), Decimal('3'))
        self.assertEqual(merged['rounded_approved_gross'], '4')
        self.assertNotEqual(holder_cash_total(self.input('3'), self.resolution)['rounded_approved_gross'], '0')

    def test_large_quantity_precision_is_not_limited_by_default_decimal_context(self):
        q = '1' + '0' * 80 + '1'
        r = holder_cash_total(self.input(q), self.resolution)
        self.assertEqual(r['rounded_approved_gross'], str(int(q) * 8 // 10))
        self.assertEqual(r['sub_twd_remainder_to_issuer'], '0.8')

    def test_unknown_quantity_refuses_instead_of_zero_and_explicit_zero_is_scenario(self):
        r = holder_cash_total(self.input(None), self.resolution)
        self.assertEqual(r['status'], 'REFUSED_UNKNOWN_ENTITLEMENT_QUANTITY')
        for key in ('unrounded_approved_gross', 'rounded_approved_gross', 'sub_twd_remainder_to_issuer'):
            self.assertIsNone(r[key])
        zero = holder_cash_total(self.input('0'), self.resolution)
        self.assertEqual(zero['rounded_approved_gross'], '0'); self.assertTrue(zero['hypothetical'])
        data = self.input(); data['quantity_evidence'] = None
        self.assertEqual(holder_cash_total(data, self.resolution)['status'], 'REFUSED_UNKNOWN_ENTITLEMENT_QUANTITY')

    def test_invalid_or_fractional_quantity_never_silently_rounds_shares(self):
        for q in (-1, 3.0, True, '-1', '1.5', '3.0', 'NaN', 'Infinity', '', ['1', '4']):
            with self.subTest(q=q), self.assertRaises(ValueError): holder_cash_total(self.input(q), self.resolution)

    def test_fake_personal_or_verified_net_override_is_not_accepted(self):
        for key, value in [('purpose', 'INVESTOR_RECONCILIATION'), ('net_per_share', '0.8'),
                           ('net_cash', '2'), ('tax_exempt', True), ('net_distributions_verified', True),
                           ('actual_received_at', '2026-07-28')]:
            data = self.input(); data[key] = value
            with self.assertRaises(ValueError): holder_cash_total(data, self.resolution)
        data = self.input(); data['quantity_evidence']['status'] = 'VERIFIED_INVESTOR'
        with self.assertRaises(ValueError): holder_cash_total(data, self.resolution)

    def test_gross_is_never_net_cash_buying_power_or_return(self):
        r = holder_cash_total(self.input(), self.resolution)
        for key in ('net_per_share', 'investor_net_cash', 'actual_received_at', 'available_cash', 'total_net_return'):
            self.assertIsNone(r[key])
        self.assertEqual(r['daily'], []); self.assertFalse(r['policy_authorized'])

    def test_wrong_holder_instrument_issuer_or_resolution_rejected(self):
        for key, value in [('issuer_code', '2884'), ('entitled_old_code', '2867'),
                           ('old_instrument', 'ISSUER_TREASURY_SHARES'), ('resolution_id', 'old-id'),
                           ('holder_case_id', '')]:
            data = self.input(); data[key] = value
            with self.assertRaises(ValueError): holder_cash_total(data, self.resolution)

    def test_proposal_or_treasury_observation_cannot_act_as_approved_holder_rule(self):
        for record in self.catalog['inventory']:
            if record['action_type'] in ('CASH_DISTRIBUTION_PROPOSAL', 'TREASURY_REPURCHASE_OBSERVATION'):
                with self.assertRaisesRegex(ValueError, 'Approved cash resolution'):
                    holder_cash_total(src.holder_input(record, 'ENGINEERED', '3'), record)

    def test_observation_and_history_cannot_be_backdated_to_meeting(self):
        for cutoff in ('2026-05-22T00:00:00+08:00', '2026-10-23T20:00:00'):
            data = self.input(); data['observed_as_of'] = cutoff
            with self.assertRaises(ValueError): holder_cash_total(data, self.resolution)
        data = self.input(); data['historical_signal'] = True
        with self.assertRaises(ValueError): holder_cash_total(data, self.resolution)
        data = self.input(); data['observed_as_of'] = datetime.fromisoformat(self.resolution['observed_at']).astimezone(timezone(timedelta(hours=8))).isoformat()
        self.assertEqual(holder_cash_total(data, self.resolution)['rounded_approved_gross'], '2')

    def test_changed_fingerprint_or_unbound_rounding_proof_rejected(self):
        record = deepcopy(self.resolution); record['fields']['rounding_rule']['value'] = 'PER_SHARE'
        with self.assertRaisesRegex(ValueError, 'fingerprint'): holder_cash_total(self.input(), record)
        record = deepcopy(self.resolution); record['fields']['rounding_rule']['proofs'][0]['source_id'] = 'other-source'; record = identify(record)
        data = src.holder_input(record, 'ENGINEERED', '3')
        with self.assertRaisesRegex(ValueError, 'proofs'): holder_cash_total(data, record)

    def test_treasury_tranche_none_is_not_global_zero_or_holder_reduction(self):
        observations = [v['observation'] for v in self.catalog['inventory'] if v['action_type'] == 'TREASURY_REPURCHASE_OBSERVATION']
        self.assertEqual(len(observations), 2)
        sixth = next(x for x in observations if x['tranche_raw'] == '第六次')
        seventh = next(x for x in observations if x['tranche_raw'] == '第七次')
        self.assertEqual(sixth['reported_cancelled_raw'], '無'); self.assertIsNone(sixth['reported_cancelled_quantity'])
        self.assertEqual(sixth['no_cancellation_scope'], 'THIS_TRANCHE_REPORT_ONLY')
        self.assertEqual(seventh['repurchased_quantity'], '28000'); self.assertEqual(seventh['reported_cancelled_quantity'], '28000')
        self.assertEqual(seventh['actual_repurchase_start'], '2025-08-14'); self.assertEqual(seventh['actual_repurchase_end'], '2025-08-25')
        for x in observations:
            self.assertEqual(x['quantity_unit'], '張_AS_PUBLISHED')
            for key in ('cancellation_effective_date', 'holder_share_conversion_ratio', 'holder_net_capital_return'): self.assertIsNone(x[key])
        self.assertFalse(any(e['type'] == 'CAPITAL_REDUCTION' for e in self.catalog['events']))

    def test_new_qualifications_keep_approved_label_but_refuse_nonlinear_net_account(self):
        result = src.qualify_distribution(self.ledger_input(), self.catalog)
        self.assertIn('APPROVED_RESOLUTION_NOT_FINAL_ALLOCATION_OR_NET_CASH', result['refusal_reasons'])
        self.assertIn('PER_HOLDER_TOTAL_ROUNDING_UNSUPPORTED_BY_LEGACY_PER_SHARE_NET_LEDGER', result['refusal_reasons'])
        self.assertIn('NET_DISTRIBUTIONS_TAX_FEES_UNKNOWN', result['refusal_reasons'])
        self.assertIn('OPENING_ENTITLEMENTS_UNKNOWN', result['refusal_reasons'])
        self.assertIn('TREASURY_CANCELLATION_DATE_OR_HOLDER_IMPACT_UNKNOWN', result['refusal_reasons'])
        self.assertEqual(result['daily'], []); self.assertIsNone(result['total_net_return'])

    def test_fake_complete_input_flags_or_missing_inventory_never_call_daily_engine(self):
        data = self.ledger_input('2026-08-03', '2026-09-10')
        for code, c in data['coverage'].items():
            c.update(status='VERIFIED_COMPLETE', types=['CASH_DIVIDEND', 'STOCK_DIVIDEND', 'CAPITAL_REDUCTION'], other_actions_checked=True,
                     event_ids=[e['id'] for e in data['events'] if e['code'] == code and data['start'] < e['ex_date'] <= data['end']])
        data['qualification'].update(opening_claims='VERIFIED', net_distributions='VERIFIED')
        data['coverage']['1101']['known_company_action_ids'] = []
        with patch('rotation_research.action_ledger.replay', side_effect=AssertionError('Unexpected replay')):
            r = src.qualify_distribution(data, self.catalog)
        self.assertIn('SOURCE_ACTION_COVERAGE_INCOMPLETE:1101', r['refusal_reasons'])
        self.assertIn('KNOWN_COMPANY_ACTION_INVENTORY_MISSING:1101', r['refusal_reasons'])
        self.assertIn('SHARE_EXCHANGE_ACCOUNT_IMPACT_UNSUPPORTED', r['refusal_reasons'])
        self.assertFalse(r['original_numeric_replay_called'])

    def test_component_version_mismatch_and_catalog_tampering_refused(self):
        data = self.ledger_input(); data['events'] = self.old['events']
        with self.assertRaisesRegex(ValueError, 'Exact v0.4'): src.qualify_distribution(data, self.catalog)
        catalog = deepcopy(self.catalog); catalog['coverage']['1101']['status'] = 'VERIFIED_COMPLETE'
        with self.assertRaisesRegex(ValueError, 'fingerprint'): src.qualify_distribution(self.ledger_input(), catalog)

    def test_rebuild_is_deterministic_and_original_catalog_not_written(self):
        self.assertEqual(src.build_catalog(), self.catalog)
        self.assertEqual(json.loads((HERE / 'action_scope_20261023/events-v03.json').read_text()), self.old)


class ArchiveChecks(unittest.TestCase):
    def test_two_extractor_versions_have_exact_claimed_pages_and_fields(self):
        old = (src.REVIEW / 'raw/tcc-2026-agm-minutes.txt').read_text()
        current = (src.OUT / 'pdf-text-recheck-current.txt').read_text()
        index = (src.REVIEW / 'raw/tcc-meeting-index.txt').read_text()
        for page in (1, 3, 4, 6, 7):
            self.assertEqual(old.split('\f')[page-1], current.split('\f')[page-1])
        self.assertEqual(src.parse_resolution(old, index), src.parse_resolution(current, index))
        self.assertEqual(src.parse_treasury(old), src.parse_treasury(current))

    def test_corrupt_pdf_or_text_rejected_offline(self):
        with tempfile.TemporaryDirectory() as td:
            review = Path(td) / 'review'; shutil.copytree(src.REVIEW, review)
            for suffix in ('.response', '.txt'):
                p = review / 'raw' / ('tcc-2026-agm-minutes' + suffix); original = p.read_bytes(); p.write_bytes(original + b'bad')
                with self.assertRaisesRegex(ValueError, 'fingerprint'): src.load_resolution_sources(review)
                p.write_bytes(original)

    def test_source_meta_manifest_disagreement_is_not_ignored(self):
        with tempfile.TemporaryDirectory() as td:
            review = Path(td) / 'review'; shutil.copytree(src.REVIEW, review)
            p = review / 'source-manifest.json'; m = json.loads(p.read_text()); m['tcc-meeting-index']['url'] = 'https://example.com'
            p.write_text(json.dumps(m))
            with self.assertRaisesRegex(ValueError, 'meta mismatch'): src.load_resolution_sources(review)


if __name__ == '__main__': unittest.main()
