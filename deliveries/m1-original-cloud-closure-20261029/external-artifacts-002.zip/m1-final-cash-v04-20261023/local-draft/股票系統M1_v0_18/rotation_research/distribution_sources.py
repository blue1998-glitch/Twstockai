"""Offline approved-resolution source v0.4; no old producers/results changed."""
from copy import deepcopy
from datetime import date
from decimal import Decimal, localcontext, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import urlsplit, unquote

from .action_sources import ROOT, HERE, dump
from .action_scope_sources import build_catalog as build_v03, VisibleText, field, proof, compact, match
from .action_scope import identify, verify, required_inventory
from .action_study import verified_quotes, candidate_input
from .source_qualification import build_calendar, bind_observed_calendar
from .action_ledger import qualify
from .holder_cash import holder_cash_total, RULE

REVIEW = HERE / 'final_distribution_review_20261023'
OUT = HERE / 'distribution_v04_20261023'
SCHEMA = 'rotation-approved-distribution-catalog/0.4'


def resolution_section(text):
    all_text = compact(text)
    return all_text.split('四、討論事項', 1)[1].split('第二案', 1)[0] if '四、討論事項' in all_text else ''


def load_resolution_sources(review=REVIEW):
    review = Path(review)
    manifest = json.loads((review / 'source-manifest.json').read_text())
    sources, texts, bodies = {}, {}, {}
    for sid, origin in [('tcc-meeting-index', 'www.tccgroupholdings.com'),
                        ('tcc-2026-agm-minutes', 'media.taiwancement.com')]:
        meta = manifest[sid]
        stored = json.loads((review / 'raw' / (sid + '.meta.json')).read_text())
        if any(meta[k] != stored[k] for k in ('url', 'final_url', 'http', 'status', 'bytes', 'sha256', 'captured_at')):
            raise ValueError('Source manifest/meta mismatch')
        if meta['http'] != 200 or meta['status'] != 'CAPTURED' or any(urlsplit(meta[k]).scheme != 'https' or urlsplit(meta[k]).netloc != origin for k in ('url', 'final_url')):
            raise ValueError('Unverified official source origin/status')
        body = (review / 'raw' / (sid + '.response')).read_bytes()
        raw_text = (review / 'raw' / (sid + '.txt')).read_bytes()
        ex = json.loads((review / 'raw' / (sid + '.extraction.json')).read_text())
        if (hashlib.sha256(body).hexdigest() != meta['sha256'] or len(body) != meta['bytes']
                or hashlib.sha256(raw_text).hexdigest() != meta['derived_text_sha256']
                or ex.get('pdf_sha256', ex.get('source_sha256')) != meta['sha256']
                or ex['text_sha256'] != meta['derived_text_sha256']):
            raise ValueError('Official source/text fingerprint mismatch')
        if sid.endswith('minutes'):
            if not body.startswith(b'%PDF-'):
                raise ValueError('PDF source format required')
        else:
            parser = VisibleText(); parser.feed(body.decode('utf-8-sig'))
            if compact(''.join(parser.parts)) != compact(raw_text.decode('utf-8-sig')):
                raise ValueError('Index visible text does not match original')
        sources[sid] = dict(path=str((REVIEW / 'raw' / (sid + '.response')).relative_to(ROOT)),
            url=meta['url'], sha256=meta['sha256'], captured_at=meta['captured_at'], kind='OFFICIAL_ARCHIVE',
            derived_text_path=str((REVIEW / 'raw' / (sid + '.txt')).relative_to(ROOT)),
            derived_text_sha256=meta['derived_text_sha256'], historical_publication_time='NOT_AUTHENTICATED')
        texts[sid] = raw_text.decode('utf-8-sig'); bodies[sid] = body
    if unquote(sources['tcc-2026-agm-minutes']['url']) not in unquote(bodies['tcc-meeting-index'].decode('utf-8-sig')):
        raise ValueError('Official index does not link the actual PDF')
    return texts, sources


def parse_resolution(text, index_text):
    section = resolution_section(text)
    if not section.startswith('第一案') or '本案依表決結果，照案通過。' not in section:
        raise ValueError('First discussion approval not authenticated')
    label = match(r'二、本公司擬以(.+?)之資本公積提撥新台幣', section)[1]
    total = match(r'提撥新台幣\(以下同\)([\d,]+)元', section)[1].replace(',', '')
    rate = match(r'每股發放([\d.]+)元', section)[1]
    if ('每位普通股股東發放現金總額至元為止(元以下捨去)' not in section
            or '其畸零款合計數計入本公司之其他收入' not in section):
        raise ValueError('Per-holder total rounding/remainder rule missing')
    if '現金比率發生變動而需修正時，授權董事長全權處理' not in section or '授權董事長另行訂定發放現金基準日及發放日' not in section:
        raise ValueError('Adjustment/date authority must remain explicit')
    prefixes = {'attending': '表決時出席股東表決權數', 'yes': '贊成權數',
                'no': '反對權數', 'invalid': '無效權數', 'abstain': '棄權與未投票權數'}
    votes = {k: match(prefix + r'[：:]([\d,]+)權', section)[1].replace(',', '') for k, prefix in prefixes.items()}
    if sum(int(v) for k, v in votes.items() if k != 'attending') != int(votes['attending']):
        raise ValueError('Scoped vote rights do not sum to attending rights')
    published = match(r'贊成權數[：:][\d,]+權([\d.]+)%', section)[1]
    with localcontext() as context:
        context.prec = 50
        percent = Decimal(votes['yes']) / Decimal(votes['attending']) * 100
        if percent.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP) != Decimal(published):
            raise ValueError('Scoped vote percent mismatch')
    meeting = match(r'(\d{4})股東常會日期(\d{4})\.(\d{2})\.(\d{2})', compact(index_text))
    if meeting[1] != meeting[2]:
        raise ValueError('Meeting edition/date mismatch')
    return dict(meeting_date=date(*map(int, meeting.groups()[1:])).isoformat(),
        approved_cash_per_share=rate, approved_total_twd=total, approved_funding_label_raw=label,
        votes=votes, published_yes_percent=published, ratio_adjustment_authorized=True,
        record_and_payment_dates_delegated=True, resolution_record_date=None, resolution_pay_date=None,
        rounding_rule=RULE, source_pages=[6, 7], tax_origin_subtype=None,
        final_after_authorized_adjustments_authenticated=False)


def parse_treasury(text):
    found = []
    for page_no, page in enumerate(text.split('\f'), 1):
        s = compact(page)
        if '買回期次第' not in s or '實際買回期間' not in s:
            continue
        tranche = match(r'買回期次(第[^次]+次)', s)[1]
        when = match(r'實際買回期間(\d+)年(\d+)月(\d+)日至(\d+)年(\d+)月(\d+)日', s)
        parts = list(map(int, when.groups()))
        iso = lambda p: date(p[0] + 1911, p[1], p[2]).isoformat()
        quantity = match(r'實際買回股份之數量([\d,]+)張', s)[1].replace(',', '')
        cancelled = match(r'已辦理銷除之股份數量(無|[\d,]+張)', s)[1]
        found.append(dict(tranche_raw=tranche, source_page=page_no, actual_repurchase_start=iso(parts[:3]),
            actual_repurchase_end=iso(parts[3:]), repurchased_quantity=quantity, quantity_unit='張_AS_PUBLISHED',
            reported_cancelled_raw=cancelled,
            reported_cancelled_quantity=None if cancelled == '無' else cancelled.removesuffix('張').replace(',', ''),
            no_cancellation_scope='THIS_TRANCHE_REPORT_ONLY' if cancelled == '無' else None,
            cancellation_effective_date=None, holder_share_conversion_ratio=None, holder_net_capital_return=None))
    if not found:
        raise ValueError('No scoped treasury observations found')
    return found


def build_catalog():
    text, sources = load_resolution_sources()
    old = build_v03()
    saved = json.loads((HERE / 'action_scope_20261023/events-v03.json').read_text())
    if old != saved:
        raise ValueError('v0.3 source/catalog drift; never overwrite it')
    parsed = parse_resolution(text['tcc-2026-agm-minutes'], text['tcc-meeting-index'])
    treasury = parse_treasury(text['tcc-2026-agm-minutes'])
    reviewed = json.loads((REVIEW / 'facts.json').read_text())
    rr = reviewed['distribution_resolution']
    if any(parsed[k] != rr[v] for k, v in [('approved_cash_per_share', 'approved_cash_per_share'),
            ('approved_total_twd', 'approved_total_twd'), ('approved_funding_label_raw', 'approved_capital_surplus_label_raw')]) or parsed['meeting_date'] != reviewed['meeting_date']:
        raise ValueError('New extraction disagrees with reviewed resolution fields')
    catalog = deepcopy(old); catalog.pop('id')
    catalog.update(schema=SCHEMA, supersedes_catalog_id=old['id'], sources={**old['sources'], **sources})
    sid = 'tcc-2026-agm-minutes'; document = text[sid]
    def p(pattern):
        m = match(pattern, resolution_section(document))
        return [dict(source_id=sid, locator='PDF pages 6-7, first discussion compact section chars ' + str(m.start()) + ':' + str(m.end()), raw_value=m[0])]
    fields = dict(
        approved_cash_per_share=field(parsed['approved_cash_per_share'], 'TWD_PER_OLD_ORDINARY_SHARE', 'APPROVED_RESOLUTION_RATE_NOT_FINAL_AFTER_ADJUSTMENTS', p(r'每股發放[\d.]+元'), 'SHAREHOLDER_APPROVED_AS_STATED'),
        approved_total_twd=field(parsed['approved_total_twd'], 'TWD', 'ISSUER_APPROVED_POOL_NOT_ONE_HOLDER_CASH', p(r'提撥新台幣\(以下同\)[\d,]+元')),
        approved_funding_label_raw=field(parsed['approved_funding_label_raw'], 'SOURCE_LABEL_AS_STATED', 'SHAREHOLDER_APPROVED_LABEL_NOT_TAX_ORIGIN_CERTIFICATE', p(r'二、本公司擬以.+?之資本公積提撥新台幣')),
        rounding_rule=field(RULE, 'PER_HOLDER_TOTAL_TWD', 'ORDINARY_HOLDER_CASH_TOTAL_NOT_PER_SHARE_NET', p(r'每位普通股股東發放現金總額至元為止\(元以下捨去\)')),
        meeting_date=field(parsed['meeting_date'], 'ISO_DATE', 'MEETING_DATE_NOT_EX_OR_RECORD_OR_PAYMENT', proof('tcc-meeting-index', text['tcc-meeting-index'], r'\d{4}股東常會日期\d{4}\.\d{2}\.\d{2}')),
        record_date=field(None, 'ISO_DATE', 'DELEGATED_NOT_STATED_IN_RESOLUTION', []),
        pay_date=field(None, 'ISO_DATE', 'DELEGATED_NOT_STATED_IN_RESOLUTION', []),
        tax_origin_subtype=field(None, 'TAX_ORIGIN', 'NOT_AUTHENTICATED_FOR_NET_MODEL', []),
        investor_net_cash=field(None, 'TWD', 'INVESTOR_NET_RECEIPT', []))
    old_proposal = next(v for v in old['inventory'] if v['action_type'] == 'CASH_DISTRIBUTION_PROPOSAL' and v['issuer_code'] == '1101')
    approved = identify(dict(family=old_proposal['family'], issuer_code='1101', entitled_old_code='1101',
        action_type='CAPITAL_SURPLUS_CASH_RESOLUTION', old_instrument=old_proposal['old_instrument'],
        company_codes=['1101'], source_ids=list(sources), observed_at=max(s['captured_at'] for s in sources.values()),
        historical_signal_eligible=False, announced_at=None, stage='SHAREHOLDER_APPROVED_RESOLUTION', fields=fields,
        resolution_facts=parsed, related_proposal_id=old_proposal['id']))
    catalog['inventory'].append(approved)
    catalog['version_relations'].append(dict(earlier_document_version=old_proposal['id'],
        later_document_version=approved['id'], role='PROPOSAL_TO_APPROVED_NOT_AUTOMATIC_FINAL_ALLOCATION_SELECTION'))
    for observation in treasury:
        catalog['inventory'].append(identify(dict(family='1101-treasury:' + observation['tranche_raw'],
            issuer_code='1101', entitled_old_code=None, old_instrument='ISSUER_TREASURY_SHARES',
            action_type='TREASURY_REPURCHASE_OBSERVATION', stage='ISSUER_REPORTED_TRANCHE_NOT_HOLDER_REDUCTION',
            company_codes=['1101'], source_ids=[sid], observed_at=sources[sid]['captured_at'],
            historical_signal_eligible=False, announced_at=None, fields={}, observation=observation)))
    # One explicit matching legacy component; no inferred final dates or net rate.
    candidates = [e for e in catalog['events'] if e['type'] == 'CASH_DIVIDEND' and e['code'] == '1101'
                  and e['ex_date'][:4] == parsed['meeting_date'][:4] and e['gross_per_share'] == parsed['approved_cash_per_share']]
    if len(candidates) != 1:
        raise ValueError('Approved resolution does not match one saved issuer cash component')
    event = candidates[0]; parent = event.pop('id')
    event.update(supersedes_event_id=parent, prior_component_observed_at=event['observed_at'],
        observed_at=max(event['observed_at'], approved['observed_at']), approval_resolution_id=approved['id'],
        approved_funding_label_raw=parsed['approved_funding_label_raw'], rounding_rule=RULE,
        final_after_authorized_adjustments_authenticated=False, tax_origin_subtype=None)
    event['source_ids'] += list(sources)
    event['field_sources']['approved_funding_label_raw'] = deepcopy(fields['approved_funding_label_raw']['proofs'])
    event['field_sources']['rounding_rule'] = deepcopy(fields['rounding_rule']['proofs'])
    event.update(identify(event))
    for code, c in catalog['coverage'].items():
        c['event_ids'] = [event['id'] if i == parent else i for i in c['event_ids']]
        c['known_company_action_ids'] = required_inventory(catalog, code)
        if code == '1101':
            c['source_ids'] = sorted(set(c['source_ids']) | set(sources))
            c['gaps'].append('TREASURY_CANCELLATION_DATE_AND_HOLDER_IMPACT_UNKNOWN')
    catalog['approved_resolution_id'] = approved['id']
    catalog['source_supplement_scope'] = 'APPROVED_LABEL_AND_HOLDER_TOTAL_ROUNDING_NOT_NET_RECEIPT_OR_COMPLETE_COVERAGE'
    return identify(catalog)


def qualify_distribution(data, catalog):
    verify(catalog)
    if catalog['schema'] != SCHEMA or data['events'] != catalog['events']:
        raise ValueError('Exact v0.4 catalog/event components required')
    reasons = qualify(data); findings = []
    def add(reason, **evidence):
        reasons.append(reason); findings.append(dict(reason=reason, **evidence))
    for code in data['assets']:
        if code not in catalog['coverage']:
            raise ValueError('Unknown asset code')
        if data['coverage'][code].get('known_company_action_ids') != required_inventory(catalog, code):
            add('KNOWN_COMPANY_ACTION_INVENTORY_MISSING:' + code)
        if catalog['coverage'][code]['status'] != 'VERIFIED_COMPLETE':
            add('SOURCE_ACTION_COVERAGE_INCOMPLETE:' + code)
    for v in catalog['inventory']:
        verify(v)
        when = v['fields'].get('scheduled_effective_date', {}).get('value')
        if v['action_type'] == 'SHARE_EXCHANGE' and when and data['start'] <= when <= data['end'] and set(v['company_codes']) & set(data['assets']):
            add('SHARE_EXCHANGE_ACCOUNT_IMPACT_UNSUPPORTED', inventory_id=v['id'])
        if (v['action_type'] == 'TREASURY_REPURCHASE_OBSERVATION' and v['issuer_code'] in data['assets']
                and v['observation']['reported_cancelled_quantity'] is not None):
            add('TREASURY_CANCELLATION_DATE_OR_HOLDER_IMPACT_UNKNOWN', inventory_id=v['id'],
                holder_share_conversion_ratio=None, holder_net_capital_return=None)
    for e in data['events']:
        if not data['start'] < e['ex_date'] <= data['end']:
            continue
        if e.get('approval_resolution_id'):
            add('APPROVED_RESOLUTION_NOT_FINAL_ALLOCATION_OR_NET_CASH', resolution_id=e['approval_resolution_id'])
            add('PER_HOLDER_TOTAL_ROUNDING_UNSUPPORTED_BY_LEGACY_PER_SHARE_NET_LEDGER', event_id=e['id'])
        elif e['type'] == 'CASH_DIVIDEND':
            add('FINAL_CASH_DISTRIBUTION_NATURE_UNVERIFIED:' + e['id'])
        if e['type'] == 'STOCK_DIVIDEND':
            add('FINAL_ALLOTMENT_AND_FRACTION_DISPOSITION_UNKNOWN:' + e['id'])
    if not reasons:
        raise ValueError('Net ledger path not implemented in this source/rounding version')
    return dict(schema='rotation-distribution-qualification/0.4', input_id=identify(data)['id'],
        catalog_id=catalog['id'], start=data['start'], end=data['end'], status='REFUSED_INCOMPLETE_EVENT_ACCOUNTING',
        refusal_reasons=sorted(set(reasons)), findings=findings, daily=[], journal=[],
        total_net_return=None, scenario_net_return=None, actual_realized_investor_return=None,
        original_numeric_replay_called=False, historical_signal_eligible=False, primary_pressure_id=None, policy_authorized=False)


def holder_input(resolution, case_id, quantity):
    return dict(schema='rotation-holder-cash-scenario/0.1', purpose='APPROVED_RATE_HYPOTHETICAL',
        resolution_id=resolution['id'], holder_case_id=case_id, issuer_code=resolution['issuer_code'],
        entitled_old_code=resolution['entitled_old_code'], old_instrument=resolution['old_instrument'],
        observed_as_of=resolution['observed_at'], historical_signal=False, quantity_shares=quantity,
        quantity_evidence=None if quantity is None else dict(status='DECLARED_SCENARIO',
            definition='ENGINEERED_CONSTANT_ENTITLED_QUANTITY_NOT_USER_ACCOUNT_OR_MARKET_RESULT'))


def main():
    OUT.mkdir(exist_ok=True); catalog = build_catalog()
    resolution = next(v for v in catalog['inventory'] if v['id'] == catalog['approved_resolution_id'])
    old, manifest = verified_quotes(); calendar = build_calendar()
    dates = [b['date'] for b in old['assets']['1101']['bars']]
    design = json.loads((HERE / 'generated/design.json').read_text()); windows = []
    for start in design['cutoffs']:
        for a, b in [('1101', '2884'), ('2884', '1101')]:
            for horizon in design['horizons']:
                i = dates.index(start)
                if i + horizon >= len(dates):
                    windows.append(dict(A=a, B=b, start=start, end=None, horizon=horizon, status='INSUFFICIENT_SAVED_FORWARD_ROWS')); continue
                data = bind_observed_calendar(candidate_input(old, catalog, manifest, start, dates[i + horizon], a), calendar)
                windows.append(dict(A=a, B=b, horizon=horizon, **qualify_distribution(data, catalog)))
    probe = holder_input(resolution, 'UNKNOWN_REAL_ENTITLEMENT_PROBE_NOT_USER_ACCOUNT', None)
    examples = [dict(input=holder_input(resolution, 'ENGINEERED-' + q, q),
                     result=holder_cash_total(holder_input(resolution, 'ENGINEERED-' + q, q), resolution))
                for q in ('0', '1', '3', '4', '5', '6', '1001')]
    dump(OUT / 'events-v04.json', catalog)
    dump(OUT / 'window-qualification.json', dict(windows=windows, qualified_windows=0, ranking=None))
    dump(OUT / 'unknown-holder-input.json', probe); dump(OUT / 'unknown-holder-refusal.json', holder_cash_total(probe, resolution))
    dump(OUT / 'engineered-gross-examples.json', examples)
    summary = dict(new_official_archives_rechecked=2, original_quote_archives_rechecked=len(manifest),
        scoped_source_versions=len(catalog['inventory']), ledger_components=len(catalog['events']),
        qualification_windows=sum(w['end'] is not None for w in windows), insufficient_windows=sum(w['end'] is None for w in windows),
        exchange_unsupported_windows=sum('SHARE_EXCHANGE_ACCOUNT_IMPACT_UNSUPPORTED' in w.get('refusal_reasons', []) for w in windows),
        total_net_return_qualified_windows=0, engineered_gross_cases=len(examples), original_numeric_replay_calls=0,
        new_strategy_replays=0, new_official_network_requests=0, browser_runs=0, android='NOT_TESTED_NEW_BUILD')
    dump(OUT / 'verification.json', summary); print(json.dumps(summary))


if __name__ == '__main__':
    main()
