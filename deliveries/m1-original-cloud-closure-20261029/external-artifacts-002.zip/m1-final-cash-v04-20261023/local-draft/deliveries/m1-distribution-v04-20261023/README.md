# M1正式決議與每人毛額圓整0.4

[直接下載小包](m1-distribution-v04-20261023.zip?raw=true)，6,655,258 bytes（約6.35 MiB）。解壓至新目錄，先開DISTRIBUTION_V04_START_HERE.md。

SHA256：`eede933c0158d229f786f2982d9731fd23f5ca803013d0f6ae366db8d3521e4e`；[SHA256SUMS](SHA256SUMS)、[封包收據](bundle-receipt.json)、[解壓重現收據](package-verification.json)、[26測試](extracted-tests.log)。原0.3小包470成員逐位元保留；五層manifest依序517／469／409／374／292成員全核對通過。

[本輪入口／契約](../../股票系統M1_v0_18/rotation_research/distribution_v04_20261023/README.md)、[實作／實測／錯誤與限制](../../股票系統M1_v0_18/rotation_research/distribution_v04_20261023/REPORT.md)、[完整Work續接指令](../../股票系統M1_v0_18/rotation_research/distribution_v04_20261023/WORK_HANDOFF.md)。固定成品提交與逐檔GitHub回讀見[GITHUB_READBACK.md](GITHUB_READBACK.md)。

正式決議新增來源版本，舊提案不覆寫；每人毛額先乘股數再對總額至元捨去，不先捨每股、不合併不同人、不除回net_per_share。26新定向測試及新目錄離線重建通過。7工程毛額例非個人帳戶；未知權利股數probe拒算。

70窗新資格仍拒算、2不足、8換股影響未支援，真正總淨報酬合格0。原每日帳／六方案重跑0，未實作每人淨額每日入帳；稅費、最後分配、實際到款／期初權利及完整行動仍缺。額外PDF抽字全文byte比較失敗及差異已保留，所用頁／欄位完全一致，見REPORT。無UI／Android、舊引擎策略庫歷史catalog與ZIP及main保持。下一步Work補來源，明確工程交Codex。
