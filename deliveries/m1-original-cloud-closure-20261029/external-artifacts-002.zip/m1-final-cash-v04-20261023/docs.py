from pathlib import Path
import json,subprocess,hashlib
root=Path('/workspace/Twstockai');p=root/'股票系統M1_v0_18/rotation_research/distribution_v04_20261023'
(p/'README.md').write_text('''# 正式分配決議與每人毛額圓整 0.4

本輪可執行獨立版本；原0.3／引擎／策略／庫／歷史／舊成品保持。正式決議來源已接入，但真實總淨報酬仍拒算。

- [輸入輸出契約](CONTRACT.md)、[實作／實測／錯誤及未完成](REPORT.md)、[完整Work續接指令](WORK_HANDOFF.md)。
- [新catalog](events-v04.json)：保留0.3所有來源版本，新增股東會通過及兩次庫藏股報告，不能把庫藏股銷除套成股東減資。
- [工程毛額案例](engineered-gross-examples.json)：假設權利股數，不是個人帳戶／投資績效。
- [缺權利股數的拒算](unknown-holder-refusal.json)、[新72窗口資格核對](window-qualification.json)、[摘要](verification.json)、[26測試](tests.log)。
- [PDF抽字額外核對](pdf-extraction-recheck.json)：整份文字非逐位元相同，所用頁／全部欄位相同；首個失敗與差異均保留，詳見REPORT。
- 可下載小包、SHA、實際解壓及固定GitHub回讀：根deliveries/m1-distribution-v04-20261023/README.md。

標準Python離線重現：
```bash
cd 股票系統M1_v0_18
python3 -m unittest rotation_research.test_distribution_v04 -v
python3 -m rotation_research.distribution_sources
```
只寫本新目錄；不連網、不改舊輸出、不需安裝依賴。PDF原件與兩版衍生文字均已封存，離線producer不需pdftotext。

每人毛額純函數為holder_cash.holder_cash_total，先依契約用distribution_sources.holder_input指定**假設權利股數**及明確決議版本，再傳入來源已核的resolution。3股×0.8＝2.4，該人總額捨去為2；1股及4股兩人分別為0與3，不能合併成5股的一人4元。所有net／actual receipt／return皆null；沒有把毛額除股數做net_per_share。
''')
(p/'REPORT.md').write_text('''# 0.4本輪實作與實測（2026-10-23）

起點d11cd18a53d688eae4602461392a6602313cea9f，遠端核對後fast-forward，保留0.3及全部後續。實際完整checkout重新bootstrap --hydrate-missing成功：0補缺、7既有差異保留、baseline_verified=true，見bootstrap.log。

## 實際修改

1. 新distribution_sources外部producer重核台泥兩官方原件、SHA／HTTP／origin、HTML可見文字、實際PDF連結與衍生文字雙指紋；只在討論第一案抽來源標籤、0.8元、5,994,545,394元、94.64%及表決總和，避免引用前案94.58%。重核31類來源結論不冒作重跑前輪31檢查。
2. 新catalog0.4新增股東會通過階段，保留0.3董事會提案與其ID／觀察時點；1101相符現金組件另存父ID、新來源與每人圓整。既有交易所ex_date、issuer record_date／pay_date及原毛額／net=null保持。股東會日、決議未載日期及未知稅務細項不補值；授權調整後最後分配尚未認證。
3. 先新增CONTRACT，再作純數值holder_cash_total：按一人一事件的假設權利股數乘決議比率，對總額至元捨去，分列餘款。不同人不合併、每股不先捨去，不除回通用每股淨額。明示工程股數才出毛額；未知股數拒算。淨額、個人到款、可用現金、每日帳及報酬全不計算。
4. 第六／七次庫藏股報告只入inventory，原張數保留；第六次「無」不變全期0，第七次28,000張銷除沒有生效日／股東轉換比／退資。不產生CAPITAL_REDUCTION帳事件，也不推缺價原因。
5. 新資格層針對正式決議、每人非線性圓整與未知庫藏股影響給明確拒因。沒有把新毛額總額塞入原固定net_per_share帳，亦未改舊action_scope／producer／action_ledger／core／策略／庫／歷史。

## 本輪實際執行

- 26項新定向unittest通過：決議／前案範圍、表決權數與百分比、來源標籤、不同股東與每股／總額圓整、大整數精度、未知不補零、錯版本／instrument／時間、淨額旗標拒用、來源破損、庫藏股不混減資及舊版本不改。
- 首輪producer與25測試通過；後續增加PDF版本相容核對測試後最終26通過。tests-first及tests.log均保留。來源producer及原件驗證離線執行，沒有新官方網路請求／安全拒絕重試或新依賴安裝。
- 重新核原122價量原件／輸入與舊0.3重建相符；新資格實際執行70窗，全部REFUSED，2窗不足；8窗仍有換股影響未支援。output-verification逐列核所有daily／journal空、報酬null，原每日numeric replay／六方案重跑0。
- 7個明示工程毛額案例及1個未知權利股數probe實際執行；前者只是批准比率下的毛額算術，後者三毛額null。沒有真實個人配息帳或淨績效結果。

## 額外PDF抽字失敗與診斷

本機pdftotext為25.03.0，Work封存版本為24.02.0。初次整份文字逐位元比較assert失敗：舊文字54,910bytes，新文字54,843bytes。原PDF／舊文字未動，另存新文字、pdf-extraction-first-failure與完整diff。差異只在附錄兩處斷行／重複逗號；**所用第1、3、4、6、7頁逐位元相同，全部決議及庫藏股欄位亦完全相同**，精確比對後新增定向測試，沒有放寬數值容差或改原件湊通過。額外重抽不等全文逐位元重現成功，也不是完整公司行動覆蓋證明。

## 仍未完成

兩股完整公司行動／減資及2026/7/25後權息、庫藏股銷除生效／股東影響、2884未圓整實配／2025可賣日／零股與換股對原股東影響、台泥調整後最後分配及適用稅務細項法規、個人淨分配／實際到款及各起日期初權利仍缺。每人圓整淨額的每日入帳新契約未實作；不能使用本毛額情境作替代。真正總淨報酬合格0、無六方案／排名／最適比例或飛輪驗證。

原MOPS／TWT49U/TWT48U／TWTAUU／file://／NHI403及本次公報PDF403均未請求重試繞過。1101 2025/8/13、2884 2025/11/5缺報價原因UNKNOWN，未補行情。Raw公司行動、五年Adjusted、歷史公布、主檔及SQLite未知保持。沒有UI／瀏覽器／Android新驗收（NOT_TESTED_NEW_BUILD）；原24／17／44／15及18／9982／Chrome36未重跑。

封包解壓／manifest／遠端逐檔核對，只以delivery/package-verification及GITHUB_READBACK實際紀錄為準。舊成果保存見preservation.json。下一步Work補具體來源與淨額／期初權利證據，定義清楚的工程再交Codex；不重問已答策略或比例。
''')
prompt='''接續blue1998-glitch/Twstockai，分支dev/m1-v018-chart-annotations。先查遠端最新，確認包含d11cd18a53d688eae4602461392a6602313cea9f及其後distribution_v04_20261023工程／固定GitHub回讀收據，保留0.3及全部後續，不回退、不用main或舊ZIP覆蓋。最新已核提交以deliveries/m1-distribution-v04-20261023/GITHUB_READBACK.md及分支頭實讀為準。
依序讀根AGENTS、CONTINUE_IN_WORK_MODE、PROJECT_VISION、M1_V019_GRAPH_CORE_RESUME_HANDOFF最新節；全文讀股票系統M1_v0_18/rotation_research/distribution_v04_20261023的README、CONTRACT、REPORT、WORK_HANDOFF、events-v04、unknown-holder-refusal、verification、output-verification、pdf-extraction-recheck與first-failure／diff及delivery回讀收據；再讀final_distribution_review_20261023原WORK_HANDOFF、facts及network-limitations。原0.3／0.2／事件帳與保存契約持續適用。
本輪已實作獨立來源0.4與holder_cash純毛額函數，26新定向測試通過。兩新官方原件與122價量原件重核；股東會通過0.8元資本公積來源標籤／總額／表決已接，舊提案及原ID／時間保持。每人總額至元捨去，不先捨每股、不合併不同人、不除回通用net_per_share。7個工程假設權利股數案例僅毛額，未知股數probe拒算，淨額／到款／可用現金／報酬null；不是個人績效或每日淨帳。股東會通過不等調整後最後分配或稅務細項已核。
原第六次庫藏股無銷除只屬該次；第七次28,000張報告銷除仍缺生效日／持有人影響，不套每人股數減資或退資。本輪新資格實跑70窗全拒算、2不足、8換股影響未支援，真正總淨報酬合格0，無原每日numeric replay／六方案或排名。26是本輪數字，舊24／17／44／15及18／9982／Chrome36未重跑，無新UI／Android。
額外pdftotext25.03整份抽字與原24.02非逐位元一致，首個assert失敗與差異已存；所用1／3／4／6／7頁及全部抽取欄位精確相同，原件／舊文字未改。不要把額外核對說成全文byte equal或重做來源研究。
下一步Work優先補完整兩股行動／減資及7/25後權息、台泥最終調整分配／稅務細項法規、銷除生效日／股東影響、2884未圓整／2025可賣日／零股及換股對原2884影響，個人淨分配／實際入帳及起初權利要有來源，或另訂來源充分、情境／稅籍明示的總額模型。不假設零稅費／零權利，不拿公司發放當個人收款；私人券商／集保原件不提交公開Git。每人總額的淨額／每日入帳若需工程，另做獨立明示契約，不能繞過原net_per_share不足直接算績效。
工程用Codex，在實際完整checkout按最新AGENTS重新bootstrap --hydrate-missing成功後只做獨立新版本，保留holder_cash／distribution_sources0.4、action_scope0.3／舊producer／action_ledger／core／策略參數／庫／歷史／舊catalog／頁／ZIP與main。缺資料維持unknown／refused，所有MOPS／TWT49U/TWT48U／TWTAUU307／file://／NHI403及公報PDF403不重試／換路徑繞過；其他獨立官方來源可讀才保存URL／時點／SHA／適用對象／欄位，不用零命中證無事件。兩個缺價日原因及Raw／五年Adjusted／歷史公布／主檔／SQLite未知保持。
全換／分批／觸發仍研究變數，不重問P0～P1、不加策略門檻或自動下單。不部署付費交易訊息子代理，historical_signal_eligible=false、primary_pressure_id=null、policy_authorized=false，Android NOT_TESTED_NEW_BUILD、圖形NOT_VALIDATED、交易／飛輪NOT_EVALUATED。適量實測，同分支逐節點保存並固定提交逐檔GitHub回讀；結束列實際完成／未完成、成品／SHA／最新已核提交及下一步Work或Codex，附完整續接指令。'''
(p/'WORK_HANDOFF.md').write_text('# 完整回Work／後續Codex指令\n\n下一步Work補來源，工程交Codex；固定提交與回讀狀態見delivery收據。\n\n```text\n'+prompt+'\n```\n')
latest='''# 2026-10-23 Codex｜正式決議來源0.4與每人毛額圓整已實作

接續d11cd18a，保留0.3及全部後續；新入口 `股票系統M1_v0_18/rotation_research/distribution_v04_20261023/README.md`、CONTRACT／REPORT／WORK_HANDOFF，ZIP及固定GitHub回讀入口 `deliveries/m1-distribution-v04-20261023/README.md`。原提案／正式來源原件及舊catalog／引擎／策略／庫／歷史與成品保持。

重新bootstrap成功（0補缺／7差異保留）。新distribution_sources重核正式決議與表決總數／94.64%、來源標籤／總額／調整與日期授權；新增holder_cash獨立明示毛額契約。假設權利股數先乘決議0.8，再對一人總額至元捨去；不先捨每股、不合併不同人、不除回net_per_share。7個工程毛額案例不當個人到款；未知股數probe拒算，所有淨額／可用現金／每日帳／報酬null。庫藏股第六次無銷除只屬該次，第七次28000張不套成股東減資。

26新定向測試通過，122原價量原件及舊0.3重建再核。新資格實跑70窗仍拒算、2不足、8換股影響未支援，真正總淨報酬合格0，原每日numeric replay／六方案重跑0。額外PDF抽字25.03與原24.02全文byte assert失敗留存；所用1／3／4／6／7頁與全部欄位精確同，原件不改，詳新REPORT。舊24／17／44／15及18／9982／Chrome36未重跑；本輪無新官方網路／UI／瀏覽器Android，Android仍未測。

完整行動／減資及7/25後權息、最終調整／稅務細項、銷除生效與股東影響、2884精度／可賣日／零股與換股影響、淨分配及期初權利仍缺。每人淨額每日入帳未實作，不能以毛額替代。所有既錄安全拒絕不重試繞過，兩缺價原因及Raw／五年Adjusted／歷史公布／主檔／SQLite未知保持。下一步Work補來源，清楚工程交Codex，完整可貼指令見新WORK_HANDOFF；不改main、不問已答策略／比例，不部署付費交易訊息或子代理。以下原文完整保留。

---

'''
for rel in ('AGENTS.md','CONTINUE_IN_WORK_MODE.md','M1_V019_GRAPH_CORE_RESUME_HANDOFF.md','股票系統M1_v0_18/rotation_research/README.md','股票系統M1_v0_18/rotation_research/WORK_HANDOFF.md','股票系統M1_v0_18/rotation_research/DATA_QUALIFICATION.md'):
 f=root/rel;b=f.read_bytes();assert not b.startswith(latest.encode());f.write_bytes(latest.encode()+b)
base=json.loads(Path('/workspace/m1-final-cash-v04-20261023/baseline.json').read_text());unchanged=0;changed=[]
for name,digest in base['files'].items():
 b=(root/name).read_bytes()
 if hashlib.sha256(b).hexdigest()==digest:unchanged+=1;continue
 before=subprocess.check_output(['git','show',base['commit']+':'+name],cwd=root);assert b.endswith(before),name;changed.append(name)
assert len(changed)==6
(p/'preservation.json').write_text(json.dumps(dict(base_commit=base['commit'],original_tracked_files=len(base['files']),byte_identical=unchanged,prefix_only_original_bytes_exact_suffix=changed,deleted_files=0,all_original_code_data_catalogs_stores_history_and_zips_unchanged=True),ensure_ascii=False,indent=2)+'\n')
