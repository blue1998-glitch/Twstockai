from pathlib import Path
import subprocess,json,hashlib,zipfile,tempfile
root=Path('/workspace/Twstockai');d=root/'deliveries/m1-resolution-validation-20261023';bundle=d/'m1-resolution-verified-v04-20261023.zip'
receipt=json.loads((d/'bundle-receipt.json').read_text());assert hashlib.sha256(bundle.read_bytes()).hexdigest()==receipt['sha256']
with tempfile.TemporaryDirectory(dir='/workspace',prefix='m1-resolution-verified-') as td:
 extracted=Path(td)
 with zipfile.ZipFile(bundle) as z:
  assert z.testzip() is None;z.extractall(extracted)
  with zipfile.ZipFile(root/'deliveries/m1-action-resolution-20261023/m1-action-resolution-v04-20261023.zip') as old:
   assert all(z.read(n)==old.read(n) for n in old.namelist());old_count=len(old.namelist())
  counts={}
  for n in ('RESOLUTION_VALIDATION_MANIFEST.json','ACTION_RESOLUTION_MANIFEST.json','ACTION_SCOPE_MANIFEST.json','OFFICIAL_ACTIONS_MANIFEST.json','SOURCE_QUALIFICATION_MANIFEST.json','ACTION_PACKAGE_MANIFEST.json'):
   m=json.loads(z.read(n));assert all(hashlib.sha256(z.read(p)).hexdigest()==s for p,s in m.items());counts[n]=len(m)
 project=extracted/'股票系統M1_v0_18'
 for name,args in [('extracted-tests.log',['python3','-m','unittest','rotation_research.test_action_resolution','rotation_research.test_resolution_validation','-v']),('extracted-producer.log',['python3','-m','rotation_research.action_resolution_sources'])]:
  r=subprocess.run(args,cwd=project,capture_output=True,text=True);(d/name).write_text(r.stdout+r.stderr);r.check_returncode()
 m=json.loads((extracted/'RESOLUTION_VALIDATION_MANIFEST.json').read_text());assert all(hashlib.sha256((extracted/p).read_bytes()).hexdigest()==s for p,s in m.items())
 old_out=project/'rotation_research/action_resolution_20261023';w=json.loads((old_out/'window-qualification.json').read_text())['windows'];actual=[r for r in w if r['end']]
 assert len(actual)==70 and len(w)-len(actual)==2 and all(r['daily']==[] and r['total_net_return'] is None for r in actual)
 assert sum('SHARE_EXCHANGE_ACCOUNT_IMPACT_UNSUPPORTED' in r['refusal_reasons'] for r in actual)==8
 r=dict(bundle_sha256=receipt['sha256'],fresh_extraction='PASS',tests=31,canonical_tests=29,additional_tests=2,offline_canonical_producer='PASS',canonical_members_byte_exact=old_count,manifest_counts=counts,all_members_unchanged_after_reproduction=True,refused_windows=70,insufficient_windows=2,exchange_unsupported_windows=8,qualified_total_net_return_windows=0,numeric_replay_calls=0,android='NOT_TESTED_NEW_BUILD')
 (d/'package-verification.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r))
