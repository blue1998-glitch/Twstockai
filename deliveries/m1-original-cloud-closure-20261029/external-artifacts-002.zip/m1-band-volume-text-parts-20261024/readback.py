from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import subprocess,json,hashlib,urllib.request,urllib.parse,datetime

repo=Path('/workspace/Twstockai');scratch=Path('/workspace/m1-band-volume-text-parts-20261024')
commit='6d35b7f0e8aefa8d28f1640d0619b28754c4024f'
directory='deliveries/m1-band-volume-text-parts-20261024'
paths=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','-z',commit],cwd=repo).decode().split('\0')[:-1]
assert len(paths)==23 and all(p.startswith(directory+'/') for p in paths)
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):return None
def read(path):
 expected=subprocess.check_output(['git','show',commit+':'+path],cwd=repo)
 url='https://raw.githubusercontent.com/blue1998-glitch/Twstockai/'+commit+'/'+urllib.parse.quote(path,safe='/')
 row=dict(path=path,url=url,requested_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),expected_bytes=len(expected),expected_sha256=hashlib.sha256(expected).hexdigest(),retries=0,redirects_followed=False)
 data=None
 try:
  with urllib.request.build_opener(NoRedirect()).open(url,timeout=60) as response:
   row['http']=response.status;data=response.read()
  row.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),full_bytes_equal=data==expected,passed=row['http']==200 and data==expected)
 except Exception as e:row.update(passed=False,error=repr(e))
 row['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 return row,data
checks=[];bodies={}
with ThreadPoolExecutor(max_workers=4) as pool:
 for future in as_completed([pool.submit(read,p) for p in paths]):
  row,body=future.result();checks.append(row);bodies[row['path']]=body
checks.sort(key=lambda x:x['path'])
assert all(x['passed'] for x in checks),[x for x in checks if not x['passed']]
m=json.loads(bodies[directory+'/MANIFEST.json']);joined=[]
for row in m['parts']:
 body=bodies[directory+'/'+row['path']]
 assert len(body)==row['bytes']<=512*1024 and hashlib.sha256(body).hexdigest()==row['sha256']
 body.decode('utf-8',errors='strict');joined.append(body)
joined=b''.join(joined)
source=subprocess.check_output(['git','show',m['original']['commit']+':'+m['original']['path']],cwd=repo)
assert joined==source and len(joined)==m['original']['bytes'] and hashlib.sha256(joined).hexdigest()==m['original']['sha256']
assert json.loads(joined)==json.loads(source)
refs={line.split()[1]:line.split()[0] for line in subprocess.check_output(['git','ls-remote','origin','refs/heads/dev/m1-v018-chart-annotations','refs/heads/main'],cwd=repo,text=True).splitlines()}
assert refs['refs/heads/dev/m1-v018-chart-annotations']==commit and refs['refs/heads/main']=='9c5b168c09ba80010c74f03b9c537e8b7474256a'
result=dict(scope='LOSSLESS_UTF8_TEXT_PARTS_ONLY_NOT_PRODUCT_ENGINEERING_OR_TESTS',fixed_delivery_commit=commit,parent_commit='bd6ed6a984254295eae4c13c5973ef28a7b7c29b',original_source=m['original'],observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=len(checks),all_pass=True,remote_head=refs['refs/heads/dev/m1-v018-chart-annotations'],main_head=refs['refs/heads/main'],main_unchanged=True,remote_parts_join=dict(parts=len(m['parts']),all_parts_utf8=True,all_parts_under_512_KiB=True,bytes=len(joined),sha256=hashlib.sha256(joined).hexdigest(),full_bytes_equal_original=True,json_parsed=True,full_object_equal_original=True),work_specific_github_connector_available=False,work_tool_full_acquisition_and_review='NOT_OBSERVED_THIS_CODEX',old_32_python_88_chromium_not_rerun=True,numeric_producer_or_indicators_run=False,old_sources_images_zip_fetched=False,new_product_version=False,new_source_011=False,checks=checks)
(scratch/'fixed-readback.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(repo/directory/'GITHUB_READBACK.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False,indent=2))
