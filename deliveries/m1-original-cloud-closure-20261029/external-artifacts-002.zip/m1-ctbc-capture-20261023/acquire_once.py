from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, urllib.request, urllib.error

OUT = Path('/workspace/m1-ctbc-capture-20261023')
URL = 'https://ecorp.ctbcbank.com/cts/static/ag_dividend_printer.jsp'
def now(): return datetime.now(timezone.utc).isoformat()
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args): return None

sentinel = OUT / 'single-get.started'
with sentinel.open('x') as f: f.write(now() + '\n')
m = dict(url=URL, method='GET', requested_at=now(), retries=0, redirects_followed=False,
         authorization='USER_EXPLICIT_NEW_SINGLE_GET_AFTER_PUBLISHED_RUNTIME_CHANGE',
         previous_runtime_spec='4', observed_runtime_spec='6', runtime_policy_mode='unrestricted', runtime_policy_state='enforced')
body = b''
try:
    with urllib.request.build_opener(NoRedirect).open(urllib.request.Request(URL, headers={'User-Agent': 'Twstockai-source-archive/1.0'}), timeout=45) as response:
        body=response.read();m.update(http=response.status, final_url=response.url, headers=dict(response.headers.items()), status='HTTP_RESPONSE_CAPTURED_PENDING_SEMANTIC_VERIFICATION')
except urllib.error.HTTPError as e:
    body=e.read();m.update(http=e.code, final_url=e.url, headers=dict(e.headers.items()), status='HTTP_REFUSED_STOPPED', error=str(e))
except Exception as e:
    m.update(http=None, status='TRANSPORT_FAILED_STOPPED', error=repr(e), headers=None)
m.update(completed_at=now(), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
(OUT/'ctbc-attempt.response').write_bytes(body)
(OUT/'ctbc-attempt.meta.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(m,ensure_ascii=False),flush=True)
