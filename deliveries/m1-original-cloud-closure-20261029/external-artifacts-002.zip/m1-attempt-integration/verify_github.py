from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
from hashlib import sha256
from pathlib import Path
import json,subprocess,urllib.request
repo=Path('/workspace/Twstockai');relative='deliveries/m1-v019-attempt-view-20261017';folder=repo/relative
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
entries=[line.split('  ',1) for line in (folder/'SHA256SUMS.txt').read_text().splitlines()]
def check(entry):
 expected,name=entry
 url='https://github.com/blue1998-glitch/Twstockai/raw/'+commit+'/'+relative+'/'+name
 digest=sha256();size=0
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'M1-artifact-verification'}),timeout=60) as response:
  status=response.status
  while True:
   block=response.read(1024*1024)
   if not block:break
   digest.update(block);size+=len(block)
 assert status==200 and digest.hexdigest()==expected and size==(folder/name).stat().st_size
 print('PASS',name,size,flush=True)
 return dict(file=name,status='PASS',http_status=status,bytes=size,sha256=digest.hexdigest(),url=url)
checks=[]
with ThreadPoolExecutor(max_workers=3) as pool:
 for future in as_completed([pool.submit(check,item) for item in entries]):checks.append(future.result())
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/dev/m1-v018-chart-annotations','refs/heads/main'],cwd=repo,text=True)
refs={ref:sha for sha,ref in (line.split() for line in remote.splitlines())}
assert refs['refs/heads/dev/m1-v018-chart-annotations']==commit
assert refs['refs/heads/main']=='9c5b168c09ba80010c74f03b9c537e8b7474256a'
report=dict(status='PASS',verified_at_utc=datetime.now(timezone.utc).isoformat(),artifact_commit=commit,
 branch='dev/m1-v018-chart-annotations',checks=sorted(checks,key=lambda x:x['file']),
 main_verified_unchanged=True,remote_refs_at_validation=refs,
 interpretation='Actual immutable GitHub HTTP GET bytes match local SHA256SUMS; 978 full-archive members were extracted and byte-checked separately',
 data_kind='SYNTHETIC_ENGINEERING_FIXTURE',physical_android='NOT_TESTED',core_product_acceptance='NOT_ESTABLISHED')
(folder/'GITHUB_DOWNLOAD_VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('ALL_PASS',len(checks),commit,flush=True)
