from pathlib import Path
from hashlib import sha256
import json,shutil,zipfile
repo=Path('/workspace/Twstockai');project=repo/'股票系統M1_v0_18';run=Path('/workspace/m1-attempt-integration/run-2')
out=repo/'deliveries/m1-v019-attempt-view-20261017';out.mkdir(exist_ok=False)
for name in ['M1_v0_19_attempt_candidate.html','attempt-candidate.json','attempt-selection-oracle.json']:shutil.copy2(run/name,out/name)
assert sha256((out/'M1_v0_19_attempt_candidate.html').read_bytes()).hexdigest()=='4f0b561bf5094a7d13c9f90e2c00811e1ca3d0e296ec75008852aac69ab70702'
usage='解壓後開啟 M1_v0_19_attempt_candidate.html。勾選啟用、選來源與觀察時點，再讀取；可前後重播、下載當時原精度JSON。全為假想工程例，不是真實行情或完整交易資格。Android本機開檔尚未實測。完整source及實測請讀同分支CONTINUE_IN_WORK_MODE.md。'
with zipfile.ZipFile(out/'M1_v019_attempt_page.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.write(out/'M1_v0_19_attempt_candidate.html','M1_v0_19_attempt_candidate.html');z.writestr('使用說明.txt',usage)
items={}
for p in project.rglob('*'):
 if not p.is_file() or any(s in p.relative_to(project).parts for s in ['__pycache__','tmp']) or p.suffix=='.pyc':continue
 if p.is_symlink():raise ValueError('Unexpected source symlink: '+str(p))
 items[p.relative_to(repo).as_posix()]=p
roots={repo/'AGENTS.md',repo/'CONTINUE_IN_WORK_MODE.md',repo/'PROJECT_VISION.md',repo/'M1_V018_PRODUCT_GAP_HANDOFF.md'}
roots.update(repo.glob('M1_V019*.md'));roots.update(repo.glob('M1_V019*.json'))
roots.update(p for p in (repo/'docs/visual-discussion').rglob('*') if p.is_file())
for p in roots:items[p.relative_to(repo).as_posix()]=p
for name in ['M1_v0_19_attempt_candidate.html','attempt-candidate.json','attempt-selection-oracle.json']:
 items['股票系統M1_v0_18/product_candidate/generated/'+name]=out/name
old=repo/'deliveries/m1-v019-context-20261017'
for name in ['M1_v0_19_candidate.html','candidate.json']:
 items['股票系統M1_v0_18/product_candidate/generated/'+name]=old/name
manifest={name:dict(bytes=p.stat().st_size,sha256=sha256(p.read_bytes()).hexdigest()) for name,p in sorted(items.items())}
mp=out/'PROJECT_FILE_MANIFEST.json';mp.write_text(json.dumps(dict(version='M1 v0.19 attempt-view-adapter/0.1',base_commit='45aaeecf92fabee80a4f2729328ae161e0d0203b',files=manifest),ensure_ascii=False,indent=2))
items[mp.name]=mp
readme=out/'OFFLINE_PROJECT_README.txt';readme.write_text('三個完整ZIP各含部分檔案，全部解壓至同一資料夾。已包含全部離線資產與最新source，不需舊ZIP或bootstrap覆蓋。先讀 CONTINUE_IN_WORK_MODE.md 最新節。新頁在 股票系統M1_v0_18/product_candidate/generated/M1_v0_19_attempt_candidate.html；勾選啟用，明選來源及時點。舊v0.19頁也保留在generated。全為假想嘗試工程例，真實行情／自動選區／Android實機未完成。只有Git checkout才需從repository root跑 python3 codex/bootstrap_m1.py --hydrate-missing。PROJECT_FILE_MANIFEST.json是本包精確指紋；舊output指紋仍為歷史基準。')
items[readme.name]=readme
whole=Path('/workspace/m1-attempt-integration/package-members.zip')
with zipfile.ZipFile(whole,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(items.items()):z.write(p,name)
with zipfile.ZipFile(whole) as z:
 groups=[[],[],[]];sizes=[0,0,0]
 for info in sorted(z.infolist(),key=lambda i:i.compress_size,reverse=True):
  group=min(range(3),key=lambda i:sizes[i]);groups[group].append(info.filename);sizes[group]+=info.compress_size+2*len(info.filename.encode())+100
for i,group in enumerate(groups,1):
 with zipfile.ZipFile(out/('M1_v019_attempt_full_0%d.zip'%i),'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name in sorted(group):z.write(items[name],name)
extracted=Path('/workspace/m1-attempt-integration/extracted');extracted.mkdir(exist_ok=False)
seen=set();archives=[]
for i in range(1,4):
 p=out/('M1_v019_attempt_full_0%d.zip'%i)
 assert p.stat().st_size<32*1024*1024
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None;assert not seen.intersection(z.namelist());seen.update(z.namelist());z.extractall(extracted)
 archives.append(dict(file=p.name,bytes=p.stat().st_size,mib=round(p.stat().st_size/1024/1024,3)))
assert seen==set(items)
for name,p in items.items():assert sha256((extracted/name).read_bytes()).digest()==sha256(p.read_bytes()).digest()
report=dict(status='PASS',archives=archives,unique_members=len(seen),project_handoff_and_generated_files=len(manifest),duplicates=0,all_extracted_bytes_match=True,original_engine_or_database_recomputed=False)
(out/'PACKAGE_VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False))
