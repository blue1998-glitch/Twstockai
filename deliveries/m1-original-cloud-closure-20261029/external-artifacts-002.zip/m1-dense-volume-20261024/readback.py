from pathlib import Path
import concurrent.futures,datetime,hashlib,json,subprocess,urllib.request,urllib.parse
ROOT=Path('/workspace/Twstockai');SCRATCH=Path('/workspace/m1-dense-volume-20261024');FIXED='1085b17ccbbc09269908bb95442ec309910d1399'
BASE=json.loads((SCRATCH/'baseline.json').read_text());PATHS=json.loads((SCRATCH/'fixed-paths.json').read_text())
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
def read(path):
 expected=git('show',FIXED+':'+path);url='https://raw.githubusercontent.com/blue1998-glitch/Twstockai/'+FIXED+'/'+urllib.parse.quote(path,safe='/');started=now()
 try:
  with urllib.request.build_opener(NoRedirect()).open(urllib.request.Request(url,headers={'User-Agent':'Twstockai-volume-peak-research-readback','Cache-Control':'no-cache'}),timeout=45) as response:
   actual=response.read();status=response.status;headers={key:response.headers.get(key) for key in ['Content-Type','Content-Length','Date','ETag','Last-Modified'] if response.headers.get(key) is not None};assert response.url==url
  assert status==200 and actual==expected,path
  return dict(path=path,url=url,requested_at=started,completed_at=now(),http_status=status,safe_headers=headers,bytes=len(actual),sha256=hashlib.sha256(actual).hexdigest(),git_blob_sha1=hashlib.sha1(b'blob '+str(len(actual)).encode()+b'\0'+actual).hexdigest(),exact_fixed_bytes=True)
 except Exception as e:
  return dict(path=path,url=url,requested_at=started,completed_at=now(),error=type(e).__name__+':'+str(e),exact_fixed_bytes=False)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:files=list(pool.map(read,PATHS))
errors=[r for r in files if not r['exact_fixed_bytes']]
(SCRATCH/'raw-readback-attempts.json').write_text(json.dumps(files,ensure_ascii=False,indent=2)+'\n')
assert not errors,errors
refs=dict(line.split('\t')[::-1] for line in git('ls-remote','origin','refs/heads/dev/m1-v018-chart-annotations','refs/heads/main').decode().splitlines())
assert refs['refs/heads/dev/m1-v018-chart-annotations']==FIXED and refs['refs/heads/main']==BASE['main']
anchors=[BASE['head'],'0df19d88abb20ae89b9082beb42433de9c394225','ec51f617bf51b1ae77099efc4ecd8099d940996d','f423447c9396bfdd7c524f4c5f63173be1ebb47d']
for sha in anchors:subprocess.run(['git','merge-base','--is-ancestor',sha,FIXED],cwd=ROOT,check=True)
roots=['AGENTS.md','CONTINUE_IN_WORK_MODE.md','PROJECT_VISION.md','M1_V019_GRAPH_CORE_RESUME_HANDOFF.md']
for path in roots:assert git('show',FIXED+':'+path).endswith(git('show',BASE['head']+':'+path))
assert set(git('diff','--name-only','-z',BASE['head'],FIXED).decode().rstrip('\0').split('\0'))==set(PATHS)
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
assert set(git('ls-files','--others','--exclude-standard','-z').decode().split('\0')[:-1])==set(BASE['untracked'])
proof=dict(record_type='fixed-engineering-github-original-byte-readback',repository='blue1998-glitch/Twstockai',branch='dev/m1-v018-chart-annotations',fixed_engineering_commit=FIXED,baseline=BASE['head'],completed_at=now(),files=files,verified_files=len(files),all_verified=True,remote=refs,all_anchors_ancestors=True,existing_root_document_bodies_preserved=True,all_old_product_data_ui_db_and_artifact_paths_unchanged=True,untracked_inventory_preserved=True,tracked_worktree_clean=True,
 new_test_methods=37,old_tests_rerun=0,intermediate_31_or_36_not_added=True,no_browser_or_android_tests=True,no_old_large_json_parts_png_zip_or_market_source_requests=True,new_research_zip_read_back=True,zip=json.loads((ROOT/'deliveries/m1-volume-peak-research-20261024/package-verification.json').read_text()),
 core_qualification='INDEPENDENT_UNVALIDATED_RESEARCH_NOT_FORMAL_REPRESENTATIVE_LINE_OR_STRATEGY',
 self_reference_policy='Receipt saved in a later commit; its own fixed-byte readback is recorded separately after that commit.')
(SCRATCH/'fixed-readback.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
D=ROOT/'deliveries/m1-volume-peak-research-20261024'
(D/'GITHUB_READBACK.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
rows='\n'.join('|'+r['path']+'|'+str(r['bytes'])+'|`'+r['sha256']+'`|200／原bytes一致|' for r in files)
(D/'GITHUB_READBACK.md').write_text('''# 固定密集量峰候選研究工程：GitHub原bytes讀回

固定工程：`'''+FIXED+'''`。開始3b6fe93及固定結清0df19d8、原band-volume ec51f617與來源0.10 f423447均為祖先；main保持原9c5b168。正常push原分支，沒有回退、強推或平行工作／子代理。

本Codex實際取得固定提交40份新增／修改文件及新研究ZIP，各HTTP200，逐檔長度、SHA與Git blob原bytes完全一致。完整URL、起訖時點、安全headers及指紋見[GITHUB_READBACK.json](GITHUB_READBACK.json)。這不是Work已核讀新研究或Android通過；Work未執行本輪產品測試。

|固定路徑|bytes|SHA256|結果|
|---|---:|---|---|
'''+rows+'''

本輪37項新測試PASS；31／36中間批及新解壓重現不累加，不冒舊32／88重跑。新包254076bytes／67成員（66manifest），完整CRC／成員長度SHA核對；新解壓12數值檔逐byte重現，來源鏈只更新local reuse observed_at。包SHA256：`0f8309e4857fa160a1eeabb91d5adc7b966bef6e1d980579065a38cc18666da2`。

原graph_core、P0-3、band_volume.py、UI、指標、策略／庫／行情及舊產物保持；只有四根入口前置段落，原文保留。完整band-volume讀取已結清，不重抓分片／大檔／原blob／圖／舊ZIP或來源。本次僅讀回本輪新包，不是重取任何舊ZIP。來源0.10與全部parent及缺口、Raw null／UNKNOWN、歷史與警告不變；正式代表線NOT_IMPLEMENTED/null，各項false/null資格保持。

無瀏覽器／Android實測、file://未重試；不跑每日淨帳／六方案，不宣稱辨識品質或獲利。未取得Work研究檔，已用庫內小原料重現；未定平台及正式單線不強補。Git路徑轉義的提交前阻擋及修正見[publication diagnostic](git-publication-diagnostic.json)，不是數值測試失敗。

本收據另行提交避免自指，提交後再逐檔核其原bytes，最終回覆另列最新已核SHA。下一個對象僅Work；完整可貼指令在root [M1_VOLUME_PEAK_RESEARCH_HANDOFF](../../M1_VOLUME_PEAK_RESEARCH_HANDOFF.md)。只看新有限研究輸出，不再重開已結清大檔／原10圖或舊驗證，不強迫唯一贏家或新增正式策略。
''')
print(json.dumps(dict(fixed_engineering=FIXED,verified_files=len(files),all_exact=True,main_unchanged=True),indent=2))
