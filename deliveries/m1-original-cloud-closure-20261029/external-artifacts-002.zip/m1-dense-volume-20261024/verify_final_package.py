from pathlib import Path,PurePosixPath
import hashlib,json,zipfile,tempfile,subprocess,os,datetime
repo=Path('/workspace/Twstockai');delivery=repo/'deliveries/m1-volume-peak-research-20261024';scratch=Path('/workspace/m1-dense-volume-20261024')
report=json.loads((scratch/'package-final.json').read_text());archive_path=delivery/'M1_volume_peak_research_20261024.zip'
with zipfile.ZipFile(archive_path) as archive:
 names=archive.namelist();assert len(names)==len(set(names)) and archive.testzip() is None
 manifest=json.loads(archive.read('MANIFEST.json'))['files'];assert set(names)==set(manifest)|{'MANIFEST.json'}
 for name,spec in manifest.items():
  assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
  body=archive.read(name);assert len(body)==spec['bytes'] and hashlib.sha256(body).hexdigest()==spec['sha256']
 with tempfile.TemporaryDirectory(prefix='m1-final-volume-repro-') as folder:
  archive.extractall(folder);app=Path(folder)/'股票系統M1_v0_18';out=Path(folder)/'reproduced'
  env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONPATH']=str(app)
  cmd=['python3','-m','volume_peak_research.build','--raw-dir','pressure_chart/data/history-20261018/raw','--selection','structure_state_chart/examples/band-volume-selection.json','--request','volume_peak_research/examples/request.json','--out',str(out)]
  run=subprocess.run(cmd,cwd=app,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (scratch/'fresh-final-package.stdout').write_bytes(run.stdout);(scratch/'fresh-final-package.stderr').write_bytes(run.stderr)
  assert run.returncode==0,run.stderr.decode()
  expected=delivery/'artifacts';checked=[]
  for name in ['research-input.json','research-request.json','summary.json']+[f'probe-{i:02}.json' for i in range(1,10)]:
   a=(out/name).read_bytes();b=(expected/name).read_bytes();assert a==b,name
   checked.append(dict(path=name,bytes=len(a),sha256=hashlib.sha256(a).hexdigest()))
  new_lineage=json.loads((out/'source-lineage.json').read_bytes());old_lineage=json.loads((expected/'source-lineage.json').read_bytes())
  for data in [new_lineage,old_lineage]:
   for item in data['sources']:item.pop('local_reuse_observed_at')
  assert new_lineage==old_lineage
report.update(verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 all_manifest_member_lengths_and_sha256_verified=True,unique_safe_paths=True,
 fresh_extraction_build_exit=run.returncode,fresh_extraction_numeric_files_exact=checked,
 fresh_extraction_source_lineage_equal_except_new_local_reuse_timestamps=True,
 fresh_extraction_tests_rerun=False,unique_final_test_count=37,
 no_old_large_product_json_parts_png_or_zip_reads=True,
 small_existing_raw_meta_selection_and_source_helpers_reused=True,no_network_market_requests=True,
 earlier_bundle_note='Pre-preservation bundle retained in scratch; final archive additionally contains preservation.json. Both fresh numeric replays are the same 9 probe scope, not additional tests.')
(delivery/'package-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(delivery/'M1_volume_peak_research_20261024.zip.sha256').write_text(report['sha256']+'  '+archive_path.name+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='fresh_extraction_numeric_files_exact'},indent=2))
