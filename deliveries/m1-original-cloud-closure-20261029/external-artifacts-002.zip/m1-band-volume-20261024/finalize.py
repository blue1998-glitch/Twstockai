from pathlib import Path
import json,hashlib,base64,gzip,re,shutil,subprocess
r=Path('/workspace/Twstockai');a=r/'股票系統M1_v0_18';s=Path('/workspace/m1-band-volume-20261024');v=a/'structure_state_chart/validation_band_volume_20261024';d=r/'deliveries/m1-explicit-band-volume-20261024';d.mkdir(exist_ok=True)
report=json.loads((v/'browser-final/browser-report.json').read_text());assert report['status']=='PASS' and report['checks']==88
def put(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
for f in ['bootstrap.log','python-initial.log','python.log','regression.log','browser-initial.log','browser-final.log','build.log']:shutil.copy2(s/f,v/f)
shutil.copy2(v/'browser-initial/browser-report.json',v/'intermediate-browser-report.json');shutil.move(str(v/'browser-initial'),str(s/'retained-browser-initial'))
put(v/'execution-diagnostic.json',dict(initial_python=dict(tests=26,status='FAILED_ONE_HARNESS_ERROR',error='Test mocked nonexistent graph_core.core.evaluate; actual function is analyze',fix='Mock actual graph_core.core.analyze without changing product or assertions'),final_new_python=26,selected_related_regression=6,unique_python_scope=32,initial_browser=88,final_browser=88,counts_not_added=True,intermediate_capture='Pre-confirmation screenshot used existing case local start beyond cutoff and became one bar; final screenshot uses wide context without changing original viewer',source_or_strategy_tuned=False,graph_p03_indicators_recomputed=False,physical_android='NOT_TESTED_NEW_BUILD'))
parent=r/'deliveries/m1-p03-readability-20261024/artifacts';out=a/'structure_state_chart/output/band-volume-delivery'
lineage={}
for name in ['structure-state.json','chart-layer.json','facts-input.json','scenario.json','role-selection.json']:
 old=(parent/name).read_bytes();new=(out/name).read_bytes();assert old==new;lineage[name]=dict(bytes=len(old),sha256=hashlib.sha256(old).hexdigest(),identical=True)
old=(parent/'M1_P03_structure_state_readable_v02.html').read_text();new=(out/'M1_P03_explicit_band_volume_v03.html').read_text()
for name,pattern in [('original_numeric_tree',r'<script type="application/json" id="payload">(.*?)</script>'),('original_p03_layer',r"const p03Compressed=Uint8Array.from\(atob\('([^']+)'\)")]:
 x=re.search(pattern,old,re.S).group(1);y=re.search(pattern,new,re.S).group(1);assert x==y;lineage[name]=dict(compressed_identical=True,decoded_sha256=hashlib.sha256(gzip.decompress(base64.b64decode(x))).hexdigest())
latest=json.loads((out/'band-volume.json').read_bytes())['snapshots']['2026-10-16'];assert latest['comparison']==dict(relation='BELOW',delta='-40779250',reason='AVAILABLE')
put(v/'source-lineage.json',dict(status='PASS',parent_engineering='ebe27cb32d2e9db12993f7b91e8992ae2f48f4b8',parent_verified='f9f71f5db6ad2200a27e947c926814a819485ac1',files=lineage,maximum_original_bars=latest['reference']['maximum_original_bars'],source_member_count=155,reference_source_start=latest['reference']['source_start'],reference_source_end=latest['reference']['source_end'],candidate_id=latest['reference']['candidate_id'],candidate_confirmed_on=latest['reference']['candidate_confirmed_on'],reference_known_on=latest['reference']['reference_known_on'],actual_later_selected_at=latest['selected_at'],historical_selection_time=None,graph_core_analyze_or_indicators_or_p03_run=False))
put(v/'source-reuse-assessment.json',dict(equivalent_maximum_statistics_already_present=True,equivalent_complete_causal_wiring_present=False,actual_gap='Explicit candidate and full-source membership / knowledge / current exact comparison / viewer and downloads',reused=['graph_core saved candidate.volume (no analyze/_volume rerun)','pressure_chart.facts.volume_facts','candle_region_chart.extents.envelope','reaction_facts.core.compare','reaction_facts.source.make_input'],parallel_maximum_algorithm=False,representative_volume_estimator='NOT_IMPLEMENTED_NO_APPROVED_GROUPING_OR_ESTIMATOR',new_corporate_source_version=False))
# Mark engineering counterexamples explicitly, never as extra market cases.
import sys
sys.path[:0]=[str(a),str(a/'tests')]
from test_explicit_band_volume import fixture
put(v/'engineering-fixture.json',dict(qualification='ENGINEERING_NOT_MARKET',input=fixture(),purpose='Tied maximum, exact equality, missing-source and future-isolation tests; not real OHLCV or a market sample'))
put(v/'visual-review.json',dict(actually_viewed=['browser-final/local-1280.png','browser-final/wide-390.png','browser-final/not-yet-known-390.png'],observations=['Current smaller than full-band maximum leaves P03 strengthening unchanged','Volume maximum is marked on volume pane only, separate from price references and MACD','Wide and local use same 155 original members','Before confirmation complete reference is hidden and wide real context remains'],other_viewports_captured_and_tested=True,android='NOT_TESTED_NEW_BUILD'))
(v/'驗收報告.md').write_text('''# 明示研究段最大量：本輪實際驗收

原唯一Codex接續f9f71f5，唯讀遠端含固定顯示ebe27cb3、核心702e9144及全部後續，main仍9c5b168c09ba80010c74f03b9c537e8b7474256a。依根及子AGENTS重新bootstrap成功0補缺／7既有差異保留；runtime connected/running spec8/current，unrestricted政策state仍unknown，不冒enforced。指定交接、裁決、原碼／依賴已讀，沒有新市場來源GET或重抓舊來源。

## 實作與既有功能對照

graph_core保存candidate.volume已有段最大量／同量日；pressure_chart.volume_facts及candle_region_chart.envelope也有等價統計。本輪未重寫最大量算法，未重跑graph_core.analyze或_volume；只讀其保存結果，再直接重用兩個helper核對，並沿reaction_facts的make_input／compare補明示來源／成員／可知資格及當日精確比較。純接線在reaction_facts/band_volume.py，無UI／IO／時計；外部build_volume才讀寫，band_volume.js只渲染保存結果和像素換算。

來源候選B88保持RESEARCH_CANDIDATE，formal_price_bounds及formal_region_membership=null。不是完整帶切段、正式原箱、自動選參照／主要壓力或密集量峰算法；既有Raw／Adjusted路由不改。來源0.10及全部parent不變，不建來源0.11或catalog，不回寫null。

## 真實保存核對

1101 Raw的B88候選sha256:9fbf971f46c19caa9b00657d0b805bc2bd4d782ab617b3818b50ddfe211b7d39，完整明示保存來源2025-11-19～2026-07-14／155根。最大量2026-01-12／98,217,134股，原K開23.85高25.10低23.80收24.95；不是原研究高26.95的1/27。10/16原量57,437,884，BELOW、精確差額-40,779,250股。原候選保存統計與兩helper相同，全同量來源逐筆保留；原155列可在JSON／抽屜核對。

量發生日1/12、候選確認9/1、量參照可知9/1、本輪實際後來選取時間分存；舊價格角色選取時間及五JSON未改。7/14或8/31等尚未確認截止reference=null，不提前露完整段量參照。只認證明示保存成員，不認證完整市場日曆／公司行動或歷史公開可得；historical_signal_eligible=false。

前筆量觀察與完整段最大量分開。10/16未越最大量不判壞、不取消轉強；10/12量大於段最大量也不把尚缺返回角色的P0-3變成可判定。10/13整理→14轉強→15整理→16轉強、10/12原突破及1213records／14events／所有ID完全不變。原突破26.95、返回高26.85、研究下緣20.25仍不同來源。

## 本輪實跑

- 新26項Python PASS：真實155根及最大量／非最高價K、同量全來源、相等／嚴格大於／真零、缺量／全缺／缺成員／已知缺日／基底及版本衝突、不可知前綴／延遲可知、追加與修改未來、來源指紋與既有統計衝突、當日缺量、跨缺日不可比、長小數不受全域精度影響、來源／時間／研究資格拒用、純核心不改輸入／無IO及禁止graph_core／P0-3呼叫。
- 6項實跑相關回歸PASS，精確測項見regression.log：reaction_facts的長小數／來源adapter拒用；pressure_facts的總量與峰日分開／缺量不冒完整最大；candle_extents的來源最高量非總量／缺量不補零。不是重跑整套歷史。
- 最後真實Chromium154.0.8037.57／HTTP，1280×1000、390×844、844×390共88檢查PASS。含五JSON完整bytes、UI／snapshot／下載一致、四日原P0-3不變、廣角486／局部31都保155完整來源、峰量日在畫內／外標記、只量圖畫線不穿MACD／不伸價軸、同窗游標、155原K／來源日期、定位／實際拖曳／觸控放大不改分析、8個截止前綴、其他股／缺Adjusted不套層／不fallback、4份真實下載、無橫溢／JS錯誤／外部網路。
- 6張桌面／手機直橫廣角局部PNG，另有未確認前廣角及3張量來源抽屜。只有雲端手機模擬，Android NOT_TESTED_NEW_BUILD、file://未重試。

唯一Python範圍26新＋6相關＝32；新解壓同26不相加，中間88與最後88不相加。歷史65／94、上一輪6／94及財務53或70／2／8／合格0未冒重跑。首次26測試其中一個mock誤指graph_core.evaluate（實際為analyze），屬測試架設錯誤；原log保留，改mock真函式後26全過，未改核心或刪斷言。初版尚未確認PNG以舊案例局部起日套早期截止變一根，最後改用廣角擷取，沒有修改原viewer或補K。

## 保持及未完成

source-lineage核五份原JSON完整bytes、原內嵌K／MA／MACD數值樹及P0-3層相同；preservation核原檔、策略、引擎、庫、Raw null／UNKNOWN、版本、歷史、舊頁圖／ZIP與main保持。密集量峰代表線仍未實作及明示原因，不以平均／中位數／比例替代；未作自動選箱／完整帶／主壓力、全市場或換股／飛輪。沒有每日淨帳／六方案／獲利驗證。

完整行動／權息、個人實配畸零／換股影響／台泥細稅源／個人淨分配／九期初權利等缺口，Raw／五年Adjusted／歷史公布／主檔／SQLite未知及所有舊警告仍在。全部受拒入口、library、嘉新逾時路徑未重試或繞過；私人原件未公開，不補零／行情／前價／估值。execution_qualified=false；imputed_close／valuation=null；historical_signal_eligible=false；primary_pressure_id=null；policy_authorized=false。不部署付費交易訊息或子代理。只交回Work看新圖用途差異。
''')
handoff='''# 明示研究帶最大量已接線：交回Work看用途差異

固定工程及最新已核SHA見deliveries/m1-explicit-band-volume-20261024/GITHUB_READBACK MD／JSON及最終回覆，收據另存避免自指。開始f9f71f5、原顯示ebe27cb3、原P0-3核心702e9144保持。

真正新增的是既有段量統計的因果／來源資格接線及主圖對照，不是另一個最大量算法：沿graph_core保存candidate.volume、pressure_chart.volume_facts、candle_region_chart.envelope與reaction_facts.compare／make_input；未重算graph_core、P0-3或指標，未改五JSON、角色／狀態／事件／ID及人工Raw／Adjusted路由。

真實B88來源2025-11-19～2026-07-14／155根；最大量1/12的98,217,134股，10/16量57,437,884、BELOW、差額-40,779,250。只是一個後來明示研究候選，正式price_bounds=null。原量日、候選確認／量參照可知9/1、本輪後來選取分存；確認前reference=null，不提前露完整段量參照。未越最大量不判壞，不否定原10/13整理→14轉強→15整理→16轉強及10/12原突破。來源缺日／缺量／基底中斷或衝突不拿已知部分最大冒完整段；同量原K與完整來源成員可追溯。

本輪實跑26新Python＋6必要回歸＝32；最後88個新Chromium檢查、三視窗與4份下載通過。中間88、新解壓同26及歷史測試不累加。mock函式名稱錯誤的初次失敗／修正及早期截止截圖廣角調整留史。Android NOT_TESTED_NEW_BUILD，file://未重試。成品PNG可GitHub直接看，不要求手機搬檔、終端或架伺服器。

未取得／未讀：舊Work未交付封包及既有來源／個人權利原件等缺口未解除，原101舊圖未重讀；未實作：密集量峰代表線（群組／估計未定，不用均值替代）、全自動完整帶／主壓力、全市場／換股／飛輪；未執行：新市場來源GET、graph_core／P0-3／指標重算、每日淨帳／六方案／獲利及無關舊全套；未測：Android／file://、參照選取品質與核心用途認可；未讀回：舊Work未取得封包，本輪新工程另記固定逐檔原bytes收據。

## 完整可貼Work指令

```text
接續blue1998-glitch/Twstockai，分支dev/m1-v018-chart-annotations。
使用Codex本次回覆的固定工程與最新已核SHA，先唯讀核包含兩者、f9f71f5db6ad2200a27e947c926814a819485ac1、ebe27cb32d2e9db12993f7b91e8992ae2f48f4b8及702e91447ff8c02950efe8edf508658e68aba45d，保留全部後續，不回退、強推或用main／舊ZIP覆蓋。

只由Work做新圖用途檢視與GitHub唯讀，不bootstrap、工程、產品測試或commit／push。不另開Codex、平行工作或子代理，工程仍交此原既有唯一Codex。

讀根AGENTS、CONTINUE_IN_WORK_MODE、PROJECT_VISION、M1_V019_GRAPH_CORE_RESUME_HANDOFF最新節，全文讀M1_EXPLICIT_BAND_VOLUME_HANDOFF.md、structure_state_chart/BAND_VOLUME.md；讀reaction_facts/band_volume.py、build_volume.py、band_volume.js、examples/band-volume-selection.json，validation_band_volume_20261024的驗收報告、source-reuse-assessment、source-lineage、preservation、execution-diagnostic及browser-final報告，delivery README／package-verification／GITHUB_READBACK MD與JSON。原P0-3、顯示0.2及所有來源parent契約繼續有效。

實際看delivery桌面／手機直橫廣角與局部六PNG、尚未確認廣角及量來源證據圖，取得解析band-volume.json、band-volume-selection與原五JSON。未取得／未讀就明列，不能用報告冒實看。不要求手機搬檔、開終端、架伺服器或部署。

只檢視新對照用途：前筆量與完整明示研究段最大量是否分清；來源段不受縮放裁切；最大量日與最高價K不混；全部同量原K及日期資格可追溯；未越最大量是否被誤解為壞／取消價格過線；密集量峰線是否清楚保持未實作。不要重問已答P0-3／P0-4，不自造群組、箱界、比例、天數、量倍數或主壓力規則。

真實1101 Raw的B88研究候選來源2025-11-19～2026-07-14／155根，最大量2026-01-12的98,217,134股；10/16量57,437,884，BELOW差額-40,779,250。最大價26.95的1/27不是最大量K。候選／量參照9/1才可知，本輪後來選取不冒歷史當時已選；確認前完整reference=null。B88 formal_price_bounds=null，非正式原箱／全自動完整帶核定。

新模組只重用原量helper、精確compare及來源綁定；未重跑graph_core／P0-3／MA／MACD。原五JSON完整bytes、原角色／狀態／事件／ID保持，10/13整理→14轉強→15整理→16轉強及10/12原突破不變。原突破26.95、返回高26.85、研究下緣20.25來源分離。密集量峰代表線status=NOT_IMPLEMENTED，未拿平均／中位數或固定比例代替。

本Codex實跑26新Python＋6相關回歸＝32及最後88個新Chromium檢查，三視窗、4下載／歷史可知前綴／同軸定位觸控／無橫溢通過；中間88、新解壓同26、歷史65／94與上一輪6／94不相加，Work沒有替跑。雲端手機模擬不是Android，NOT_TESTED_NEW_BUILD保持；file://不重試。

來源0.10及全部parent、策略、引擎、庫、Raw null／UNKNOWN、舊版本／歷史／成品／main及所有舊警告保持，不建來源0.11或catalog、不回寫parent null。不重抓年報、CTBC、公開說明書、舊ZIP或圖；全部受拒入口、library及嘉新逾時路徑不重試／換主機路徑繞過。私人原件不公開，不補零、行情、前價或估值。完整公司行動／權息、個人實配畸零／換股影響／台泥細稅源／個人淨額及九期初權利等缺口保留，不作無限來源工程前置。

execution_qualified=false；imputed_close／valuation=null；historical_signal_eligible=false；primary_pressure_id=null；policy_authorized=false。Raw／五年Adjusted／歷史公布／主檔／SQLite未知；全換／分批仍研究變數，不跑每日淨帳／六方案，不稱已驗獲利。最大量對照不等密集量峰、自動完整帶、全市場、換股或飛輪完成。

交實際看過的新圖／JSON及用途差異，分列已完成及未取得／未讀／未實作／未執行／未測／未讀回。明確可復現缺陷交回原唯一Codex；真正影響核心行為的新歧義才附足夠真實廣角／局部圖詢問，不重問既答案例。只選一個下一步對象並附完整指令。不部署、付費、交易、發訊息或啟動子代理。
```
'''
(r/'M1_EXPLICIT_BAND_VOLUME_HANDOFF.md').write_text(handoff);(d/'WORK_HANDOFF.md').write_text(handoff)
prefix='''# 2026-10-24 Codex｜明示研究段最大量已接入：不改P0-3、不估密集量峰

最新接續M1_EXPLICIT_BAND_VOLUME_HANDOFF.md，成品及固定原bytes收據入口deliveries/m1-explicit-band-volume-20261024/README.md。原段量helper已存在，本輪只補來源／可知資格及主圖對照：沿graph_core保存candidate.volume（不重跑analyze／_volume）、pressure_chart.volume_facts、candle_region_chart.envelope、reaction_facts.compare／make_input，無平行最大量算法。新reaction_facts/band_volume.py純接線、build_volume外部IO、band_volume.js只呈現；原P0-3／指標／模式路由及五JSON、角色／狀態／事件／ID保持。

1101 Raw／B88完整明示保存來源155根，2025-11-19～2026-07-14；最大量1/12的98,217,134股，10/16為57,437,884、BELOW差額-40,779,250。來源原K與最高價K不同；量日／候選確認及參照可知9/1／實際後來選取分存，確認前不露完整reference。同量全來源、缺日／缺量／基底或指紋衝突拒比，完整指保存成員不冒完整市場日曆。前筆量與最大量分開，未越不判壞、不取消過線。B88 formal_price_bounds=null仍研究候選；密集量峰代表線NOT_IMPLEMENTED及理由保留，不用平均／中位數／固定比例替代。

本輪26新Python＋6相關回歸＝32，最終88項新Chromium三視窗／4下載檢查通過；初次mock函式名稱錯誤及截圖廣角調整留史，不累加中間88／新解壓同26或歷史65／94、上一輪6／94。桌面／手機直橫廣角局部與來源PNG、原精度JSON及可重現ZIP已交付；Android NOT_TESTED_NEW_BUILD、file://未重試。只交Work看新圖用途差異，完整指令見新handoff，不重問已答P0-3／P0-4。

來源0.10及全部parent／庫／Raw null／UNKNOWN／策略引擎／歷史／舊成品／main及舊警告不改，不建來源0.11／catalog、不回寫null、不重抓來源或重試受拒入口。完整行動／個人權利／淨分配、Raw／Adjusted／歷史公布／主檔／SQLite等缺口保持，不跑每日淨帳／六方案／績效，全部false/null資格保持。最大量工程不等密集量峰、完整帶自動切段／主壓力、全市場、換股或飛輪完成。不部署付費交易訊息或子代理。以下原文留史。

---

'''
for rel in ['AGENTS.md','CONTINUE_IN_WORK_MODE.md','PROJECT_VISION.md','M1_V019_GRAPH_CORE_RESUME_HANDOFF.md']:
 p=r/rel;p.write_text(prefix+p.read_text())
p=a/'AGENTS.md';p.write_text('> 最新明示研究段最大量接線讀root M1_EXPLICIT_BAND_VOLUME_HANDOFF.md、structure_state_chart/BAND_VOLUME.md及validation_band_volume_20261024。只重用既有最大量helper，不改原P0-3／五JSON／模式路由或估密集量峰；本輪26新＋6相關Python／88 Chromium，Android未測，不累加歷史。下一步只Work新圖用途檢視。下方原文留史。\n\n'+p.read_text())
p=a/'structure_state_chart/README.md';p.write_text('> 最新明示研究段最大量對照：[BAND_VOLUME.md](BAND_VOLUME.md)、[本輪驗收](validation_band_volume_20261024/驗收報告.md)、[新PNG／JSON／HTML／ZIP](../../deliveries/m1-explicit-band-volume-20261024/README.md)。沿用0.2主圖與原五JSON，P0-3及來源0.10不改，密集量峰代表線未實作。本輪32 Python／88 Chromium，不累加下方歷史。\n\n'+p.read_text())
base=json.loads((s/'baseline.json').read_text());changed=[]
allowed=['AGENTS.md','CONTINUE_IN_WORK_MODE.md','PROJECT_VISION.md','M1_V019_GRAPH_CORE_RESUME_HANDOFF.md','股票系統M1_v0_18/AGENTS.md','股票系統M1_v0_18/structure_state_chart/README.md']
for p,h in base['files'].items():
 body=(r/p).read_bytes()
 if hashlib.sha256(body).hexdigest()!=h:
  changed.append(p);assert p in allowed,p;assert body.endswith(subprocess.check_output(['git','show',base['head']+':'+p],cwd=r)),p
assert sorted(changed)==sorted(allowed)
put(v/'preservation.json',dict(status='PASS',baseline_commit=base['head'],tracked_files=len(base['files']),unchanged_existing_files=len(base['files'])-len(changed),changed_existing_files=changed,all_changes_prepend_only=True,all_original_engines_parameters_data_cases_catalogs_databases_raw_unknown_history_pages_png_zip_unchanged=True,old_untracked_status_inventory=base['status'],untracked_full_bytes_claimed=False))
print('Docs, exact lineage and preservation PASS',len(base['files']),len(changed))
