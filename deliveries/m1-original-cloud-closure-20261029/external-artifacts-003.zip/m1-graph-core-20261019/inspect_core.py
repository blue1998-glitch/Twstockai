import sys,json,time
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'src')]
from graph_core.core import analyze
from candle_region_chart.build import load_parent
p=load_parent();s=next(s for s in p['history_series'] if s['code']=='1101');f=s['frames'][-1];bars=s['bases'][f['chart_base']]['bars']
payload=dict(schema_version='graph-recognition-input/0.1',context=dict(code=s['code'],source_id=s['source']['id'],price_basis_id=f['chart_base'],price_mode=s['price_mode'],volume_unit='SHARES_REPORTED'),bars=bars)
t=time.time();r=analyze(payload,as_of=bars[-1]['date']);print('seconds',time.time()-t,'pivots',len(r['pivots']),'boxes',len(r['boxes']),'frontier',len(r['comparison']['pareto_frontier_ids']),'bytes',len(json.dumps(r)))
Path('/workspace/m1-graph-core-20261019/real-first.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));Path('/workspace/m1-graph-core-20261019/input1101.json').write_text(json.dumps(payload,ensure_ascii=False))
for sc in r['parameters']['reversals']:
 b=[b for b in r['boxes'] if b['scale']==sc];print(sc,len(b));print([(x['start'],x['source_end'],x['turns'],x['research_bounds']['low'],x['research_bounds']['high']) for x in sorted(b,key=lambda x:-x['duration_records'])[:5]])
