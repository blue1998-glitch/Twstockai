from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import subprocess,json,hashlib,urllib.request,urllib.parse,datetime
r=Path('/workspace/Twstockai');s=Path('/workspace/m1-p03-readability-20261024');d=r/'deliveries/m1-p03-readability-20261024'
commit='ebe27cb32d2e9db12993f7b91e8992ae2f48f4b8'
paths=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','-z',commit],cwd=r).decode().split('\0')[:-1]
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):return None
def read(path):
 expected=subprocess.check_output(['git','show',commit+':'+path],cwd=r)
 url='https://raw.githubusercontent.com/blue1998-glitch/Twstockai/'+commit+'/'+urllib.parse.quote(path,safe='/')
 row=dict(path=path,url=url,requested_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),expected_bytes=len(expected),expected_sha256=hashlib.sha256(expected).hexdigest(),redirects_followed=False,retries=0)
 try:
  with urllib.request.build_opener(NoRedirect()).open(url,timeout=60) as response:row['http']=response.status;data=response.read()
  row.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),full_bytes_equal=data==expected,passed=row['http']==200 and data==expected)
 except Exception as e:row.update(passed=False,error=repr(e))
 row['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();return row
checks=[]
with ThreadPoolExecutor(max_workers=4) as pool:
 for f in as_completed([pool.submit(read,p) for p in paths]):
  checks.append(f.result())
  if len(checks)%20==0:print('Fixed bytes read',len(checks),'/',len(paths),flush=True)
checks.sort(key=lambda x:x['path'])
refs={line.split()[1]:line.split()[0] for line in subprocess.check_output(['git','ls-remote','origin','refs/heads/dev/m1-v018-chart-annotations','refs/heads/main'],cwd=r,text=True).splitlines()}
pkg=json.loads((d/'package-verification.json').read_text())
result=dict(scope='DISPLAY_READABILITY_02_ONLY_CORE_AND_JSON_01_IMMUTABLE',fixed_engineering_commit=commit,parent_commit='34d6f7823ddaac92b526491764e1e6eb33ebc003',parent_numeric_engine_commit='702e91447ff8c02950efe8edf508658e68aba45d',observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=len(checks),all_pass=all(x['passed'] for x in checks),remote_head=refs['refs/heads/dev/m1-v018-chart-annotations'],main_head=refs['refs/heads/main'],main_unchanged=refs['refs/heads/main']=='9c5b168c09ba80010c74f03b9c537e8b7474256a',current_python_tests=6,current_real_chromium_display_checks=94,previous_65_94_not_rerun=True,intermediates_and_extracted_repeat_not_added=True,package_bytes=pkg['bytes'],package_sha256=pkg['sha256'],physical_android='NOT_TESTED_NEW_BUILD',source_011=False,numeric_producer_executed=False,execution_qualified=False,imputed_close=None,valuation=None,historical_signal_eligible=False,primary_pressure_id=None,policy_authorized=False,checks=checks)
(s/'fixed-readback.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
assert result['all_pass'],[x for x in checks if not x['passed']]
assert result['remote_head']==commit and result['main_unchanged'],refs
(d/'GITHUB_READBACK.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False,indent=2))
