from pathlib import Path
import hashlib,json,subprocess,shutil,base64,gzip,re
r=Path('/workspace/Twstockai');a=r/'股票系統M1_v0_18';s=Path('/workspace/m1-p03-readability-20261024');v=a/'structure_state_chart/validation_readability_20261024';d=r/'deliveries/m1-p03-readability-20261024';d.mkdir(exist_ok=True)
report=json.loads((v/'browser-release/browser-report.json').read_text());assert report['status']=='PASS' and report['checks']==94
def put(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
for src,dest in [('browser-release.log','browser-release.log'),('build-release.log','build.log'),('panels.log','panels.log'),('python.log','python.log')]:shutil.copy2(s/src,v/dest)
# Preserve intermediate reports/logs without publishing repeated large downloads/images.
for directory in ['browser-delivery']:
 if (v/directory).exists():
  shutil.copy2(v/directory/'browser-report.json',v/'intermediate-94-browser-report.json')
  shutil.move(str(v/directory),str(s/('retained-'+directory)))
shutil.copy2(s/'browser-delivery.log',v/'browser-intermediate-94.log')
parent=r/'deliveries/m1-p03-structure-state-20261024/artifacts';out=a/'structure_state_chart/output/readability-release'
lineage=json.loads((v/'source-lineage.json').read_text());lineage['display_html_sha256']=hashlib.sha256((out/'M1_P03_structure_state_readable_v02.html').read_bytes()).hexdigest()
put(v/'source-lineage.json',lineage)
put(v/'execution-diagnostic.json',dict(initial_status='FAIL',initial_failure='New section used existing text helper without required parent; async loader replaced page with load-error message; test timed out looking for case button',initial_evidence='browser-initial-failure.json',fix='Supply parent before moving new sections; wait for final display hook',core_or_data_changed=False,intermediate_chromium_checks=[91,91,94],final_chromium_checks=94,counts_not_added=True,final_python_tests=6,old_65_python_94_chromium_not_rerun=True,visual_followup='Shortened repeated relation names; moved reference evidence targets outside candles; pre-return unavailable title no longer mislabels first-ever insufficient date as today breakout',last_title_original_state_changed_on_unchanged_in_json=True,panel_capture_not_product_tests=True,physical_android='NOT_TESTED_NEW_BUILD'))
put(v/'visual-review.json',dict(scope='NEW_P03_DISPLAY_02_ONLY',observed_new_figures=['browser-release/local-1280.png','browser-release/local-390.png','browser-release/wide-390.png','browser-release/breakout-prefix-390.png','panels/source-dates-1280.png'],remaining_images_checked_by_final_browser_capture=True,observations=['Event rows retain initial breakout alongside return-state insufficiency','Three reference roles separate; exact source K dates distinct from candidate end/confirmation','390 plot width 225 to 309px, same low/high bounds','Zoom shelf separated from price ticks/candles/volume label','Volume labelled descriptive, not good/bad or new qualification'],android='NOT_TESTED_NEW_BUILD'))
(v/'驗收報告.md').write_text('''# P0-3顯示0.2：本輪實測與範圍

只由原唯一Codex接續34d6f782，遠端含固定702e9144及全部祖先，main實核仍9c5b168c09ba80010c74f03b9c537e8b7474256a。runtime connected/running spec8/current=true；unrestricted政策state仍unknown，不冒enforced。根／子AGENTS與指定最新交接、原0.1契約／原碼、驗收／source-lineage／失敗與收據已讀。重新bootstrap成功：0補缺、7既有來源差異保留；沒有新增依賴或網路設定。

## 真正改動

另增build_readable.py／readability.js顯示0.2，不改原build.py／patch.js。直接讀固定0.1 HTML／五份JSON，核SHA後增量接入事件列與分欄來源日期，縮減手機右側留白。縮放控制改到K／量間獨立空間，各44×44；原關卡開啟時恢復舊疊圖保留區。三參照按鈕移至圖外圖例，保持可點證據；三條線仍實價、原K點不移日期、超軸不硬貼。

事件列直接顯示日期／收盤／相對三參照／原突破／狀態變化與原因。10/12同時列「原突破已記錄」及「返回後P0-3證據不足」。原核心state_changed_on仍是其原值；在返回角色未知的畫面改以「返回後角色尚不可知；原突破另列」說明，避免把首次不足的2021日期誤認為今日突破日期，沒有回寫原日期。返回高26.85仍出自10/13，不借舊④。

原價位K日／候選末轉折／候選確認／原值可知／角色可知／後來選取分欄，不改schema或值。量較前一保存筆改為獨立中性量觀察，不是整帶量線／最大量或突破資格；MACD與量不取消過線，原supporting／opposing／missing與原數值仍在抽屜及JSON。

## 本輪實際執行

- 6項Python定向顯示／來源保留測試PASS：五份JSON完整bytes相同；內嵌數值樹／狀態層相同；來源竄改拒用；未知顯示hook拒用；不同現有成品拒覆寫；新目錄重建可重現。沒有執行任何數值核心producer。
- 最終Chromium154.0.8037.57：94項本次呈現檢查PASS（browser-release/browser-report.json）。94是本輪新腳本的結果，與上輪恰同數的94不是同一批，也未相加。實際1280×1000、390×844、844×390；手機isMobile／hasTouch只模擬，不是Android。
- 包含：1213records／14events完整對原JSON；兩種窗／三角色線／資料共軸；新量標示與原evidence相同；來源日期分欄；參照按鈕／原抽屜；定位不跳日、實際拖曳移圖／查詢、觸控放大、歷史10/12／13／15前綴與9份實際下載逐JSON核等、10/12不洩漏26.85或未來事件；其他股票／缺Adjusted不套層／不fallback；全1213根仍可看、無橫溢／JS錯誤／外部網路請求。
- 390寬：原畫布374／plot225，新畫布382／plot309，增加84px（約37.3%）；同窗priceLow=23.276、priceHigh=28.174相同，未改價軸範圍、K或指標。價格／量／MACD共x與游標；縮放位置在price.bottom之後、volume標題之前，未遮K／刻度。
- 新桌面／手機直橫廣角及局部6張，另有10/12前綴、完整來源日期3張與4張獨立事件／日期面板；真實Chromium擷取，不是合成行情。視讀範圍見visual-review.json。獨立面板擷取不是額外產品測試。
- 來源／數值SHA核對見source-lineage.json，原K／MA／MACD interned payload SHA a632ac6200b87f8fdc44d2a80c05056019f89e356e0815ec69ac2ad5287d3d30；structure-state SHA37a75a6979fb5d101323bc1b4498ca63aec437d6c2f118c0589877c22242710d，原角色／事件／ID精度不變。新封裝僅view_version=0.2，snapshot schema仍0.1。

初版載入失敗：既有text helper要求parent，新節點少給參數，載入錯誤頁使case button等待逾時。保留browser-initial-failure.json／log；補parent後成功，未改核心或放寬斷言。中間91／91／94只作中間版本，不加成最終278或更多。後續視讀縮短重複名稱、保留圖外證據入口及修正不足狀態日期語義後，再跑最終94。原65 Python／94 Chromium及財務53／70／2／8／合格0不冒本輪重跑；新解壓重現同6也不加總12。

## 保持與未做

原structure_state／reaction_facts／graph_core／manual_basis、策略、K／MA／MACD、角色、B88正式price_bounds=null、來源0.10及parent、庫、Raw null／UNKNOWN、舊HTML／JSON／PNG／ZIP與main完整保留。未重抓年報／CTBC／公開說明書／舊ZIP／圖或重試受拒入口。無來源0.11、數值producer、每日淨帳／六方案／績效或Android／file://驗收。全市場完整帶／主壓力、自動選參照及核心用途品質仍未核定；Raw／五年Adjusted／歷史公布／主檔／SQLite未知和Fontconfig／xref舊警告不變。

execution_qualified=false；imputed_close／valuation=null；historical_signal_eligible=false；primary_pressure_id=null；policy_authorized=false。沒有部署、付費、交易、訊息或子代理。
''')
handoff='''# P0-3用途檢視後：顯示0.2交回Work

最新已核與固定工程SHA見本輪delivery GITHUB_READBACK MD／JSON及最終回覆；收據另存，避免自指。原0.1固定702e91447ff8c02950efe8edf508658e68aba45d／收據34d6f7823ddaac92b526491764e1e6eb33ebc003保持。

這輪只實作使用者指定三項閱讀缺口：預設日期／收盤／相對參照／狀態事件列，手機有效繪圖區，分欄來源日期及中性量觀察。原事件抽屜已有，沿用並改善，沒有誤報缺失或新做核心。人工Raw／Adjusted既有模式繼續沿用；原0.1核心、所有JSON／事件／角色／ID完整bytes相同，舊成品未覆寫。新view_version=0.2、核心snapshot仍0.1，不是來源0.11。

真正實跑：6項新定向Python、最後94項本次真實Chromium，三視窗及9份下載；原65／94沒有重跑。中間91／91／94及新解壓同6不相加。首次text helper少parent導致載入失敗及後續修正留史。390 plot225→309px，原價格範圍不變；量／MACD／K同軸，觸控控制44px。新圖直接可GitHub看；Android NOT_TESTED_NEW_BUILD、file://未重試，無部署。

真實案例與資格不變：1101 Raw1213日／14事件；條件式10/13整理→14轉強→15整理→16轉強；10/12原突破保留，但返回角色當時未知。原突破參照26.95、返回高26.85、研究下緣20.25分開。B88及返回階段仍後來明示研究假設，正式price_bounds=null；顯示更清楚不是核定正式原箱或完整回檔。真例無轉弱／收盤相等，工程反例沒有改成市場樣本。

未取得：舊Work研究ZIP／未交付原meta、完整公司行動／個人實配畸零／期初權利／淨分配原件等未因本輪取得；未讀：這些未取得資料，原101圖刻意不重讀；未實作：自動完整帶／主壓力、全市場、換股／資金飛輪及未定參照算法；未執行：新來源GET／數值producer／每日淨帳／六方案／獲利／無關全套；未測：Android實機、file://與參照選取品質／核心用途認可；未讀回：舊Work未取得封包。本輪新工程逐檔原bytes回讀另記收據，不混為上述舊缺口。

## 完整可貼Work指令

```text
接續blue1998-glitch/Twstockai，分支dev/m1-v018-chart-annotations。
固定P0-3顯示0.2工程與最新已核SHA，使用本次Codex最終回覆及deliveries/m1-p03-readability-20261024/GITHUB_READBACK.md／JSON。先唯讀核包含該固定提交、最新收據、34d6f7823ddaac92b526491764e1e6eb33ebc003及702e91447ff8c02950efe8edf508658e68aba45d並保留全部後續，不回退、強推或用main／舊ZIP覆蓋。

本輪只由Work做新圖用途差異唯讀檢視，不bootstrap、工程、產品測試、commit／push；仍由原既有唯一Codex處理工程，不另開Codex、平行工作或子代理。

讀根AGENTS、CONTINUE_IN_WORK_MODE、PROJECT_VISION、M1_V019_GRAPH_CORE_RESUME_HANDOFF最新節，M1_P03_READABILITY_HANDOFF.md全文、structure_state_chart/READABILITY.md及validation_readability_20261024/驗收報告、source-lineage、preservation、execution-diagnostic、browser-release報告；讀delivery README／package-verification／讀回收據。原M1_P03_STRUCTURE_STATE_HANDOFF與structure_state/README之數值／來源時間契約保持。

實際開啟新delivery桌面1280、手機390直向／844橫向廣角及局部共六PNG，10/12前綴圖、獨立events與source-dates面板；取得並解析structure-state、chart-layer、facts-input、scenario、role-selection JSON。不能以報告冒實看圖；未取得／未讀須明列。不要求使用者手機搬檔、開終端、架伺服器或部署。

只檢視三項新用途差異：日期／收盤／相對三參照／狀態變化是否在預設圖及靜態圖可理解；手機K線寬度及44px右下控制是否好讀；原價位K日／候選末轉折／確認／角色可知／後來選取是否逐欄清楚，以及量較前保存筆是否仍被誤讀為量多必好或量少必壞。既有事件抽屜保留，非本輪首次新增。原突破參照26.95、返回高26.85、研究下緣20.25來源分開。

10/12必同時理解原突破已記錄與返回後P0-3尚不可判定；不能把不足當突破沒發生。10/13整理→14轉強→15整理→16轉強是同一後來明示研究角色案例，非市場準確率。26.85原K是10/13，不借原④5/13同價。B88正式price_bounds=null，返回階段未核正式完整回檔；用途檢視不默認核定參照品質。量／MACD不取消已發生過線，不重問已答P0-3，不新增箱界／確認天數／量倍數／OSC或主壓力規則。

本Codex本輪實際6 Python與最終94 Chromium（本次新腳本，與上輪恰同數94非同批），9份下載／來源前綴／同軸定位觸控／無橫溢通過；原65／94與中間91／91／94不累加，Work未替跑。Android NOT_TESTED_NEW_BUILD、file://未重試。新舊五份JSON完整bytes相同，原數值樹、核心狀態／事件／ID、角色與日期無改；只新顯示與封裝view_version0.2。

來源0.10及全部parent、Raw／UNKNOWN／庫／歷史／舊成品／main及所有舊警告保持，不建來源0.11、不回寫null、不重抓年報CTBC／公開說明書／舊ZIP／圖；所有受拒入口、library、嘉新逾時路徑不重試／換主機路徑繞過。私人券商／集保原件不公開，不補零、行情、前價、估值。完整公司行動／指定權息期間／個人實配畸零／換股影響／台泥最細稅源／個人淨分配與九期初權利等缺口保持，不把來源研究當任何圖形功能的無限前置。

execution_qualified=false；imputed_close／valuation=null；historical_signal_eligible=false；primary_pressure_id=null；policy_authorized=false。Raw／五年Adjusted／歷史公布／主檔／SQLite未知；全換／分批仍研究變數，沒有每日淨帳／六方案或獲利驗證。呈現改善不等自動完整帶、全市場辨識、換股或資金飛輪完成。

輸出實際看過的新圖／JSON與三項用途差異，分列已完成、未取得／未讀／未實作／未執行／未測／未讀回。例行顯示缺陷直接具體交回原唯一Codex；只有真正影響核心行為的新歧義才附充分真實廣角／局部圖提問，不重問P0-3或既答案例。最後只選一個下一執行對象並附完整指令。不部署、付費、交易、發訊息或啟動子代理。
```
'''
(r/'M1_P03_READABILITY_HANDOFF.md').write_text(handoff);(d/'WORK_HANDOFF.md').write_text(handoff)
prefix='''# 2026-10-24 Codex｜P0-3用途檢視後顯示0.2：事件／手機繪圖區／日期分欄

最新完整接續 `M1_P03_READABILITY_HANDOFF.md`；成品／直接PNG與固定回讀在 `deliveries/m1-p03-readability-20261024/README.md`。只增量呈現，不改structure_state／reaction_facts／graph_core、角色、狀態、事件、ID、K／MA／MACD及五份原JSON；原0.1工程702e9144與收據34d6f782／全部舊成品保留。新view_version0.2不是來源0.11。

預設事件列直接看日期／收盤／相對三參照／狀態變化；10/12原突破與返回後狀態不足同時說明，未來高點及事件不洩漏。原突破26.95／返回高26.85／研究下緣20.25分開，B88正式price_bounds仍null、後來明示研究角色未升人工正式原箱。手機390有效plot225→309px，價格範圍不變；44px縮放移K／量間，三面板與游標同軸。來源日期逐欄分原價位K／末轉折／確認／原值及角色可知／後來選取；量較前筆以中性量觀察顯示，不稱好壞或新量資格，原核心支持／反面完整保留。既有事件抽屜及人工Raw／Adjusted模式已實作，沿用不重做。

本輪只實跑6個新顯示Python及最終94項本次Chromium三視窗／9下載檢查；與歷史65／94不同批，不累加中間91／91／94或新解壓重驗。首次text helper缺parent的載入失敗與修正留史；舊原件／引擎／0.10全部parent／庫／Raw null／UNKNOWN／main及舊警告不改。不重抓來源、不建來源0.11、不跑producer／每日帳／六方案／獲利或Android，file://不重試。Android NOT_TESTED_NEW_BUILD，全部false/null資格及來源缺口保持。

下一步只交Work看新圖用途差異，完整可貼指令見新handoff；不重問P0-3，不以顯示改善冒自動完整帶／全市場／換股／資金飛輪完成。原唯一Codex工程寫入，無平行工作／子代理，不部署付費交易訊息。以下歷史原文完整保留。

---

'''
for rel in ['AGENTS.md','CONTINUE_IN_WORK_MODE.md','PROJECT_VISION.md','M1_V019_GRAPH_CORE_RESUME_HANDOFF.md']:
 p=r/rel;p.write_text(prefix+p.read_text())
p=a/'AGENTS.md';p.write_text('> 最新P0-3顯示0.2接續root M1_P03_READABILITY_HANDOFF.md及structure_state_chart/READABILITY.md、validation_readability_20261024/驗收報告。只事件可讀性／手機有效繪圖／來源日期及中性量觀察，原核心／JSON／0.1成品完整保留；本輪6 Python／94新腳本Chromium，不與歷史65／94相加。Android未測，下一步只Work看新圖用途差異。下方原文留史。\n\n'+p.read_text())
p=a/'structure_state_chart/README.md';p.write_text('> 顯示最新0.2：讀[READABILITY.md](READABILITY.md)、[本輪實測](validation_readability_20261024/驗收報告.md)及[新版PNG／HTML／JSON／ZIP入口](../../deliveries/m1-p03-readability-20261024/README.md)。原0.1核心、五份JSON及下方舊工程／驗收保持；不是來源0.11，不重跑歷史65／94。\n\n'+p.read_text())
base=json.loads((s/'baseline.json').read_text());changed=[]
allowed=['AGENTS.md','CONTINUE_IN_WORK_MODE.md','PROJECT_VISION.md','M1_V019_GRAPH_CORE_RESUME_HANDOFF.md','股票系統M1_v0_18/AGENTS.md','股票系統M1_v0_18/structure_state_chart/README.md']
for rel,h in base['files'].items():
 body=(r/rel).read_bytes()
 if hashlib.sha256(body).hexdigest()!=h:
  changed.append(rel);assert rel in allowed,rel;assert body.endswith(subprocess.check_output(['git','show',base['head']+':'+rel],cwd=r)),rel
assert sorted(changed)==sorted(allowed)
put(v/'preservation.json',dict(status='PASS',baseline_commit=base['head'],tracked_files=len(base['files']),unchanged_existing_files=len(base['files'])-len(changed),changed_existing_files=changed,all_changes_prepend_only=True,original_core_sources_market_data_roles_states_events_ids_archives_pngs_and_all_parents_unchanged=True,old_untracked_status_inventory=base['status'],untracked_full_bytes_claimed=False))
print('docs and preservation done',len(changed),'prefixes')
