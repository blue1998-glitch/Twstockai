# 給既有唯一Codex的完整指令

```text
接續 blue1998-glitch/Twstockai
分支 dev/m1-v018-chart-annotations
Work最新已核SHA：7ae4e80ca0fe7e67bc23ff6caaaa6ec129dd45d0

僅由本既有唯一Codex工作接續工程與GitHub寫入，不啟動第二個寫入工作或子代理。先核分支頭與祖先，保留全部後續；不回退、不強推、不用main／舊ZIP覆蓋。

先讀根AGENTS、CONTINUE_IN_WORK_MODE、PROJECT_VISION、M1_V019_GRAPH_CORE_RESUME_HANDOFF最新節，全文讀股票系統M1_v0_18/rotation_research/source_diagnostics_20261023/WORK_HANDOFF.md、README、REPORT、CONTRACT、catalog-v05、source-manifest、missing-quotes、verification、diagnostics、network-configuration、visual-review及delivery MD／JSON收據。正式action_resolution 0.4及parent0.3契約繼續有效。

本輪Work只有GitHub唯讀、既有ZIP離線來源核對與尋源，沒有bootstrap／工程／產品測試／commit／push。Codex既有61項（30+31）及解壓重驗不是Work本輪重跑。70窗仍拒算、2不足、8窗換股影響未支援、真正總淨報酬合格0，沒有每日淨帳或六方案新績效。

Work已實讀原研究包：16,795,237 bytes，SHA256 667c6fbc458feb086371ea5b54f468249699be8e24f979a12c53089dd244d669；CRC及91項manifest全一致。已將你未取得的兩停牌PDF、財政部真API JSON／官方script／頁面與meta另做小包：
TWstockai_Offline_Source_Bridge_20261023.zip
先讀小包REPORT.md、bridge-facts.json、prior_archive_readback.json、MANIFEST.json，再讀archived_work內原件與meta。這是離線封存來源，沒有重試被拒網域；原捕捉時點與本輪讀回時點分存，不能冒新官方連線或倒填歷史公布可得。github_reference及原facts只作對照，不整包覆蓋專案。

只有實際取得附件原始bytes並核SHA後才能接入；若附件仍不可見，明說未取得並保留該工程未完成。禁止用本摘要、SHA字串、合成回應或另一環境可讀當本環境取得原件。不要重抓已被拒入口。

已離線核實：
A. archived_work/twse-tcc-suspension-20250812.response
386308 bytes；SHA256 de4cd75086aad05089d4c3b9ca2f21218cb7088550359ef77bfd1db93ff83198。
2025/8/12文件明載1101上市普通股自8/13起暫停交易。與既有8/14復牌分存；這次有直接起日證據，不靠復牌日倒推。

B. archived_work/twse-esun-suspension-20251104.response
380108 bytes；SHA256 ce5e00490f5d5dc9fed0873e754348d3cb29b28c7e26014fb6d9293e68c32512。
2025/11/4文件明載2884上市普通股自11/5起暫停交易；直接復牌原件仍缺，不自行推整段終點。

C. archived_work/mof-tax-api-143802.response
12953 bytes；SHA256 0616b330ca5fbd08d692546e5ce0c0f9f4d6bdeeb99ca5b6691d70b4b44b65b3。
真官方公開查詢回應，Code=1、Data.Table一筆、TaxAct所得稅法、TaxVer一一四年版、Title一51公司將資本公積以現金方式發給股東之課稅規定、Terms=1、Subsection=51、Content含101/8/17台財稅字第10100097670號令。對照封存官方頁及script、原query表單meta；不呼叫被拒API。ViewCount可變，保存完整封存回應不改字節；未來新回應另存，不能要求整份SHA永遠固定。

在實際完整checkout依最新AGENTS重新bootstrap --hydrate-missing成功才實作。用獨立新版本來源附層嵌入精確parent0.5，原0.5／正式0.4／0.3、scope、resolution、source producer、action_ledger、core、策略參數、庫、Raw null、舊catalog、歷史與成品不改。

工程範圍：
1. 新來源producer離線驗ZIP成員、原件SHA／長度、meta中的原URL／HTTP200／時點、PDF magic／抽字及對象／日期明文；必要頁有限視讀。不能把有SHA的摘要當原件。
2. 在新診斷版本加入兩個明示停牌起日來源；市場session仍開市、個股停牌來源分開。原UNKNOWN歷史不覆寫，Raw仍null，不補行情、不自訂停牌估值／沿前價規則、不解除缺價拒算；execution_qualified仍false。
3. 真財政部封存回應接既有parse_mof_api或獨立新版本，明示從合成分支到真來源驗收的實際範圍。法律來源不等台泥細項來源、個人稅籍、免稅、零保費／匯費或淨額；announced_at不由HTTP Date／Last-Modified或文件年月推定。
4. 做必要定向測試：原件／meta／日期／issuer／instrument錯配與竄改拒用；停牌起日不推終日或其他股票；真API錯TaxVer／Title／Content拒用、ViewCount變動不改內容語義；缺完整coverage／淨到款／期初權利仍拒算；parent與舊成品完整保留。不把合成反例計為市場樣本。

仍缺完整1101／2884行動減資及2026/7/25～10/16權息、2884直接2025可交易日／未圓整實配／畸零處置及既有股東換股影響、台泥最後調整與稅務細項、個人淨分配及九起日期初權利。媒體8/27上市線索未升直接官方證據。員工增資、原2867換股對價與既有2884權利分開；預計發行不是完成，登記不是上市，公司完成不是個人淨到款；空白不補零。私人券商／集保原件不得公開。若另作情境淨帳，必須獨立明示稅籍、費用、權利來源與假設，不混作實際績效。

所有已記錄拒絕入口、三網域代理403／草稿未套用、MOPS、TWT49U／TWT48U、TWTAUU307、file://、NHI403、公報PDF403、TWSE公文查詢307與重大訊息自動導MOPS空頁入口不重試、不改主機／路徑繞過。本次只讀封存原件，不把它當網域限制已解除。

全換／分批仍研究變數，不重問已答規則／比例；Raw／五年Adjusted／歷史公布／主檔／SQLite未知、historical_signal_eligible=false、primary_pressure_id=null、policy_authorized=false保持。無新UI不重開Android驗收，交易與飛輪NOT_EVALUATED。

寫入前再次核分支頭，若前進先讀並保留新增成果；由此唯一Codex在同分支逐節點保存，固定提交逐檔GitHub回讀，不覆蓋或強推。缺原件／未實測不能標完成，無合格淨帳來源不跑六方案湊績效。不部署、付費、交易、發訊息或子代理。結束附最新已核SHA、實際測試與限制及完整下一輪Work唯讀續接指令。
```
