# Work離線原件補核與Codex接續（2026-10-23）

本輪從已保存的原Work研究ZIP讀回兩份停牌起日PDF與財政部真實API回應，補上source_diagnostics 0.5尚未取得的原件交接。沒有新的官方連線請求到被拒絕的網域，沒有修改GitHub、bootstrap、工程或產品測試。正式0.4、parent0.3及來源診斷0.5均保持。

## GitHub唯讀核對

- 開始核到指定分支頭7ae4e80ca0fe7e67bc23ff6caaaa6ec129dd45d0，與使用者指定相同。
- GitHub compare確認在前節點0d6e86a之後ahead 2、behind 0，包含產品固定提交f1b9468b及其收據；舊成果未回退。
- 已全文讀source_diagnostics_20261023的WORK_HANDOFF、README、REPORT、CONTRACT、source-manifest、missing-quotes、verification、diagnostics、network-configuration、visual-review，另讀catalog-v05及delivery的MD／JSON回讀紀錄；根四入口讀最新節。原契約按既有內容繼續有效。
- 61項＝30新診斷＋31正式回歸，以及解壓重驗、528原成員保留，均為Codex既有證據。本輪沒有重跑。

## 已讀來源事實

原ZIP為TWstockai_Work_Source_Research_20261023.zip，16,795,237 bytes，SHA256 667c6fbc458feb086371ea5b54f468249699be8e24f979a12c53089dd244d669。已從其保存位置實際讀回，CRC無錯誤，MANIFEST內91項全部長度／SHA一致；讀了facts、原件meta、原PDF及官方API JSON。這是封存資料的離線核對，不是重新連線官方驗收，也不把原捕捉時點改成本輪時點。

| 原件 | 封存觀察時間（UTC，原meta原樣保留） | bytes | SHA256 |
| --- | --- | --- | --- |
| 台泥停牌起日PDF | 2026-10-23T03:06:59.401522+00:00 | 386308 | de4cd75086aad05089d4c3b9ca2f21218cb7088550359ef77bfd1db93ff83198 |
| 玉山停牌起日PDF | 2026-10-23T03:05:02.193264+00:00 | 380108 | ce5e00490f5d5dc9fed0873e754348d3cb29b28c7e26014fb6d9293e68c32512 |
| 財政部TaxSN143802真實API JSON | 2026-10-23T03:10:08.388759+00:00 | 12953 | 0616b330ca5fbd08d692546e5ce0c0f9f4d6bdeeb99ca5b6691d70b4b44b65b3 |

### 停牌日期與範圍

- 台泥PDF日期2025/8/12，明載1101上市普通股自2025/8/13起暫停交易。這份起日文件和GitHub已存8/14復牌文件分開，可為8/13提供正面證據；不是只從復牌日倒推。
- 玉山PDF日期2025/11/4，明載2884上市普通股自2025/11/5起暫停交易。復牌原件仍未補到，不能自行延伸起迄期間。
- 本輪重新抽字並檢視封存頁面影像；未產生產品狀態。可供Codex在新版本來源診斷採用，現有0.5的UNKNOWN與Raw null完全未改。沒有停牌價格、估值政策、成交資格或總報酬解鎖。

原來源URL只作provenance，不是要求重試：
- https://wwwc.twse.com.tw/staticFiles/news/news/tsecnews/8a8216d697fc438f01989dd5fa3502a6.pdf
- https://investoredu.twse.com.tw/Mobile_pages/..%2FFileSystem%2FFileUpload%2Fdae59521-69e0-4856-90fc-d349fb6013eb.pdf

### 稅務來源

真實JSON Code=1、Data.Table一筆，TaxAct=所得稅法、TaxVer=一一四年版、Title=一51公司將資本公積以現金方式發給股東之課稅規定、Terms=1、Subsection=51；Content含101/8/17台財稅字第10100097670號令。本小包同帶封存官方頁面、前端查詢腳本、原查詢表單與meta，供唯一Codex離線驗來源，再接既有parse_mof_api契約；本輪沒有呼叫該產品parser。

可支持：指定不具股東出資額性質的資本公積現金按股利所得課稅；項目認定依決議，未載明時依帳冊。不可支持：台泥每筆實際資金最細來源、個人稅籍、免稅、零保費、零匯費或淨入帳。一般函釋的取得不等所有歷史日期適用法規已驗。ViewCount等欄可變；既有封存回應須核原SHA，未來新回應必另存新觀察，不要求整份SHA固定。

原provenance：https://ttc.mof.gov.tw/FB/FB120/143802；公開查詢POST https://ttc.mof.gov.tw/Api/PostData，FunctionID=FB12001，ObjParams[TaxSN]=143802。本輪未連線這些已被拒入口。

## 進一步來源搜尋：未完成與未讀

- 針對玉山2025上市日、2025畸零股、實際換股完成、台泥最後調整／減資與來源細項補查官方來源。搜尋出8/27上市的媒體轉載仍只作尋源線索，沒有直接官方上市原件，本輪不升格tradable_date。
- 玉山併購官方索引可讀，仍列7/23公開說明書及8/14 Q&A等；索引沒有新項目，不證無事件，也不證9/1完成或既有2884完全無影響。
- 終止上市頁開啟僅取得查詢介面，沒有本輪封存可重現的2867完整資料列；搜尋摘要不作實際換股帳證據。
- 本輪未取得窮盡的1101／2884公司行動減資名冊、2026/7/25～10/16權息、2025未圓整／個人實配與畸零處置、既有2884完整換股影響、台泥最後調整及細項來源、個人淨分配或九起日期初權利。
- 不重讀玉山765頁全冊；原第1／55頁工程驗收不冒稱本輪重驗。無私人券商或集保原件；空白不代表零權利。

## 錯誤與界線

本輪沒有新增來源擷取錯誤或重試被拒入口。GitHub所記代理403／未套用草稿、原Work包所記TWSE公文查詢307／MOPS空頁導向／xref警告等照舊保留。原包含有舊31測試紀錄，不覆蓋目前61項證據；本輪只核封包與來源，不把檔案指紋核對算產品測試。

## 建議與交接

把本小包附給既有唯一Codex工作，依CODEX_HANDOFF.md做離線來源新版本。不要再次要求它連線相同被拒網域，也不要將整個原包的固定GitHub文字副本覆蓋新專案。

若Codex仍看不到附件，須明說原件未取得並停止該部分接入；不能用本報告摘要、SHA字串、合成回應或目前Work可讀冒稱Codex已有原件。這個跨環境可讀性缺口和產品規則驗收分開。

原70窗拒算、2不足、8窗換股影響未支援、真正總淨報酬合格0保持，沒有本輪每日淨帳或六方案績效。歷史訊號false、主壓力null、策略授權false維持；無新UI／Android／部署／付費／交易／訊息或子代理。
