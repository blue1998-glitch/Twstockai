# 離線原件小包

先讀REPORT.md及CODEX_HANDOFF.md，再讀bridge-facts.json。archived_work含從前次已保存研究ZIP讀回的兩停牌原PDF、財政部真實API／script／頁面與meta。沒有新的官方請求到被拒絕的來源。

github_reference及原facts只供比較，不覆蓋專案。原策略、引擎與資料不在此包修改；沒有新產品程式／測試／績效。SHA、CRC與manifest核對只屬來源保存。

若既有Codex仍看不到本附件，需明說原件未取得；不能拿本包摘要或合成資料假裝已接入。無需重試被拒來源。
