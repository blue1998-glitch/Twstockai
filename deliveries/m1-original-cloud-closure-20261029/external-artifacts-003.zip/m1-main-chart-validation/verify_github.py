from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,hashlib,json,urllib.request,urllib.parse,datetime
root=Path('/workspace/Twstockai');out=root/'deliveries/m1-v019-technical-chart-20261017';commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
files=[p for p in out.iterdir() if p.is_file() and p.name!='GITHUB_DOWNLOAD_VERIFICATION.json']
files += [root/n for n in ['AGENTS.md','CONTINUE_IN_WORK_MODE.md','M1_V019_LONG_HISTORY_CHART_HANDOFF.md','M1_V019_TECHNICAL_CHART_ANDROID_ACCEPTANCE.md','股票系統M1_v0_18/technical_chart/build.py','股票系統M1_v0_18/technical_chart/viewer.js','股票系統M1_v0_18/technical_chart/validation_20261017/browser/browser-report.json','股票系統M1_v0_18/technical_chart/validation_20261017/artifact-delivery-report.json']]
def check(p):
 name=str(p.relative_to(root));url='https://github.com/blue1998-glitch/Twstockai/raw/'+commit+'/'+urllib.parse.quote(name,safe='/')
 with urllib.request.urlopen(url,timeout=90) as r:
  b=r.read();status=r.status
 local=p.read_bytes();assert status==200 and b==local,name
 return dict(file=name,status='PASS',http_status=status,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),url=url)
with ThreadPoolExecutor(max_workers=3) as pool:checks=list(pool.map(check,sorted(files)))
report=dict(status='PASS',verified_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),artifact_commit=commit,branch='dev/m1-v018-chart-annotations',checks=checks,main_unchanged_commit='9c5b168c09ba80010c74f03b9c537e8b7474256a')
p=out/'GITHUB_DOWNLOAD_VERIFICATION.json';assert not p.exists();p.write_text(json.dumps(report,ensure_ascii=False,indent=2));print('PASS',len(checks),'remote files',sum(c['bytes'] for c in checks),'bytes',commit)
