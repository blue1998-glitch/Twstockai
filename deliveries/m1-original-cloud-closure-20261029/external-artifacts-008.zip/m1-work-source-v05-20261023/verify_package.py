from pathlib import Path
import hashlib,json,subprocess,zipfile

ROOT=Path('/workspace/Twstockai'); WORK=Path('/workspace/m1-work-source-v05-20261023')
DEL=ROOT/'deliveries/m1-source-diagnostics-20261023'
target=DEL/'m1-source-diagnostics-v05-20261023.zip'
out=WORK/'fresh-extracted'
out.mkdir(exist_ok=False)
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))
 assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
 body={n:z.read(n) for n in z.namelist()}
 z.extractall(out)
with zipfile.ZipFile(ROOT/'deliveries/m1-resolution-validation-20261023/m1-resolution-verified-v04-20261023.zip') as z:
 assert all(z.read(n)==body[n] for n in z.namelist())
 parent=len(z.namelist())
manifests={}
for name,b in body.items():
 if name.endswith('_MANIFEST.json'):
  m=json.loads(b)
  assert all(hashlib.sha256(body[n]).hexdigest()==sha for n,sha in m.items())
  manifests[name]=len(m)
commands=[['python3','-m','unittest','rotation_research.test_source_diagnostics','rotation_research.test_action_resolution','rotation_research.test_resolution_validation','-v'],
 ['python3','-m','rotation_research.source_diagnostics_sources']]
results=[]
for args,name in zip(commands,['extracted-tests.log','extracted-producer.log']):
 p=subprocess.run(args,cwd=out/'股票系統M1_v0_18',capture_output=True,text=True)
 (DEL/name).write_text(p.stdout+p.stderr)
 results.append(dict(command=args,returncode=p.returncode,log=name))
 assert p.returncode==0,name
assert 'Ran 61 tests' in (DEL/'extracted-tests.log').read_text()
assert all((out/n).read_bytes()==b for n,b in body.items())
v=json.loads((out/'股票系統M1_v0_18/rotation_research/source_diagnostics_20261023/verification.json').read_text())
assert (v['refused_windows'],v['insufficient_windows'],v['exchange_unsupported_windows'],v['qualified_total_net_return_windows'])==(70,2,8,0)
result=dict(status='PASS',filename=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
 members=len(body),parent_members_byte_exact=parent,manifests=manifests,commands=results,
 actual_tests=61,new_distinct_source_tests=30,rerun_formal_v04_tests=31,
 all_bundle_members_unchanged_after_test_and_producer=True,offline_producer_verification=v)
(DEL/'package-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
