import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
name, *command = sys.argv[1:]
cwd = base / 'run-1/股票系統M1_v0_17'
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
tick = time.monotonic()
with (base / f'{name}.log').open('w') as log:
    result = subprocess.run(command, cwd=cwd, stdout=log, stderr=subprocess.STDOUT,
                            env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
report = dict(command=command, cwd=str(cwd), started_utc=started,
              duration_seconds=round(time.monotonic()-tick, 3), exit_code=result.returncode)
(base / f'{name}.execution.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
print(json.dumps(report, ensure_ascii=False))
print((base / f'{name}.log').read_text()[-2500:])
sys.exit(result.returncode)
