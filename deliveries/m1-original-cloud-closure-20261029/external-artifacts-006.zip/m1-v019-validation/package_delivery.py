from pathlib import Path
import hashlib,json,shutil,zipfile
repo=Path('/workspace/Twstockai');project=repo/'股票系統M1_v0_18';run=Path('/workspace/m1-v019-validation/final')
output=repo/'deliveries/m1-v019-context-20261017';output.mkdir(parents=True,exist_ok=True)
for name in ['M1_v0_19_candidate.html','candidate.json']:shutil.copy2(run/name,output/name)
with zipfile.ZipFile(output/'M1_v019_candidate_page.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.write(output/'M1_v0_19_candidate.html','M1_v0_19_candidate.html')
 z.writestr('使用說明.txt','解壓後開啟 M1_v0_19_candidate.html，明選股票／模式及分析日。Android本機開檔仍未驗收；不要把圖形或雲端模擬通過當成核心分析認可。規則、完整證據及未決核心案例請讀同分支交接。')
items={}
for p in project.rglob('*'):
 if not p.is_file() or any(x in p.relative_to(project).parts for x in ('__pycache__','tmp')) or p.suffix=='.pyc':continue
 if p.is_symlink():raise ValueError('Unexpected symlink: '+str(p))
 items[p.relative_to(repo).as_posix()]=p
for name in ['AGENTS.md','CONTINUE_IN_WORK_MODE.md','M1_V018_PRODUCT_GAP_HANDOFF.md','M1_V019_REQUIREMENTS_TRACE.md','M1_V019_CORE_RULE_DECISIONS.md']:
 items[name]=repo/name
for name in ['M1_v0_19_candidate.html','candidate.json']:
 items['股票系統M1_v0_18/product_candidate/generated/'+name]=output/name
manifest={name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for name,p in sorted(items.items())}
manifest_path=output/'PROJECT_FILE_MANIFEST.json';manifest_path.write_text(json.dumps(dict(version='M1 v0.19 independent candidate',files=manifest),ensure_ascii=False,indent=2))
items['PROJECT_FILE_MANIFEST.json']=manifest_path
readme=output/'OFFLINE_PROJECT_README.txt';readme.write_text('本三包為完整離線專案，各含部分檔案，全部解壓到同一資料夾。既有資產已附，不需舊版ZIP；不要執行bootstrap覆蓋來源。先讀 CONTINUE_IN_WORK_MODE.md。候選HTML在 股票系統M1_v0_18/product_candidate/generated/。若是Git checkout才需從repository root執行 python3 codex/bootstrap_m1.py --hydrate-missing。原manifest為歷史基準，合法差異另有報告；本次精確檔案hash用 PROJECT_FILE_MANIFEST.json。核心產品與Android實機仍未驗收。')
items['OFFLINE_PROJECT_README.txt']=readme
# Measure actual compressed members, then balance three ordinary independent ZIPs.
whole=Path('/workspace/m1-v019-validation/pack-members.zip')
with zipfile.ZipFile(whole,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(items.items()):z.write(p,name)
with zipfile.ZipFile(whole) as z:
 groups=[[],[],[]];sizes=[0,0,0]
 for info in sorted(z.infolist(),key=lambda i:i.compress_size,reverse=True):
  group=min(range(3),key=lambda i:sizes[i]);groups[group].append(info.filename);sizes[group]+=info.compress_size+len(info.filename.encode())*2+100
for i,names in enumerate(groups,1):
 with zipfile.ZipFile(output/('M1_v019_full_0%d.zip'%i),'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name in sorted(names):z.write(items[name],name)
# Actually extract all three into a fresh directory and verify every input byte.
extract=Path('/workspace/m1-v019-validation/extracted');extract.mkdir(exist_ok=False)
seen=set();archive_sizes=[]
for i in range(1,4):
 path=output/('M1_v019_full_0%d.zip'%i);assert path.stat().st_size<32*1024*1024
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None;assert not seen.intersection(z.namelist());seen.update(z.namelist());z.extractall(extract)
 archive_sizes.append(dict(file=path.name,bytes=path.stat().st_size,mib=round(path.stat().st_size/1024/1024,3)))
assert seen==set(items)
for name,p in items.items():assert hashlib.sha256((extract/name).read_bytes()).digest()==hashlib.sha256(p.read_bytes()).digest()
report=dict(status='PASS',archives=archive_sizes,unique_members=len(seen),project_and_handoff_files=len(manifest),all_extracted_bytes_match=True,duplicates=0,original_engine_or_database_recomputed=False)
(output/'PACKAGE_VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False))
