from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,subprocess,urllib.request
repo=Path('/workspace/Twstockai');folder=repo/'deliveries/m1-v019-context-20261017'
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
entries=[]
for line in (folder/'SHA256SUMS.txt').read_text().splitlines():
 expected,name=line.split('  ',1);entries.append((name,expected))
def check(entry):
 name,expected=entry
 url='https://github.com/blue1998-glitch/Twstockai/raw/'+commit+'/deliveries/m1-v019-context-20261017/'+name
 digest=hashlib.sha256();size=0
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'M1-delivery-verification'}),timeout=60) as response:
  status=response.status
  while True:
   block=response.read(1024*1024)
   if not block:break
   digest.update(block);size+=len(block)
 assert status==200 and digest.hexdigest()==expected and size==(folder/name).stat().st_size
 print('PASS',name,size,flush=True)
 return dict(file=name,status='PASS',http_status=status,bytes=size,sha256=digest.hexdigest(),url=url)
results=[]
with ThreadPoolExecutor(max_workers=3) as pool:
 for future in as_completed([pool.submit(check,entry) for entry in entries]):results.append(future.result())
report=dict(status='PASS',verified_at_utc=datetime.now(timezone.utc).isoformat(),artifact_commit=commit,
 branch='dev/m1-v018-chart-annotations',checks=sorted(results,key=lambda row:row['file']),
 interpretation='Actual immutable GitHub HTTP GET bodies match local SHA256SUMS; local three-archive extraction verified separately',
 main_expected='9c5b168c09ba80010c74f03b9c537e8b7474256a')
(folder/'GITHUB_DOWNLOAD_VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('ALL_PASS',len(results),commit,flush=True)
