from pathlib import Path
root=Path('/workspace/Twstockai'); out=root/'股票系統M1_v0_18/rotation_research/official_actions_20261022'
prompt='''接續blue1998-glitch/Twstockai，分支dev/m1-v018-chart-annotations。先查遠端最新，確認包含6185297ed145f325bc1a19d99067a6aab084ce65及其後官方公司行動0.2補充交付／GitHub回讀收據，保留全部後續，不用main或舊ZIP覆蓋。最新已核提交見deliveries/m1-official-actions-20261022/GITHUB_READBACK.md。
依序讀根AGENTS、CONTINUE_IN_WORK_MODE、PROJECT_VISION、M1_V019_GRAPH_CORE_RESUME_HANDOFF最新節，再全文讀股票系統M1_v0_18/rotation_research/official_actions_20261022的README、REPORT、CONTRACT、WORK_HANDOFF、verification、source-manifest、minutes-facts、completion-facts、events-v02、window-qualification及delivery回讀收據；原action_data_20261022/CONTRACT和source_qualification_20261022/SOURCE_CONTRACT仍適用。
本輪新17定向測試及離線producer已實測，兩玉山官方PDF已封存。2025-06-13會議同次增資面額10元有來源；已存最終金額0.10015129元／10導出0.010015129股／原股，僅公開金額精度推導，不是已核未圓整最終比例或每人實配。議事錄每千股約10股不能代替最終比例。公司後續報告記載2025-07-28基準、8/27發放完畢，不等個人淨入帳／新股可交易日；原ex_date 7/22保持。零股得併湊、未併按面額折現至元及現金元以下捨去有條文，實際期限／處置仍未知。新schema 0.2只補一個原組件，四個現金組件及舊catalog／引擎不變。announced_at=null、historical_signal_eligible=false、primary_pressure_id=null。
下一步Work優先讀有來源的官方資料，補2025-07-01～2026-10-16完整公司行動／減資及其他事件覆蓋、特別2026-07-25後權息；2884直接最終配股比／實際配股精度、新股掛牌可交易日／零股截止；淨分配及期初持有權利。淨分配可用投資人證據，或來源明確、稅籍及情境明示的稅費模型，但未知不得預設零稅費／零權利。不需使用者猜比例，不重問已答P0～P1圖形規則。缺資料存原始錯誤與具體缺日／欄位，維持未知或拒算。
本輪runtime spec3兩新域生效，玉山PDF可讀；MOPS server-java/t39sb01?quick=1實際HTTP200卻是明確安全拒絕頁，原件已存，不能當空事件名冊，不重試、不換路徑繞過、不執行頁內IP腳本。先前TWSE TWT49U/TWT48U、TWTAUU歷史HTTP307及file://也不重試不繞過。其他來源如實際可讀，保存完整URL／擷取時間／SHA／原文欄位及覆蓋範圍；不能拿當前零命中、個別公司決議或衍生性商品公告認證整段無事件。
70窗已核317市場日／473曆日但公司行動／淨分配／期初權利不足，全仍拒算，2窗40筆不足；真正總淨報酬合格0，無新六方案回放或勝出比例。1101 2025-08-13、2884 2025-11-05市場開市但個股無報價，原因UNKNOWN，不補價。保留原Raw公司行動／五年Adjusted、歷史公布可得、主檔與SQLite未知。
如Work可處理純來源核對直接完成；需要工程交Codex，在實際完整checkout按AGENTS重新bootstrap --hydrate-missing成功後，只做獨立新來源版本，保留所有差異／舊證據，適量實測，不引用舊44、18／9982、Chrome36或前輪15為新版通過。沒有新UI；Android NOT_TESTED_NEW_BUILD，不重開舊手機驗收。全換／分批比例／觸發仍研究變數，不改原core／參數／策略／庫／歷史／舊頁／舊ZIP或main，不部署付費交易訊息或子代理。不自動下單，資料未合格不得畫成市場淨績效。逐節點保存同指定分支、固定提交逐檔GitHub回讀；結束列實際完成／未完成、成品／SHA入口、最新已核提交、下一步Work或Codex，並附完整續接指令。'''
(out/'WORK_HANDOFF.md').write_text('# 完整回Work／後續Codex指令\n\n本輪來源補充已保存時，請以根delivery回讀收據標示的最新提交為準。Work可先補來源核對；工程仍交Codex。\n\n```text\n'+prompt+'\n```\n')
latest='''# 2026-10-22 Codex｜官方公司行動來源0.2：2884面額／公司發放報告已補

接續6185297e，保留全部先前成果；新入口 `股票系統M1_v0_18/rotation_research/official_actions_20261022/README.md`、REPORT／CONTRACT／WORK_HANDOFF。新ZIP及固定GitHub逐檔核對見 `deliveries/m1-official-actions-20261022/README.md`。原0.1、日曆、P1-7及舊包全部保持；下方是歷史。

本環境重新bootstrap成功（0補缺／7差異保留），runtime spec3新域已列允許；實際取得玉山兩官方PDF。2025會議同次增資面額10元、最終公開股票股利金額0.10015129／10導出0.010015129股／原股；僅公開金額精度推導，非已核未圓整最終比例／個人實配。公司後續報告8/27發放完畢不是個人淨到款／新股可交易日；零股政策已存但期限／實際處置未核。新catalog0.2補一個原股票組件，四現金組件不動，announced_at仍null；新觀察時點不倒填舊可知時點。

新17定向測試通過，122價量原件重核、70研究窗仍拒算、2不足，真正總淨報酬合格0；無新六方案回放／排名。MOPS入口HTTP200卻為明確安全拒絕，原件保存、不重試繞過；原權息禁端點／TWTAUU／file://限制保留。完整行動／減資及2026/7/25後權息、2884可交易日／精確實配與零股、淨分配／期初權利仍缺。沒有把公司完成報告當投資人績效。

初次表格抽字／測試oracle失敗及修正均留檔；本輪無UI／瀏覽器／Android，Android仍NOT_TESTED_NEW_BUILD，前輪44／15及18／9982／Chrome36未重跑。原core／action_ledger／策略參數／庫／歷史／舊頁／舊ZIP及main保持，不重問已答P0～P1，不改全換／分批研究資格，不部署付費交易訊息或子代理。下一步Work補可核官方來源；需要工程用Codex，完整可貼指令見新WORK_HANDOFF。Raw／五年Adjusted、歷史公布／主檔與SQLite未知持續。以下原文完整保留。

---

'''
for rel in ('AGENTS.md','CONTINUE_IN_WORK_MODE.md','M1_V019_GRAPH_CORE_RESUME_HANDOFF.md','股票系統M1_v0_18/rotation_research/README.md','股票系統M1_v0_18/rotation_research/WORK_HANDOFF.md','股票系統M1_v0_18/rotation_research/DATA_QUALIFICATION.md'):
 p=root/rel; original=p.read_bytes(); assert not original.startswith(latest.encode());p.write_bytes(latest.encode()+original)
