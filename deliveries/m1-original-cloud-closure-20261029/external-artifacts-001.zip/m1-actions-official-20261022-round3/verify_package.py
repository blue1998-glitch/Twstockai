from pathlib import Path
import hashlib,json,zipfile,subprocess,tempfile
root=Path('/workspace/Twstockai'); delivery=root/'deliveries/m1-official-actions-20261022'; bundle=delivery/'m1-official-actions-v02-20261022.zip'
receipt=json.loads((delivery/'bundle-receipt.json').read_text());assert hashlib.sha256(bundle.read_bytes()).hexdigest()==receipt['sha256']
with tempfile.TemporaryDirectory(dir='/workspace',prefix='m1-official-actions-extracted-') as td:
 extracted=Path(td)
 with zipfile.ZipFile(bundle) as z:
  assert z.testzip() is None;z.extractall(extracted)
  with zipfile.ZipFile(root/'deliveries/m1-source-qualification-20261022/m1-source-qualification-v01-20261022.zip') as old:
   assert all(z.read(n)==old.read(n) for n in old.namelist());old_count=len(old.namelist())
  counts={}
  for manifest_name in ('OFFICIAL_ACTIONS_MANIFEST.json','SOURCE_QUALIFICATION_MANIFEST.json','ACTION_PACKAGE_MANIFEST.json'):
   manifest=json.loads(z.read(manifest_name));assert all(hashlib.sha256(z.read(n)).hexdigest()==s for n,s in manifest.items());counts[manifest_name]=len(manifest)
 project=extracted/'股票系統M1_v0_18'
 for name,args in [('extracted-tests.log',['python3','-m','unittest','rotation_research.test_official_actions','-v']),('extracted-producer.log',['python3','-m','rotation_research.official_actions'])]:
  r=subprocess.run(args,cwd=project,text=True,capture_output=True);(delivery/name).write_text(r.stdout+r.stderr);r.check_returncode()
 manifest=json.loads((extracted/'OFFICIAL_ACTIONS_MANIFEST.json').read_text())
 assert all(hashlib.sha256((extracted/n).read_bytes()).hexdigest()==s for n,s in manifest.items()),'Reproduction changed a shipped artifact'
 summary=dict(bundle_sha256=receipt['sha256'],fresh_extraction='PASS',tests=17,offline_producer='PASS',prior_members_byte_exact=old_count,manifests=counts,all_manifest_members_unchanged_after_offline_reproduction=True,new_strategy_runs=0,browser_runs=0,android='NOT_TESTED_NEW_BUILD')
 (delivery/'package-verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary))
