from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from urllib.request import urlopen
from urllib.parse import quote
import subprocess,json,hashlib
root=Path('/workspace/Twstockai');work=Path('/workspace/m1-actions-official-20261022-round3')
commit='188f84a42f4d012435f06bc86d46b31b82aebb55';branch='dev/m1-v018-chart-annotations'
files=json.loads((work/'publish-files.json').read_text())
def verify(name):
 url='https://raw.githubusercontent.com/blue1998-glitch/Twstockai/'+commit+'/'+quote(name,safe='/')
 local=(root/name).read_bytes()
 try:
  with urlopen(url,timeout=30) as response:
   body=response.read();status=response.status
  return dict(path=name,url=url,http=status,bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),byte_equal=body==local,pass_=status==200 and body==local)
 except Exception as e:
  return dict(path=name,url=url,pass_=False,error=type(e).__name__+': '+str(e))
with ThreadPoolExecutor(max_workers=4) as pool:
 checks=list(pool.map(verify,files))
head=subprocess.check_output(['git','ls-remote','origin','refs/heads/'+branch],cwd=root,text=True).split()[0]
main=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=root,text=True).split()[0]
assert head==commit and main=='9c5b168c09ba80010c74f03b9c537e8b7474256a'
receipt=dict(product_commit=commit,branch=branch,observed_at=datetime.now(timezone.utc).isoformat(),remote_branch_head=head,main_unchanged=main,files=len(checks),all_pass=all(c['pass_'] for c in checks),checks=checks)
(work/'readback.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='checks'}),flush=True)
for c in checks:
 if not c['pass_']:print(json.dumps(c,ensure_ascii=False))
assert receipt['all_pass']
