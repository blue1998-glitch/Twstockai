from pathlib import Path
import json
root=Path('/workspace/Twstockai'); out=root/'股票系統M1_v0_18/rotation_research/official_actions_20261022'
(out/'README.md').write_text('''# 官方公司行動來源補充 0.2（2026-10-22）

本輪新入口。保留舊事件帳0.1、來源日曆0.1、P1-7、舊成品及main；只新增官方文件擷取與獨立離線來源補充。沒有新增UI。

- [實測與資料限制](REPORT.md)
- [欄位／時間／資格契約](CONTRACT.md)
- [新事件表](events-v02.json)：僅補強原2884股票股利組件，不是新增公司事件或完整行動名冊。
- [官方原件及衍生文字指紋](source-manifest.json)、[議事錄事實](minutes-facts.json)、[公司完成報告](completion-facts.json)。
- [70窗口仍拒算](window-qualification.json)、[實際執行摘要](verification.json)、[17測試紀錄](tests.log)。
- [完整續接／回Work指令](WORK_HANDOFF.md)。小ZIP及GitHub回讀見根deliveries/m1-official-actions-20261022/README.md。

可離線執行（標準Python，不連網、不重跑原策略）：
```bash
cd 股票系統M1_v0_18
python3 -m unittest rotation_research.test_official_actions -v
python3 -m rotation_research.official_actions
```
PDF原件及pdftotext衍生文字均已封存，離線producer只讀經SHA綁定的文字，不需安裝PDF套件。若要獨立重做抽字，依raw/*.extraction.json的命令用pdftotext；後續執行producer不會自行連網或覆寫舊結果。
''')
(out/'CONTRACT.md').write_text('''# 官方公司行動來源補充契約 0.2

1. 這是新producer official_actions.py及新schema rotation-action-catalog/0.2-issuer-supplement；原action_sources、action_ledger及所有原輸入／結果不變。先用原reader重核122份價量原件，再核原四份事件原件與五組件；只在新路徑寫出新事件表與窗口拒算紀錄。
2. 官方PDF必須由原已封存玉山股東資訊HTML實際連結，HTTPS指定issuer域、HTTP200、PDF格式、長度及SHA均核對。pdftotext衍生文字另有PDF／文字雙SHA及工具版本，不把文字當第二份獨立原始證據。人工或程式不得任意補原件內容。
3. 議事錄抽出實際會議日、盈餘年度、同次轉增資面額、發行額／股數並相互核算，另核通過決議與允許調整配股率的條文。議事錄「每千股約10股」是當次概數，不作最終直接比率。
4. 原2884最終公開每股股票股利金額0.10015129元／本次有來源面額10元，按Decimal導出0.010015129股／原股，保留原金額精度。這是**依公開金額精度推導**，不是已驗的未四捨五入精確配股比或投資人實配股數；不得由除權參考價反推或假設面額。新組件保留supersedes_event_id、原值、雙來源欄位定位與新指紋。
5. 原ex_date=2025-07-22、公司除權息基準日=2025-07-28、公司報告2025-08-27發放完畢分開。公司事後完成報告只支持公司層級執行情形，不能認證特定投資人已淨入帳、新股掛牌或可賣日。tradable_date、investor_receipt_at、net_amount仍null。
6. 本次決議有零股得合併、逾期未併按面額折現至元及現金股利元以下捨去的規定；只存政策證據。實際併湊期限、個人選擇／股數、淨稅費及入帳未核，不在原帳新增無來源的圓整或補貼。fractional_disposition保持null；不能把理論小數權利當已可賣零股。
7. 原件擷取時點是目前觀察證明，不是歷史公開可得時點。新組件observed_at取包含新PDF的最晚擷取時點，另保留original_component_observed_at；announced_at=null，historical_signal_eligible=false。會議日不是上傳公開時點。
8. 新來源擷取create-only、驗既存原件、不自動重試／跳轉、不改proxy或TLS。兩域加入runtime後才各查必要入口；MOPS雖HTTP200卻是明確安全拒絕頁，記為不可用來源，不當零事件名冊、不重試、不換路徑繞過、不載入其外部IP腳本。原TWT49U/TWT48U、TWTAUU歷史失敗及file://限制繼續保留。
9. 原coverage仍INCOMPLETE、other_actions_checked=false；2025-07-01～2026-10-16完整公司行動／減資、2026-07-25後權息、淨分配／期初權利未補完。新catalog只更新一組件的來源與ID，不把5組件說成已涵蓋所有事件。
10. 本輪重用原window_audit及已核官方日曆，70價格研究窗均仍REFUSED_INCOMPLETE_EVENT_ACCOUNTING，2窗不足；真正總淨報酬合格0、無每日真實淨資金路徑／六策略再算或排名。全換／分批／比例／觸發仍研究變數，primary_pressure_id=null、policy_authorized=false。Raw公司行動、五年Adjusted、歷史公布、主檔及SQLite未知持續；無瀏覽器／Android新驗收。
''')
(out/'REPORT.md').write_text('''# 本輪實測與來源缺口

## 實際完成

- 分支起點6185297ed145f325bc1a19d99067a6aab084ce65，包含使用者指定50d8c5e及全部後續；fetch／ff後沒有遠端後續被覆蓋。重新bootstrap --hydrate-missing成功，0補缺、7合法差異保留，見bootstrap.log。
- Runtime spec 3且觀察current，兩官方域列入允許；network policy state仍unknown，不以設定證明可讀。實際取得兩個玉山官方PDF：議事錄1,572,950bytes、完成報告64,317bytes；URL／時點／SHA及PDF／文字對照均封存。
- 2025-06-13會議／2024盈餘同次增資議事錄PDF第19頁明載每股面額10元、股東股利增資1,602,000,000元／160,200,000股；第20頁表決通過並授權調整配股率。議事錄「約每千股10股」與最終金額分開。
- 依已存最終每股金額0.10015129／有來源面額10，導出0.010015129股／原股，保留公開精度；不認為已驗最終未圓整比例／每人實配。
- 官方執行情形PDF第1頁報告7/28基準、8/27發放完畢；只補公司層級報告，不補新股掛牌日或個人淨到款。零股政策與現金元以下捨去已存證據，實際截止／處置未核。
- 新catalog 0.2僅補原一個股票股利組件，保留父ID及新指紋／來源欄位；四個現金組件完全相同。原0.1／日曆與策略不變。
- 執行17項新定向unittest全部通過，重建122價量原件／原輸入一致，70日曆合格研究窗仍全部拒算、2不足，真正總淨報酬0合格。沒有六方案新回放／排名或市場績效。

## 失敗及修正（保留原證據）

1. MOPS官方入口server-java/t39sb01?quick=1回應HTTP200、800bytes，但正文是「因為安全性考量…THIS PAGE CAN NOT BE ACCESSED」。原HTML與SHA已存；判為SECURITY_DENIAL_NOT_EMPTY_DATA，停止該來源，不重試／繞過、不執行其外部腳本。這不是公司行動查無資料。
2. 初次producer因pdftotext -layout把表格兩欄交織而拒絕解析後續執行報告；initial-producer-failure.log及原-layout文字／抽字收據均保留。改用同原PDF的pdftotext -raw依閱讀順序另存文字／收據後才通過，不改PDF或憑猜測填值。
3. 初次17測試有1項錯誤：測試預期簡寫REFUSED，而原引擎實際完整狀態是REFUSED_INCOMPLETE_EVENT_ACCOUNTING。tests-first.log保留；只修正新測試oracle，未改原引擎狀態。修正後17項通過（tests.log）。

## 仍未完成

- 整段完整公司行動／減資與其他權利異動覆蓋、2026-07-25～10-16權息；MOPS安全拒絕不能替代完整名冊。
- 2884最終直接未圓整配股比／實際配股精度、新股可交易日、零股併湊截止／每人處置與現金。
- 股利淨分配的投資人證據，或來源明確且稅籍／情境明示的稅費模型；真實淨到款、期初持有／除權息權利。不得預設零稅、零費、零既存權利。
- 真正總淨報酬窗口仍0；沒有合格新成交路徑比較、勝出比例或正式全換／分批規則。
- 原1101 2025-08-13及2884 2025-11-05市場開市但個股無報價，原因UNKNOWN，未補價。Raw公司行動共同基底／五年Adjusted、歷史公布可得及SQLite根因未完成。
- 原44、18／9982、Chrome36及前輪15測試是歷史，本輪未重跑；無新UI／瀏覽器／Android，Android保持NOT_TESTED_NEW_BUILD，file://不重試。

打包後另以新目錄解壓執行17項及離線producer，校驗原375包成員、雙層舊manifest與新manifest並逐檔遠端回讀；實際結果見delivery bundle-receipt、package-verification及GITHUB_READBACK，未執行前不得引用為通過。保留檢核見preservation.json。
''')
