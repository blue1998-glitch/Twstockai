# 明示研究帶最大量：獨立重現包

不是全歷史專案，不要覆寫原checkout。正常查看直接用GitHub新PNG，不需手機搬檔、終端或架站。artifacts為新自含HTML／JSON及完整原精度；project含本輪完整新增工程、所需不變舊helper及已存公開0.2父輸入、原comparison-data，沒有新來源下載或graph_core／P0-3／指標重算。

工程師在新目錄解壓後：

```bash
cd project/股票系統M1_v0_18
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p test_explicit_band_volume.py -v
PYTHONDONTWRITEBYTECODE=1 python3 -m structure_state_chart.build_volume --output-dir structure_state_chart/output/REPRODUCED --selection structure_state_chart/examples/band-volume-selection.json
```

應與artifacts九輸出完整bytes相同。新解壓同26不加總52；相關6舊回歸只在完整repo實跑，不在此包跑無關全套。純prepare／evaluate也可無網頁呼叫。瀏覽器另需既有Chromium及Playwright，臨時loopback HTTP並非部署；Android未測，file://不重試。日期／來源資格／密集量峰未定及下一輪Work完整指令見WORK_HANDOFF。
