M1 多參照反應事實附層 0.1
本包是完整精度JSON資料，不是新版HTML或自動選關。
comparison-data為原真實圖來源與原core；reference-selection為後來明示查詢；reaction-facts為新附層。
參照可知日不代表當時已選關，historical_signal_eligible=false，primary_pressure_id=null。
原圖／引擎／策略／庫／歷史未改；全部策略及來源限制見reaction-facts.limits。
Android NOT_TESTED_NEW_BUILD；本輪無UI或瀏覽器驗收。
完整source、CLI、驗收及續接：repository reaction_facts/README.md與交付README。
