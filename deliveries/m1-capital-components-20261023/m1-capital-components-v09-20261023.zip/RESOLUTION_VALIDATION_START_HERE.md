# 決議0.4完整來源及本環境驗收

正式金融程式沿用action_resolution，不另發布平行草稿。原511成員逐位元保留。
先讀股票系統M1_v0_18/rotation_research/resolution_validation_20261023/README.md、REPORT、WORK_HANDOFF，及相鄰action_resolution_20261023/CONTRACT.md。
解壓至新目錄，進入股票系統M1_v0_18，標準Python離線：
```bash
python3 -m unittest rotation_research.test_action_resolution rotation_research.test_resolution_validation -v
python3 -m rotation_research.action_resolution_sources
```
31項＝正式版本29＋新增2；毛額非淨額／到款／期初權利或績效，70窗仍拒算、2不足、合格總淨報酬0。
PDF全文byte差異／首個失敗保持，所用頁與欄位相同；不需安裝pdftotext，衍生文字已封存。
RESOLUTION_VALIDATION_MANIFEST.json核本包全部其他成員，五層舊manifest仍有效。
不是全系統完整checkout；工程仍依GitHub根AGENTS準備。打包另需原0.4 ZIP，不重複塞ZIP。
