# 公司分項研究0.9離線重現

先讀股票系統M1_v0_18/rotation_research/capital_components_20261023/README.md、CONTRACT、REPORT、WORK_HANDOFF。
原0.8的693成員與十層manifest逐位元保留，舊入口只屬各自歷史版本。
解壓到全新目錄，cd 股票系統M1_v0_18，標準Python離線執行：
```bash
python3 -m unittest rotation_research.test_capital_components rotation_research.test_source_contracts -v
python3 -m rotation_research.capital_components_sources
```
本輪29新＋0.8相關31＝60，與前輪31新＋29回歸範圍不同；新解壓同60不累加。
不需網路／PDF工具／瀏覽器。原公開說明書已在舊成員內，新增391／456抽字與實際視讀PNG；xref警告／初次parser失敗與修正保留。
公司股東160200＋員工18000＝178200仟股只同家族對帳，非個人實配；29.05只公司計算參照，不是Raw價格或估值。
70拒算、2不足、8換股影響未支援、合格總淨報酬0，daily／journal空，無新六方案或Android通過。
CAPITAL_COMPONENTS_MANIFEST.json核全部其他成員，原十manifest仍有效。
這不是完整checkout；工程依GitHub最新AGENTS重新bootstrap，不以此包覆寫專案。
