# 獨立來源診斷0.5

保留正式0.4原完整驗收包全部528成員。新附層不是新淨帳／行情或策略版本。
先讀股票系統M1_v0_18/rotation_research/source_diagnostics_20261023/README.md、CONTRACT、REPORT、WORK_HANDOFF。
解壓至新目錄，cd 股票系統M1_v0_18，以標準Python離線執行：
```bash
python3 -m unittest rotation_research.test_source_diagnostics rotation_research.test_action_resolution rotation_research.test_resolution_validation -v
python3 -m rotation_research.source_diagnostics_sources
```
來源及抽字已封存，重現不需新網路或pdftotext。765頁PDF只有第1／55頁受核，xref警告保存。
兩缺價日仍UNKNOWN／Raw null；70拒算、2不足、8換股未支援、真正總淨報酬0。
SOURCE_DIAGNOSTICS_MANIFEST.json核全部其他成員，舊六層manifest仍有效。
本包非全系統checkout；工程需依最新GitHub AGENTS重新bootstrap，不以舊入口覆蓋專案。
封存capture-original-script.txt僅是本次擷取記錄，勿自動執行或重試受阻來源。
