# 公司行動決議來源0.4

最新入口：股票系統M1_v0_18/rotation_research/action_resolution_20261023/README.md、CONTRACT、REPORT、WORK_HANDOFF。
舊470成員逐位元保留；舊START_HERE是歷史，本入口才是本包最新版本。
解壓至新目錄，進入股票系統M1_v0_18，標準Python離線執行：
```bash
python3 -m unittest rotation_research.test_action_resolution -v
python3 -m rotation_research.action_resolution_sources
```
本包含必要前輪研究上下文與新原件，可執行以上兩命令；不是全系統完整checkout。
打包重建使用完整Git checkout及舊交付ZIP，不把舊ZIP再次塞進本包；先按根AGENTS重新bootstrap。
台泥股東會通過來源與每人現金總額圓整已接入；工程假想股數的gross preview不是個人淨額／到款／期初權利。
70窗拒算、2不足、淨報酬合格0；沒有六方案新績效，Android未測。
ACTION_RESOLUTION_MANIFEST.json核所有其他成員；所有舊manifest仍可獨立核。
