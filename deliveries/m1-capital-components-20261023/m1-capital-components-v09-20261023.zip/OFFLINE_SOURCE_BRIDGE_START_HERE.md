# 離線來源0.6：開始閱讀

先讀股票系統M1_v0_18/rotation_research/offline_source_bridge_20261023/README.md、CONTRACT、REPORT、WORK_HANDOFF。
原來源0.5包575成員及所有舊manifest逐位元保留，舊入口只屬其歷史版本。
解壓至全新目錄，cd 股票系統M1_v0_18，標準Python離線執行：
```bash
python3 -m unittest rotation_research.test_offline_source_bridge rotation_research.test_source_diagnostics rotation_research.test_action_resolution rotation_research.test_resolution_validation -v
python3 -m rotation_research.offline_source_bridge_sources
```
原橋接ZIP及metadata已含入；不需網路、pdftotext或瀏覽器。91項是30新＋61本輪回歸。
兩停牌起日有直接來源，舊UNKNOWN／Raw null與缺價拒算不改；70拒算、2不足、8換股不支援、真正總淨報酬0。
一般法律不是個人免稅／淨收，沒有新數值帳、六方案或Android通過。
OFFLINE_SOURCE_BRIDGE_MANIFEST.json核全部其他成員，原七manifest仍有效。
本包是離線重現附件，不是全系統checkout；工程以GitHub最新AGENTS先bootstrap，勿拿舊入口覆蓋專案。
