# 獨立來源0.7

先讀股票系統M1_v0_18/rotation_research/source_followup_20261023/README.md、CONTRACT、REPORT、WORK_HANDOFF。
606原0.6成員與八個舊manifest逐位元保留，原入口只屬各自歷史版本。
解壓到全新目錄，cd 股票系統M1_v0_18，標準Python離線執行：
```bash
python3 -m unittest rotation_research.test_source_followup rotation_research.test_offline_source_bridge -v
python3 -m rotation_research.source_followup_sources
```
29新＋30相關回歸＝59；新解壓同59不累加。三份實際官方原件已含入，不需網路、pdftotext或瀏覽器。
只補來源事實，TAIFEX佐證不是TWSE直接普通股公告；公司完成不是個人權利；月份／仟股／仟元精度保持。
70拒算、2不足、8換股影響未支援，真正總淨報酬0，沒有新六方案或Android通過。
SOURCE_FOLLOWUP_MANIFEST.json核全部其他成員，舊八manifest仍有效。
此為離線重現附件，不是完整checkout；工程使用GitHub最新AGENTS先bootstrap，不拿舊包覆蓋專案。
