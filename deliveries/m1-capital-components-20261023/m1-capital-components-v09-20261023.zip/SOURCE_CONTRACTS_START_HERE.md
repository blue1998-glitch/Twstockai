# 來源研究0.8離線重現

先讀股票系統M1_v0_18/rotation_research/source_contracts_20261023/README.md、CONTRACT、REPORT、WORK_HANDOFF。
原0.7的651成員與九層manifest完整逐位元保留，舊入口只屬各自歷史版本。
解壓到全新目錄，cd 股票系統M1_v0_18，標準Python離線執行：
```bash
python3 -m unittest rotation_research.test_source_contracts rotation_research.test_source_followup -v
python3 -m rotation_research.source_contracts_sources
```
31新＋本輪相關29＝60，同60解壓重驗不累加。無需網路／pdftotext／瀏覽器。
既有公開說明書及新一頁官方PDF已含入；只視讀指定六頁，765頁未全書核閱，xref及轉圖快取警告保留。
Work研究附件未見／未讀與其讀回時點未知明列，不能假稱已讀。
僅來源事實，條件異議不等個人權利；股東／員工／原2867與既有2884分開，登記非上市，稅費非淨額。
70拒算、2不足、8換股影響未支援、真正總淨報酬0，daily／journal空，無六方案或Android通過。
SOURCE_CONTRACTS_MANIFEST.json核其他全部成員，原九manifest仍有效。
這不是完整checkout；工程用GitHub最新AGENTS重新bootstrap，不以此包覆寫專案。
